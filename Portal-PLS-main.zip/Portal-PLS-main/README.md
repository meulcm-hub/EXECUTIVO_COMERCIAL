# Portal PLS LCM — NEXT-0.1

Primeira etapa real da migração do Google Apps Script para **Next.js + Node.js + PostgreSQL + Google APIs**.

## O que esta versão resolve arquiteturalmente

- Dashboard/histórico deixam de depender de varreduras do Google Sheets/Drive.
- Medições e eventos são modelados em PostgreSQL com índices.
- Drive continua sendo o repositório oficial dos Excel/PDF.
- Upload grande não atravessa a Function: usa armazenamento privado temporário.
- Aprovação tem autorização própria.
- PLS aprovada continua imutável.
- Versões antigas são preservadas.

## Rodar localmente

1. Copie `.env.example` para `.env.local` e preencha as variáveis.
2. Crie um PostgreSQL vazio.
3. Execute `sql/001_init.sql` no banco.
4. Instale dependências: `npm install`.
5. Rode `npm run dev`.
6. Abra `http://localhost:3000`.

## Atenção

Esta é uma **base de migração**, não substitua o Apps Script ainda. O parser completo da PLS está propositalmente bloqueado para não correr o risco de aprovar números diferentes dos atuais.

Leia `docs/MIGRATION_STATUS.md` e `docs/PROXIMA_ETAPA.md`.
