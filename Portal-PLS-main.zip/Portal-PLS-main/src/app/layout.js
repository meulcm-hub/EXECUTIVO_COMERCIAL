import './globals.css';
import React from 'react';

export const metadata = {
  title: 'Portal PLS LCM',
  description: 'Gestão de obras, medições e documentos — Portal PLS LCM',
};

export default function RootLayout({ children }) {
  return React.createElement('html', { lang: 'pt-BR' },
    React.createElement('body', null, children)
  );
}
