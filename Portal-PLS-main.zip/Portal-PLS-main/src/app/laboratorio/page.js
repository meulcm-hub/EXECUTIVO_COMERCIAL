'use client';
import React,{useEffect,useState} from 'react';
const h=React.createElement;
const MAX_BYTES=3*1024*1024;
export default function Laboratorio() {
 const [config,setConfig]=useState({loading:true,enabled:false,error:''});
 const [works,setWorks]=useState([]);
 const [obra,setObra]=useState('');
 const [numero,setNumero]=useState('');
 const [excel,setExcel]=useState(null);
 const [pdf,setPdf]=useState(null);
 const [agreed,setAgreed]=useState(false);
 const [working,setWorking]=useState(false);
 const [result,setResult]=useState(null);
 const [error,setError]=useState('');
 useEffect(()=>{let live=true;(async()=>{
  try {
   const [r,w]=await Promise.all([fetch('/api/laboratorio/envio',{cache:'no-store'}),fetch('/api/obras',{cache:'no-store'})]);
   const a=await r.json();
   if(!r.ok||!a.ok)throw new Error(a.error||'Acesso indisponível.');
   const b=await w.json();
   if(!w.ok||!b.ok)throw new Error(b.error||'Não foi possível carregar as obras.');
   if(live){setConfig({loading:false,enabled:!!a.labConfigured,error:''});setWorks(b.obras||[]);}
  }catch(e){if(live)setConfig({loading:false,enabled:false,error:e?.message||'Não foi possível carregar o laboratório.'});}
 })();return()=>{live=false;};},[]);
 async function send(e){
  e.preventDefault();setError('');setResult(null);
  if(!config.enabled)return setError('Laboratório desativado.');
  if(!agreed)return setError('Confirme que o Excel e o PDF são arquivos sintéticos de teste.');
  if(!obra || !/^[1-9]\d{0,3}$/.test(numero))return setError('Escolha a obra e o número da medição.');
  if(!excel)return setError('Selecione um Excel de teste.');
  if(excel.size+(pdf?.size||0)>MAX_BYTES)return setError('O total de Excel e PDF excede 3 MiB.');
  setWorking(true);
  try {
   const data=new FormData();data.set('obraId',obra);data.set('numero',numero);data.set('excel',excel);if(pdf)data.set('pdf',pdf);
   const r=await fetch('/api/laboratorio/envio',{method:'POST',body:data,cache:'no-store'});
   const j=await r.json();if(!r.ok||!j.ok)throw new Error(j.error||'Teste de envio não concluído.');
   setResult(j);
  }catch(e){setError(e?.message||'Teste não concluído.');}finally{setWorking(false);}
 }
 return h('div',{className:'lab-wrap'},
  h('header',{className:'lab-bar'},h('div',{className:'lab-brand'},h('img',{src:'/logo-lcm.png',alt:'LCM Construção'}),h('b',null,'Laboratório de envio · NEXT-0.8B')),h('a',{href:'/'},'← Voltar ao Portal PLS')),
  h('main',{className:'lab-main'},
   h('span',{className:'p-eyebrow'},'MÓDULO RESTRITO · ADMINISTRADORES'),
   h('h1',null,'Teste isolado de Excel e PDF'),
   h('p',null,'Valida a transferência real para um armazenamento privado de testes, confere os arquivos recuperados e os exclui. O Portal atual e as medições oficiais continuam protegidos.'),
   config.loading?h('p',{className:'lab-state'},'Verificando configuração...'):
    h('div',{className:'lab-state '+(config.enabled?'lab-ready':'')},config.error|| (config.enabled?'Laboratório configurado. Use APENAS arquivos sintéticos.':'Laboratório DESATIVADO. A equipe técnica deve configurar uma Private Blob Store exclusiva antes do primeiro teste.')),
   h('section',{className:'lab-card'},
    h('h2',null,'Envio temporário de teste'),
    h('p',{className:'lab-warning'},'Não envie planilhas de obras reais. O teste não cria versão, medição, evento, e-mail ou pasta no Google Drive. Os uploads oficiais continuam bloqueados.'),
    h('form',{onSubmit:send},
     h('label',{className:'lab-label'},'Obra de referência (somente identificação)',h('select',{className:'lab-input',value:obra,onChange:e=>setObra(e.target.value),required:true,disabled:!config.enabled},h('option',{value:''},'Selecione uma obra'),...works.map(w=>h('option',{key:w.id,value:w.id},[w.codigo,w.nome].filter(Boolean).join(' - '))))),
     h('label',{className:'lab-label'},'Número de teste',h('input',{type:'number',className:'lab-input',min:1,max:9999,step:1,required:true,value:numero,onChange:e=>setNumero(e.target.value),placeholder:'Ex.: 99',disabled:!config.enabled})),
     h('label',{className:'lab-label'},'Excel sintético de teste (.xls, .xlsx, .xlsm, .xlsb)',h('input',{type:'file',className:'lab-input',accept:'.xls,.xlsx,.xlsm,.xlsb',required:true,onChange:e=>setExcel(e.target.files?.[0]||null),disabled:!config.enabled})),
     h('label',{className:'lab-label'},'PDF sintético de teste (opcional)',h('input',{type:'file',className:'lab-input',accept:'.pdf',onChange:e=>setPdf(e.target.files?.[0]||null),disabled:!config.enabled})),
     h('label',{className:'lab-check'},h('input',{type:'checkbox',checked:agreed,onChange:e=>setAgreed(e.target.checked),disabled:!config.enabled}),'Confirmo que estes arquivos são fictícios e não contêm informações oficiais ou pessoais.'),
     h('button',{type:'submit',className:'lab-button',disabled:!config.enabled||working||!agreed||!excel||!obra||!numero},working?'Enviando, relendo e apagando...':'Testar upload privado e descarte')),
    error?h('div',{className:'lab-error',role:'alert'},error):null,
    result?h('div',{className:'lab-done',role:'status'},
      h('strong',null,'Teste de transferência e integridade concluído.'),
      h('p',null,`Sessão: ${result.labId} · ${result.work?.codigo} - ${result.work?.nome} · M${result.numero}`),
      h('p',null,`Abas identificadas: ${(result.planilha?.abas||[]).join(' | ')}`),
      h('div',{className:'lab-files'},...(result.arquivos||[]).map((f,i)=>h('div',{key:i},h('b',null,`${f.tipo.toUpperCase()} · ${f.arquivo}`),h('p',null,`${f.tamanhoBytes} bytes · ${f.integridade}`),h('span',{className:'lab-sha'},`SHA-256: ${f.sha256}`)))),
      h('strong',null,result.arquivosDescartados?'Arquivos de teste eliminados após leitura.':'Confirmar exclusão dos arquivos.'),
      h('p',null,'Neon: nenhuma gravação · Drive: nenhuma alteração · E-mails: nenhum envio · Aprovação: bloqueada.')):null),
   h('p',{className:'lab-warning'},'Se a operação falhar no meio do processamento, peça à equipe técnica para verificar e limpar o prefixo lcm-pls-lab-08b/ no armazenamento privado.')));
}
