'use client';
import React, { useEffect, useState } from 'react';

function App() {
  const [me, setMe] = useState(null);
  const [obras, setObras] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sync, setSync] = useState({ loading: false, preview: null, result: null, error: '' });
  const [inventory, setInventory] = useState({ loading: false, workId: '', result: null, error: '' });
  const [selectedMeasurement, setSelectedMeasurement] = useState('');
  const [reader, setReader] = useState({ loading: false, result: null, error: '' });
  const [migrationPreview, setMigrationPreview] = useState({ running: false, workId: '', total: 0, completed: 0, rows: [], error: '' });
  const [payloadPreview, setPayloadPreview] = useState({ loading: false, workId: '', data: null, error: '' });

  async function refresh() {
    const [m, o] = await Promise.all([
      fetch('/api/me', { cache: 'no-store' }).then((r) => r.json()),
      fetch('/api/obras', { cache: 'no-store' }).then((r) => r.json()).catch(() => ({ obras: [] })),
    ]);
    setMe(m);
    setObras(o.obras || []);
    setLoading(false);
  }

  useEffect(() => { refresh(); }, []);

  async function previewSync() {
    setSync({ loading: true, preview: null, result: null, error: '' });
    const r = await fetch('/api/admin/drive/sync-works', { cache: 'no-store' });
    const data = await r.json();
    if (!r.ok || !data.ok) return setSync({ loading: false, preview: null, result: null, error: data.error || 'Falha na prévia.' });
    setSync({ loading: false, preview: data, result: null, error: '' });
  }

  async function commitSync() {
    if (!window.confirm('Confirmar importação/atualização das obras no PostgreSQL? Esta ação NÃO move nem altera arquivos do Google Drive.')) return;
    setSync((s) => ({ ...s, loading: true, error: '' }));
    const r = await fetch('/api/admin/drive/sync-works', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ confirm: true }),
    });
    const data = await r.json();
    if (!r.ok || !data.ok) return setSync((s) => ({ ...s, loading: false, error: data.error || 'Falha na sincronização.' }));
    setSync((s) => ({ ...s, loading: false, result: data, error: '' }));
    await refresh();
  }

  async function auditWork(workId) {
    setReader({ loading: false, result: null, error: '' });
    setMigrationPreview({ running: false, workId: '', total: 0, completed: 0, rows: [], error: '' });
    setPayloadPreview({ loading: false, workId: '', data: null, error: '' });
    setSelectedMeasurement('');
    setInventory({ loading: true, workId, result: null, error: '' });
    const r = await fetch(`/api/admin/drive/pls-inventory?workId=${encodeURIComponent(workId)}`, { cache: 'no-store' });
    const data = await r.json();
    if (!r.ok || !data.ok) return setInventory({ loading: false, workId, result: null, error: data.error || 'Falha ao auditar arquivos da obra.' });
    const preferred = data.preferredMeasurements || data.measurementsFound || [];
    const latest = preferred.length ? Math.max(...preferred.map(Number)) : '';
    setSelectedMeasurement(latest ? String(latest) : '');
    setInventory({ loading: false, workId, result: data, error: '' });
  }

  async function readWorkbookOnServer() {
    if (!inventory.workId || !selectedMeasurement) return;
    setReader({ loading: true, result: null, error: '' });
    const r = await fetch(`/api/admin/drive/pls-read-preview?workId=${encodeURIComponent(inventory.workId)}&measurement=${encodeURIComponent(selectedMeasurement)}`, { cache: 'no-store' });
    const data = await r.json();
    if (!r.ok || !data.ok) return setReader({ loading: false, result: null, error: data.error || 'Falha ao abrir o Excel no servidor.' });
    setReader({ loading: false, result: data, error: '' });
  }

  async function generateHistoricalPreview() {
    const audit = inventory.result;
    if (!inventory.workId || !audit?.preferredMeasurements?.length) return;
    const measurements = (audit.preferredMeasurements || []).slice().map(Number).filter((x) => x > 0).sort((a, b) => a - b);
    setMigrationPreview({ running: true, workId: inventory.workId, total: measurements.length, completed: 0, rows: [], error: '' });

    const rows = [];
    for (let i = 0; i < measurements.length; i += 2) {
      const batch = measurements.slice(i, i + 2);
      try {
        const r = await fetch('/api/admin/migration/preview-batch', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ workId: inventory.workId, measurements: batch }),
          cache: 'no-store',
        });
        const data = await r.json();
        if (!r.ok || !data.ok) throw new Error(data.error || 'Falha ao gerar lote da prévia histórica.');
        rows.push(...(data.records || []));
        setMigrationPreview({ running: true, workId: inventory.workId, total: measurements.length, completed: Math.min(i + batch.length, measurements.length), rows: rows.slice(), error: '' });
      } catch (error) {
        batch.forEach((measurement) => rows.push({ measurement, error: error?.message || String(error), proposedAction: 'NAO_IMPORTAR' }));
        setMigrationPreview({ running: false, workId: inventory.workId, total: measurements.length, completed: Math.min(i + batch.length, measurements.length), rows: rows.slice(), error: error?.message || String(error) });
        return;
      }
    }
    setMigrationPreview({ running: false, workId: inventory.workId, total: measurements.length, completed: measurements.length, rows, error: '' });
  }

  async function inspectEventPayload() {
    if (!inventory.workId || !selectedMeasurement) return;
    setPayloadPreview({ loading: true, workId: inventory.workId, data: null, error: '' });
    try {
      const r = await fetch('/api/admin/migration/payload-preview', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ workId: inventory.workId, measurement: Number(selectedMeasurement) }),
        cache: 'no-store',
      });
      const data = await r.json();
      if (!r.ok || !data.ok) throw new Error(data.error || 'Falha no dry run do payload.');
      setPayloadPreview({ loading: false, workId: inventory.workId, data, error: '' });
    } catch (error) {
      setPayloadPreview({ loading: false, workId: inventory.workId, data: null, error: error?.message || String(error) });
    }
  }

  if (loading) return React.createElement('main', { className: 'shell' }, React.createElement('p', null, 'Carregando Portal PLS...'));
  if (!me?.authenticated) {
    return React.createElement('main', { className: 'shell' },
      React.createElement('section', { className: 'hero' },
        React.createElement('span', { className: 'badge' }, 'MIGRAÇÃO CONTROLADA'),
        React.createElement('h1', null, 'Portal PLS LCM'),
        React.createElement('p', null, 'Next.js + PostgreSQL + Google Drive API.'),
        React.createElement('a', { className: 'button', href: '/api/auth/google/start' }, 'Entrar com Google LCM')
      )
    );
  }

  const admin = me.profile?.perfilGlobal === 'ADMIN';
  const audit = inventory.result;
  const read = reader.result?.preview;

  return React.createElement('main', { className: 'shell' },
    React.createElement('header', { className: 'topbar' },
      React.createElement('div', null,
        React.createElement('strong', null, 'Portal PLS LCM'),
        React.createElement('small', null, ' NEXT-0.6F • Conferência de matrizes')
      ),
      React.createElement('div', { className: 'user' }, me.user?.name || me.user?.email)
    ),
    React.createElement('section', { className: 'hero compact' },
      React.createElement('h1', null, 'Conferência técnica das planilhas'),
      React.createElement('p', null, 'O Apps Script continua ativo. A NEXT-0.6F confere os serviços e as posições das matrizes em memória, sem liberar importação. Nenhuma medição, versão ou evento é gravado no PostgreSQL.'),
      React.createElement('div', { className: 'actions' },
        React.createElement('a', { className: 'button secondary', href: '/' }, '← Painel do Portal'),
        React.createElement('button', { className: 'button secondary', onClick: async () => { await fetch('/api/auth/logout', { method: 'POST' }); location.reload(); } }, 'Sair')
      )
    ),
    admin ? React.createElement('section', { className: 'card' },
      React.createElement('h2', null, 'Sincronização segura das obras'),
      React.createElement('p', null, 'A identidade externa da obra é o ID da pasta do Drive. Códigos repetidos permanecem separados.'),
      React.createElement('div', { className: 'actions' },
        React.createElement('button', { className: 'button secondary', disabled: sync.loading, onClick: previewSync }, sync.loading ? 'Analisando...' : '1. Analisar pastas do Drive'),
        sync.preview ? React.createElement('button', { className: 'button', disabled: sync.loading, onClick: commitSync }, '2. Importar/atualizar obras') : null
      ),
      sync.error ? React.createElement('p', { style: { color: '#b42318', fontWeight: 700 } }, sync.error) : null,
      sync.preview ? React.createElement('div', { className: 'work', style: { marginTop: 12 } },
        React.createElement('strong', null, `${sync.preview.discovered} pasta(s) de obra identificada(s)`),
        React.createElement('span', null, `${sync.preview.ignored?.length || 0} pasta(s) ignorada(s) por não seguirem o padrão de obra.`),
        React.createElement('span', null, `${sync.preview.duplicateCodes?.length || 0} código(s) repetido(s), mantidos separados por pasta.`)
      ) : null,
      sync.result ? React.createElement('div', { className: 'work', style: { marginTop: 12 } },
        React.createElement('strong', null, 'Sincronização concluída'),
        React.createElement('span', null, `Criadas: ${sync.result.summary?.inserted || 0} • Atualizadas: ${sync.result.summary?.updated || 0} • Conflitos: ${sync.result.summary?.conflicts?.length || 0}`)
      ) : null
    ) : null,
    React.createElement('section', { className: 'card' },
      React.createElement('h2', null, `Obras no PostgreSQL (${obras.length})`),
      React.createElement('p', null, admin ? 'Use “Auditar PLS” para identificar os arquivos e depois leia uma medição diretamente no servidor.' : ''),
      React.createElement('div', { className: 'grid' },
        ...(obras.length ? obras.map((o) => React.createElement('article', { className: 'work', key: o.id },
          React.createElement('strong', null, `${o.codigo} - ${o.nome}`),
          React.createElement('span', null, `${o.faixa_pls || 'Faixa não definida'} • ${o.perfil || ''}`),
          admin ? React.createElement('button', {
            className: 'button secondary',
            style: { marginTop: 8, padding: '7px 10px', fontSize: 12 },
            disabled: inventory.loading,
            onClick: () => auditWork(o.id),
          }, inventory.loading && inventory.workId === o.id ? 'Lendo Drive...' : 'Auditar PLS') : null
        )) : [React.createElement('p', { key: 'none' }, 'Nenhuma obra foi sincronizada para o PostgreSQL ainda.')])
      )
    ),
    admin && (inventory.loading || inventory.error || audit) ? React.createElement('section', { className: 'card' },
      React.createElement('h2', null, 'Auditoria de arquivos PLS'),
      inventory.loading ? React.createElement('p', null, 'Lendo somente a estrutura da obra no Google Drive...') : null,
      inventory.error ? React.createElement('p', { style: { color: '#b42318', fontWeight: 700 } }, inventory.error) : null,
      audit ? React.createElement(React.Fragment, null,
        React.createElement('div', { className: 'work' },
          React.createElement('strong', null, `${audit.work.codigo} - ${audit.work.nome}`),
          React.createElement('span', null, `${audit.foldersScanned} pasta(s) examinada(s) • ${audit.excelFiles} Excel encontrado(s)`),
          React.createElement('span', null, `${audit.identifiedFiles} identificado(s) • ${audit.unidentifiedFiles} sem número • ${audit.modelFiles || 0} modelo(s)`),
          React.createElement('span', null, `${audit.conflictFiles || 0} conflito(s) pasta × arquivo • ${audit.possibleWrongWorkFiles || 0} possível(is) arquivo(s) de outra obra`),
          React.createElement('span', null, `Medições encontradas: ${(audit.measurementsFound || []).join(', ') || 'nenhuma'}`),
          React.createElement('span', null, `Medições com candidato seguro: ${(audit.preferredMeasurements || []).join(', ') || 'nenhuma'}`),
          audit.missingMeasurements?.length ? React.createElement('span', { style: { color: '#b54708', fontWeight: 700 } }, `Lacunas no Drive até a maior medição: ${audit.missingMeasurements.join(', ')}`) : null,
          audit.reviewMeasurements?.length ? React.createElement('span', { style: { color: '#b54708', fontWeight: 800 } }, `Medições com mais de um candidato principal: ${audit.reviewMeasurements.join(', ')}`) : null,
          audit.truncated ? React.createElement('span', { style: { color: '#b54708', fontWeight: 700 } }, 'A leitura atingiu o limite de segurança e foi truncada.') : null
        ),
        audit.preferredMeasurements?.length ? React.createElement('div', { className: 'actions', style: { marginTop: 12, alignItems: 'center' } },
          React.createElement('select', {
            value: selectedMeasurement,
            onChange: (e) => { setSelectedMeasurement(e.target.value); setReader({ loading: false, result: null, error: '' }); setPayloadPreview({ loading: false, workId: '', data: null, error: '' }); },
            style: { padding: 9, borderRadius: 8, border: '1px solid #cbd5e1', fontWeight: 700 },
          }, ...(audit.preferredMeasurements || []).slice().sort((a, b) => b - a).map((n) => React.createElement('option', { key: n, value: n }, `M${String(n).padStart(2, '0')}`))),
          React.createElement('button', { className: 'button', disabled: reader.loading || !selectedMeasurement, onClick: readWorkbookOnServer }, reader.loading ? 'Abrindo Excel no servidor...' : 'Ler PLS no servidor'),
          React.createElement('button', { className: 'button secondary', disabled: migrationPreview.running, onClick: generateHistoricalPreview }, migrationPreview.running ? `Gerando preview ${migrationPreview.completed}/${migrationPreview.total}...` : 'Gerar preview histórico'),
          React.createElement('button', { className: 'button secondary', disabled: payloadPreview.loading || !selectedMeasurement, onClick: inspectEventPayload }, payloadPreview.loading ? 'Conferindo payload...' : 'Conferir matrizes 0.6F')
        ) : null,
        reader.error ? React.createElement('p', { style: { color: '#b42318', fontWeight: 700, marginTop: 12 } }, reader.error) : null,
        React.createElement('div', { style: { overflowX: 'auto', marginTop: 14 } },
          React.createElement('table', { style: { width: '100%', borderCollapse: 'collapse', fontSize: 12 } },
            React.createElement('thead', null, React.createElement('tr', null,
              ...['Medição', 'Origem', 'Situação', 'Papel', 'Arquivo', 'Caminho'].map((h) => React.createElement('th', { key: h, style: { textAlign: 'left', padding: 8, borderBottom: '1px solid #dbe3e8' } }, h))
            )),
            React.createElement('tbody', null,
              ...(audit.candidates || []).slice(0, 35).map((f) => React.createElement('tr', { key: f.driveFileId },
                React.createElement('td', { style: { padding: 8, borderBottom: '1px solid #edf1f4', whiteSpace: 'nowrap' } }, f.numeroMedicao ? `M${String(f.numeroMedicao).padStart(2, '0')}` : '—'),
                React.createElement('td', { style: { padding: 8, borderBottom: '1px solid #edf1f4', whiteSpace: 'nowrap' } }, f.numeroOrigem),
                React.createElement('td', { style: { padding: 8, borderBottom: '1px solid #edf1f4', minWidth: 210 } }, (f.situacao || []).join(' • ')),
                React.createElement('td', { style: { padding: 8, borderBottom: '1px solid #edf1f4', whiteSpace: 'nowrap' } }, f.papelArquivo || ''),
                React.createElement('td', { style: { padding: 8, borderBottom: '1px solid #edf1f4' } }, f.arquivo),
                React.createElement('td', { style: { padding: 8, borderBottom: '1px solid #edf1f4' } }, f.path)
              ))
            )
          )
        ),
        React.createElement('p', { style: { marginTop: 12, fontSize: 12, color: '#52606d' } }, audit.warning)
      ) : null
    ) : null,
    admin && migrationPreview.workId === inventory.workId && (migrationPreview.running || migrationPreview.rows.length || migrationPreview.error) ? React.createElement('section', { className: 'card' },
      React.createElement('h2', null, 'Preview da migração histórica'),
      React.createElement('p', null, 'Somente leitura. O Portal abre os candidatos selecionados, aplica as validações e mostra o que seria feito no banco. Nenhuma medição, versão ou evento é gravado nesta etapa.'),
      migrationPreview.running ? React.createElement('p', { style: { fontWeight: 800 } }, `Processando ${migrationPreview.completed}/${migrationPreview.total} medições...`) : null,
      migrationPreview.error ? React.createElement('p', { style: { color: '#b42318', fontWeight: 700 } }, migrationPreview.error) : null,
      migrationPreview.rows.length ? React.createElement(React.Fragment, null,
        React.createElement('div', { className: 'work' },
          React.createElement('strong', null, `${audit?.work?.codigo || ''} - ${audit?.work?.nome || ''}`),
          React.createElement('span', null, `Linhas analisadas: ${migrationPreview.rows.length}/${migrationPreview.total}`),
          React.createElement('span', null, `APTAS: ${migrationPreview.rows.filter((x) => x.validation?.status === 'APTO').length} • Bloqueadas/revisão: ${migrationPreview.rows.filter((x) => x.validation?.status && x.validation.status !== 'APTO').length} • Erros: ${migrationPreview.rows.filter((x) => x.error).length}`),
          React.createElement('span', { style: { color: '#b54708', fontWeight: 700 } }, 'Ainda não existe botão de importar nesta versão. Primeiro revise esta tabela.')
        ),
        React.createElement('div', { style: { overflowX: 'auto', marginTop: 14 } },
          React.createElement('table', { style: { width: '100%', borderCollapse: 'collapse', fontSize: 11, minWidth: 1450 } },
            React.createElement('thead', null, React.createElement('tr', null,
              ...['Medição','Status','Perfil','Arquivo','Nº interno','Período','Levantamento','Temporal','Eventos','Resumo / orçamento','Candidatos','Banco atual','Ação proposta','SHA-256'].map((h) => React.createElement('th', { key: h, style: { textAlign: 'left', padding: 7, borderBottom: '1px solid #dbe3e8', whiteSpace: 'nowrap' } }, h))
            )),
            React.createElement('tbody', null, ...migrationPreview.rows.slice().sort((a, b) => Number(a.measurement || 0) - Number(b.measurement || 0)).map((row) => {
              const summary = row.summary;
              const budgets = row.budgets;
              const financial = summary
                ? `Ant ${summary.previous ?? '—'} • Per ${summary.period ?? '—'} • Acum ${summary.accumulated ?? '—'} • R$ per ${summary.periodValue ?? '—'}`
                : (budgets ? `Hab ${budgets.habitacao ?? '—'} • Infra ${budgets.infraestrutura ?? '—'} • Equip ${budgets.equipamentos ?? '—'} • Global ${budgets.global ?? '—'}` : '—');
              return React.createElement('tr', { key: `migration-${row.measurement}` },
                React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4', fontWeight: 800, whiteSpace: 'nowrap' } }, row.measurement ? `M${String(row.measurement).padStart(2, '0')}` : '—'),
                React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4', fontWeight: 800, color: row.validation?.importAllowed ? '#067647' : '#b42318', whiteSpace: 'nowrap' } }, row.error ? 'ERRO' : (row.validation?.status || '—')),
                React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4', whiteSpace: 'nowrap' } }, row.parserProfile || '—'),
                React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4', minWidth: 220 } }, row.error || row.file?.name || '—'),
                React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4' } }, row.internalMeasurement || '—'),
                React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4', whiteSpace: 'nowrap' } }, row.period?.reference || '—'),
                React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4', whiteSpace: 'nowrap' } }, row.period?.surveyDate || '—'),
                React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4', whiteSpace: 'nowrap' } }, row.period?.temporalStatus || '—'),
                React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4' } }, row.events?.count ?? '—'),
                React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4', minWidth: 280 } }, financial),
                React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4', minWidth: 160 } }, row.candidates ? `${row.candidates.alternatives || 0} alternativo(s)${row.candidates.duplicateCandidatesIdentical ? ' • duplicados idênticos' : ''}` : '—'),
                React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4', minWidth: 150 } }, row.database ? `${row.database.measurementExists ? 'Medição existe' : 'Nova medição'} • ${row.database.versionCount || 0} versão(ões)${row.database.sameShaAlreadyExists ? ' • SHA já existe' : ''}` : '—'),
                React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4', fontWeight: 800, whiteSpace: 'nowrap' } }, row.proposedAction || 'NAO_IMPORTAR'),
                React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4', fontFamily: 'monospace' } }, row.file?.sha256 ? `${row.file.sha256.slice(0, 12)}…` : '—')
              );
            }))
          )
        )
      ) : null
    ) : null,
    admin && payloadPreview.workId === inventory.workId && (payloadPreview.loading || payloadPreview.error || payloadPreview.data) ? React.createElement('section', { className: 'card' },
      React.createElement('h2', null, 'NEXT-0.6F — Reconciliação de matrizes Faixa 1 e 2'),
      React.createElement('p', null, 'Leitura exclusiva: nenhuma versão, medição, evento ou arquivo é gravado. A grade mostra uma amostra; o mapeamento completo é conferido em memória.'),
      payloadPreview.loading ? React.createElement('p', null, 'Lendo e mapeando os eventos da medição...') : null,
      payloadPreview.error ? React.createElement('p', { style: { color: '#b42318', fontWeight: 700 } }, payloadPreview.error) : null,
      payloadPreview.data ? React.createElement(React.Fragment, null,
        React.createElement('div', { className: 'work' },
          React.createElement('strong', null, `M${String(payloadPreview.data.measurement).padStart(2, '0')} • ${payloadPreview.data.payload.status}`),
          React.createElement('span', null, `Validação da fonte: ${payloadPreview.data.validation.status} • Ação prevista: ${payloadPreview.data.proposedAction}`),
          React.createElement('span', null, `Eventos da leitura: ${payloadPreview.data.payload.completeSourceCount} • Eventos mapeados: ${payloadPreview.data.payload.mappedEvents} • Conferência: ${payloadPreview.data.payload.countsMatch ? 'CONTAGENS IGUAIS' : 'CONTAGENS DIFERENTES'}`),
          React.createElement('span', null, `Hash estrutural V3: ${payloadPreview.data.payload.structureSha256}`),
          React.createElement('span', null, `Já existe no banco: ${payloadPreview.data.database.measurementExists ? 'SIM' : 'NÃO'} • mesmo SHA: ${payloadPreview.data.database.sameShaExists ? 'SIM' : 'NÃO'}`),
          React.createElement('span', { style: { fontWeight: 800, color: '#b42318' } }, 'Importação DESABILITADA. Nenhum SQL de gravação é executado.')
        ),
        payloadPreview.data.payload.coverage?.length ? React.createElement('p', null, `Cobertura: ${payloadPreview.data.payload.coverage.map(x => `${x.area || x.sheetName}: ${x.events} evento(s)${x.matrixPositions !== undefined ? `; posições identificadas: ${x.matrixPositions}; serviços com matriz: ${x.matrixEvents}; células preenchidas: ${x.matrixCells}; divergências: ${x.matrixWarnings}; eventos temporais: ${x.temporalWithoutMatrix}` : ''}`).join(' • ')}`) : null,
        (payloadPreview.data.payload.warnings?.length || payloadPreview.data.pendingBeforeRealImport?.length) ? React.createElement('div', { style: { marginTop: 10 } },
          React.createElement('strong', null, 'Pontos para revisar antes de qualquer importação:'),
          ...(payloadPreview.data.payload.warnings || []).map((x, i) => React.createElement('p', { key: `pwar-${i}`, style: { color: '#b54708', margin: '4px 0' } }, `⚠ ${x}`)),
          ...(payloadPreview.data.pendingBeforeRealImport || []).map((x, i) => React.createElement('p', { key: `ppend-${i}`, style: { color: '#b54708', margin: '4px 0' } }, `• ${x}`))
        ) : null,
        // Diagnóstico explicativo; evidencia quais blocos estão preenchidos sem inferir qual célula deve ser corrigida.
        payloadPreview.data.payload.diagnostics?.eventDiscrepancies?.length ? React.createElement('div', { style: { padding: 12, border: '1px solid #f1d09e', borderRadius: 8, marginTop: 12 } },
          React.createElement('strong', null, 'Conferência detalhada — diferenças entre Excel e matriz'),
          ...payloadPreview.data.payload.diagnostics.eventDiscrepancies.map((d, i) => React.createElement('div', { key: `diag-${i}`, style: { marginTop: 9, paddingTop: 8, borderTop: '1px solid #e9ecef' } },
            React.createElement('p', null, `Linha ${d.line} • ${d.description} (${d.unit}) • quantidade oficial ${d.quantity}${d.quantityFormula ? ` (fórmula: =${d.quantityFormula})` : ''}`),
            React.createElement('p', null, `Excel: anterior ${d.official.previous ?? '—'}, período ${d.official.period ?? '—'}, acumulado ${d.official.accumulated ?? '—'} • Matriz: anterior ${d.matrixDerived?.previous ?? '—'}, período ${d.matrixDerived?.period ?? '—'}, acumulado ${d.matrixDerived?.accumulated ?? '—'}`),
            React.createElement('p', null, `Por grupo: ${(d.countsByGroup || []).map((b) => `${b.group}: ${b.countedPositions}`).join(' • ') || '(sem grupos)'}`),
            React.createElement('p', { style: { fontSize: 11, color: '#8a4716' } }, `${d.zeroPositions?.length ? `Posições zeradas: ${d.zeroPositions.join(', ')}. ` : ''}Não é possível concluir automaticamente quais células devem ser corrigidas. Os valores oficiais não foram alterados.`)
          ))
        ) : null,
        (payloadPreview.data.payload.diagnostics?.labelIssues?.length || payloadPreview.data.payload.diagnostics?.labelObservations?.length) ? React.createElement('div', { style: { padding: 12, marginTop: 10, border: '1px solid #e8d9b5', borderRadius: 8 } },
          React.createElement('strong', null, 'Conferência dos rótulos de posições'),
          ...(payloadPreview.data.payload.diagnostics.labelIssues || []).map((d,i) => React.createElement('p', { key:`li-${i}` }, `⚠ ${d.cell} • ${d.group} • valor original: ${d.original} • rótulo não reconhecido`)),
          ...(payloadPreview.data.payload.diagnostics.labelObservations || []).map((d,i) => React.createElement('p', { key:`lo-${i}` }, `Observação: ${d.cell} • ${d.group} • rótulo ${d.actualLabel} (demais grupos usam ${d.usualLabel}). Confirmar, sem correção automática.`))
        ) : null,
        React.createElement('div', { style: { overflowX: 'auto', marginTop: 12 } },
          React.createElement('table', { style: { width: '100%', borderCollapse: 'collapse', fontSize: 11, minWidth: 1050 } },
            React.createElement('thead', null, React.createElement('tr', null,
              ...['Linha', 'Área', 'Item', 'Descrição', 'Tipo', 'Qtd.', 'Incidência', 'Anterior', 'Período', 'Acumulado', '% Per.', 'Matriz'].map((h) => React.createElement('th', { key: h, style: { padding: 7, textAlign: 'left', borderBottom: '1px solid #dbe3e8' } }, h))
            )),
            React.createElement('tbody', null,
              ...(payloadPreview.data.dbRowsPreview.measurement_events.sample || []).map((e, i) => React.createElement('tr', { key: `${e.area}-${e.linha_pls}-${i}` },
                ...[e.linha_pls, e.area, e.item, e.descricao, e.tipo_evento || '—', e.quantidade, e.incidencia_servico, e.exec_anterior, e.exec_periodo, e.exec_acumulado, e.perc_periodo, e.matriz_json ? `${e.matriz_json.nonEmpty ?? '?'} preenchidas / ${e.matriz_json.values?.length ?? 0} posições${e.matriz_json.reconciliation?.length ? ' (REVISAR)' : ''}` : (String(e.unidade || '').toUpperCase().includes('MES') ? 'Temporal' : '—')].map((x, j) => React.createElement('td', { key: j, style: { padding: 7, borderBottom: '1px solid #edf1f4', maxWidth: j === 3 ? 280 : undefined } }, x === null || x === undefined ? '—' : String(x)))
              ))
            )
          )
        ),
        React.createElement('p', { style: { fontSize: 12, color: '#52606d' } }, `Exibindo até ${payloadPreview.data.dbRowsPreview.measurement_events.sampleLimit} linhas. Foram montados ${payloadPreview.data.dbRowsPreview.measurement_events.total} registros de eventos em memória para esta medição.`)
      ) : null
    ) : null,
    admin && (reader.loading || reader.error || read) ? React.createElement('section', { className: 'card' },
      React.createElement('h2', null, 'Leitura do Excel no servidor'),
      React.createElement('p', null, 'Esta etapa apenas baixa o arquivo escolhido pela API do Drive e o interpreta em memória. Nada é salvo no PostgreSQL e nada é alterado no Drive.'),
      reader.loading ? React.createElement('p', null, 'Baixando e lendo o Excel...') : null,
      reader.error ? React.createElement('p', { style: { color: '#b42318', fontWeight: 700 } }, reader.error) : null,
      read ? React.createElement(React.Fragment, null,
        React.createElement('div', { className: 'work' },
          React.createElement('strong', null, read.file.name),
          React.createElement('span', null, `Perfil detectado: ${read.parsed.parserProfile}`),
          React.createElement('span', null, `Medição pela pasta: ${read.file.measurementFromFolder || '—'} • medição dentro da planilha: ${read.parsed.internalMeasurementNumber || 'não identificada'}`),
          React.createElement('span', null, `Aba principal: ${read.parsed.selectedSheet || 'não reconhecida'} • eventos detectados: ${read.parsed.eventCount || 0}`),
          React.createElement('span', null, `Abas do arquivo (${read.workbook.sheetCount}): ${(read.workbook.sheetNames || []).join(' | ')}`),
          React.createElement('span', null, `SHA-256: ${read.file.sha256}`),
          read.parsed.periodReference ? React.createElement('span', null, `Período de referência: ${read.parsed.periodReference}`) : null,
          read.parsed.surveyDate ? React.createElement('span', null, `Data do levantamento: ${read.parsed.surveyDate}`) : null,
          read.internalMeasurementMismatch ? React.createElement('span', { style: { color: '#b42318', fontWeight: 800 } }, '⚠ O número interno da planilha difere da pasta. Não será importado automaticamente enquanto essa divergência não for tratada.') : null
        ),
        read.validation ? React.createElement('div', { className: 'work', style: { marginTop: 12, border: '2px solid #cbd5e1' } },
          React.createElement('strong', { style: { fontSize: 16 } }, `Validação da medição: ${read.validation.status}`),
          React.createElement('span', { style: { fontWeight: 800, color: read.validation.importAllowed ? '#067647' : '#b42318' } }, read.validation.importAllowed ? 'APTO para a próxima etapa de migração.' : 'NÃO apto para importação automática.'),
          ...(read.validation.reasons || []).map((x, i) => React.createElement('span', { key: `validation-${i}` }, `• ${x}`)),
          read.validation.candidateAlternatives?.length ? React.createElement('span', { style: { marginTop: 4, fontWeight: 700 } }, `Candidatos principais encontrados: ${read.validation.candidateAlternatives.map((x) => x.arquivo).join(' | ')}`) : null
        ) : null,
        read.temporalValidation ? React.createElement('div', { className: 'work', style: { marginTop: 12 } },
          React.createElement('strong', null, `Validação temporal: ${read.temporalValidation.status}`),
          read.temporalValidation.folderReference ? React.createElement('span', null, `Competência pela pasta: ${read.temporalValidation.folderReference}${read.temporalValidation.folderLabel ? ` • pasta: ${read.temporalValidation.folderLabel}` : ''}`) : React.createElement('span', null, 'Competência pela pasta: não identificada'),
          read.temporalValidation.periodReference ? React.createElement('span', null, `Período interno: ${read.temporalValidation.periodReference}`) : null,
          read.temporalValidation.surveyDate ? React.createElement('span', null, `Data do levantamento interna: ${read.temporalValidation.surveyDate}`) : null,
          read.temporalValidation.filenameReference ? React.createElement('span', { style: { color: '#52606d' } }, `Referência no nome do arquivo: ${read.temporalValidation.filenameReference} (informativa; não decide a validação)`) : null,
          ...(read.temporalValidation.issues || []).map((x, i) => React.createElement('span', { key: `temporal-${i}`, style: { color: read.temporalValidation.blocking ? '#b42318' : '#b54708', fontWeight: 700 } }, `⚠ ${x}`)),
          React.createElement('span', { style: { fontSize: 12, color: '#52606d' } }, read.temporalValidation.rule || '')
        ) : null,
        read.candidateComparison?.checked ? React.createElement('div', { className: 'work', style: { marginTop: 12 } },
          React.createElement('strong', null, `Comparação dos candidatos: ${read.candidateComparison.allIdentical ? 'DUPLICADOS IDÊNTICOS' : 'REVISÃO NECESSÁRIA'}`),
          React.createElement('span', { style: { fontWeight: 700, color: read.candidateComparison.allIdentical ? '#067647' : '#b54708' } }, read.candidateComparison.allIdentical ? 'Os candidatos possuem o mesmo SHA-256; não há diferença de conteúdo entre eles.' : 'Os candidatos não são byte a byte idênticos, ou a comparação não pôde ser concluída.'),
          ...(read.candidateComparison.files || []).map((x, i) => React.createElement('span', { key: `candhash-${i}` }, `${x.arquivo || x.driveFileId}: ${x.sha256 || 'SHA não obtido'}${x.error ? ` • erro: ${x.error}` : ''}`))
        ) : null,
        read.parsed.budgets ? React.createElement('div', { className: 'work', style: { marginTop: 12 } },
          React.createElement('strong', null, 'Orçamentos lidos da Faixa 1'),
          React.createElement('span', null, `Habitação: ${String(read.parsed.budgets.habitacao ?? '—')} • Infraestrutura: ${String(read.parsed.budgets.infraestrutura ?? '—')} • Equipamentos: ${String(read.parsed.budgets.equipamentos ?? '—')} • Global: ${String(read.parsed.budgets.global ?? '—')}`)
        ) : null,
        read.parsed.summary && Object.keys(read.parsed.summary).length ? React.createElement('div', { className: 'work', style: { marginTop: 12 } },
          React.createElement('strong', null, `${read.parsed.summary.valid === false ? '⚠ Resumo NÃO validado' : 'Resumo lido'} (${read.parsed.summary.source || 'fonte detectada'})`),
          React.createElement('span', { style: read.parsed.summary.valid === false ? { color: '#b42318', fontWeight: 800 } : null }, `Anterior: ${String(read.parsed.summary.previous ?? '—')} • Período: ${String(read.parsed.summary.period ?? '—')} • Acumulado: ${String(read.parsed.summary.accumulated ?? '—')}`),
          React.createElement('span', null, `Valor período: ${String(read.parsed.summary.periodValue ?? '—')} • Valor acumulado: ${String(read.parsed.summary.accumulatedValue ?? '—')}`),
          read.parsed.summary.detectedColumns ? React.createElement('span', null, `Colunas detectadas: anterior ${read.parsed.summary.detectedColumns.previous} • período ${read.parsed.summary.detectedColumns.period} • acumulado ${read.parsed.summary.detectedColumns.accumulated} • valor período ${read.parsed.summary.detectedColumns.periodValue}${read.parsed.summary.detectedColumns.accumulatedValue ? ` • valor acumulado ${read.parsed.summary.detectedColumns.accumulatedValue}` : ''}`) : null,
          read.parsed.summary.detectionMethod ? React.createElement('span', null, `Detecção: ${read.parsed.summary.detectionMethod}${Number.isFinite(Number(read.parsed.summary.consistencyDelta)) ? ` • diferença matemática ${Number(read.parsed.summary.consistencyDelta).toFixed(6)}` : ''}`) : null,
          read.parsed.summary.validationIssues?.length ? React.createElement(React.Fragment, null, ...read.parsed.summary.validationIssues.map((x, i) => React.createElement('span', { key: `issue-${i}`, style: { color: '#b42318', fontWeight: 700 } }, `⚠ ${x}`))) : null
        ) : null,
        read.parsed.summary?.diagnosticCells?.length ? React.createElement('div', { style: { overflowX: 'auto', marginTop: 12 } },
          React.createElement('strong', null, `Diagnóstico da linha usada no resumo${read.parsed.summary.diagnosticRow ? ` (linha ${read.parsed.summary.diagnosticRow})` : ''}`),
          React.createElement('table', { style: { width: '100%', borderCollapse: 'collapse', fontSize: 12, marginTop: 8 } },
            React.createElement('thead', null, React.createElement('tr', null, ...['Coluna','Cabeçalho próximo','Valor bruto','Exibido','Formato','Fórmula'].map((h) => React.createElement('th', { key: h, style: { textAlign: 'left', padding: 7, borderBottom: '1px solid #dbe3e8' } }, h)))),
            React.createElement('tbody', null, ...read.parsed.summary.diagnosticCells.map((c) => React.createElement('tr', { key: c.column },
              React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4', fontWeight: 800 } }, c.column),
              React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4' } }, c.header || '—'),
              React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4' } }, String(c.rawValue ?? '—')),
              React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4' } }, c.formattedValue || '—'),
              React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4' } }, c.format || '—'),
              React.createElement('td', { style: { padding: 7, borderBottom: '1px solid #edf1f4' } }, c.formula || '—')
            )))
          )
        ) : null,
        read.warnings?.length ? React.createElement('div', { className: 'work', style: { marginTop: 12 } },
          React.createElement('strong', null, 'Avisos da leitura'),
          ...(read.warnings.map((w, i) => React.createElement('span', { key: i, style: { color: '#b54708', fontWeight: 700 } }, `⚠ ${w}`)))
        ) : null
      ) : null
    ) : null
  );
}

export default App;
