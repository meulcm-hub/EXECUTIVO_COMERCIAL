'use client';
import React,{useEffect,useState} from 'react';
const h=React.createElement;
export default function OperationalReadiness(){
  const [state,setState]=useState({phase:'loading',data:null,error:''});
  useEffect(()=>{
    const ctrl=new AbortController();
    (async()=>{
      try{
        const res=await fetch('/api/admin/operacao/prontidao',{signal:ctrl.signal,cache:'no-store'});
        const body=await res.json();
        if(!res.ok||!body.ok)throw Error(body.error||'Falha ao verificar prontidão operacional.');
        if(!ctrl.signal.aborted)setState({phase:'ready',data:body,error:''});
      }catch(e){if(!ctrl.signal.aborted)setState({phase:'error',data:null,error:e?.message||String(e)});}
    })();return()=>ctrl.abort();
  },[]);
  return h('section',{className:'p-card p-operational-readiness'},
    h('div',{className:'p-card-head'},h('div',null,h('span',{className:'p-eyebrow'},'STATUS REAL DO BANCO'),
      h('h2',null,'Prontidão para operação'),h('p',null,'Conferência administrativa da estrutura e das etapas de liberação. Consulta sem gravações.'))),
    state.phase==='loading'?h('p',{className:'p-empty'},'Conferindo a estrutura do Neon...'):null,
    state.phase==='error'?h('p',{className:'p-error',role:'alert'},state.error):null,
    state.data?h(React.Fragment,null,
      h('div',{className:'p-readiness-facts'},...[
        ['Obras ativas',state.data.database.obras_ativas],
        ['Medições no Neon',state.data.database.medicoes_no_neon],
        ['Versões no Neon',state.data.database.versoes_registradas],
        ['E-mails pendentes',state.data.database.emails_pendentes],
      ].map(([k,v])=>h('div',{key:k},h('small',null,k),h('strong',null,String(v))))),
      h('p',{className:'p-history-notice'},state.data.database.readReady?'Estrutura base disponível; operações oficiais ainda bloqueadas.':'Estrutura base requer revisão antes da ativação.'),
      h('div',{className:'p-readiness-phases'},...state.data.phases.map(x=>h('div',{key:x.name},h('span',null,x.name),h('strong',{className:x.state==='DISPONIVEL'?'ready':'waiting'},x.state.replaceAll('_',' '))))),
      h('p',{className:'p-history-tail'},state.data.message)
    ):null
  );
}
