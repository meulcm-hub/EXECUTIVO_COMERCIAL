'use client';
import React,{useEffect,useMemo,useState} from 'react';
const h=React.createElement;
const n=number=>`M${String(number||0).padStart(2,'0')}`;
const moment=value=>value?new Date(value).toLocaleString('pt-BR'):'—';
const pct=value=>value==null?'—':`${Number(value).toLocaleString('pt-BR',{maximumFractionDigits:2})}%`;
const currency=value=>value==null?'—':Number(value).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});

export default function HistoryPanel({work=null,goToWorks}){
  const [data,setData]=useState({phase:'loading',items:[],counts:null,limited:false,error:''});
  const [search,setSearch]=useState('');
  const [status,setStatus]=useState('TODOS');
  const [selected,setSelected]=useState(null);
  const [detail,setDetail]=useState({phase:'idle',data:null,error:''});
  const workId=work?.id||null;
  useEffect(()=>{
    const controller=new AbortController();
    setData({phase:'loading',items:[],counts:null,limited:false,error:''});setSelected(null);setDetail({phase:'idle',data:null,error:''});
    (async()=>{
      try {
        const suffix=workId?`?obra=${encodeURIComponent(workId)}`:'';
        const res=await fetch(`/api/operacao/historico${suffix}`,{cache:'no-store',signal:controller.signal});
        const answer=await res.json();
        if(!res.ok||!answer.ok) throw new Error(answer.error||'Erro ao consultar o histórico.');
        if(!controller.signal.aborted)setData({phase:'ready',items:answer.items||[],counts:answer.counts,limited:!!answer.limited,error:''});
      } catch(e){if(!controller.signal.aborted)setData({phase:'error',items:[],counts:null,limited:false,error:e?.message||String(e)});}
    })();
    return ()=>controller.abort();
  },[workId]);
  useEffect(()=>{
    if(!selected)return;
    const controller=new AbortController();
    setDetail({phase:'loading',data:null,error:''});
    (async()=>{
      try{
        const res=await fetch(`/api/operacao/historico/${encodeURIComponent(selected)}`,{signal:controller.signal,cache:'no-store'});
        const payload=await res.json();
        if(!res.ok||!payload.ok)throw new Error(payload.error||'Falha ao carregar detalhes.');
        if(!controller.signal.aborted)setDetail({phase:'ready',data:payload,error:''});
      }catch(e){if(!controller.signal.aborted)setDetail({phase:'error',data:null,error:e?.message||String(e)});}
    })();return()=>controller.abort();
  },[selected]);
  const filtrados=useMemo(()=>data.items.filter(row=>{
    if(status!=='TODOS'&&row.status!==status)return false;
    const text=`${row.codigo||''} ${row.obra_nome||''} ${row.numero} ${row.arquivo_nome||''} ${row.criado_por||''}`;
    return text.toLowerCase().includes(search.trim().toLowerCase());
  }),[data.items,status,search]);
  const total=data.counts||{total:0,emExecucao:0,aprovadas:0,revisao:0};
  return h('section',{className:'p-history-section'},
    h('div',{className:'p-page-header'},h('div',null,
      h('span',{className:'p-eyebrow'},'LCM CONSTRUÇÃO · CONTROLE DE MEDIÇÕES'),
      h('h1',null,work?`Histórico da obra ${work.codigo} - ${work.nome}`:'Histórico e aprovações'),
      h('p',null,'Consulte versões, responsáveis e auditoria reais do PostgreSQL. Aprovações, uploads e e-mails permanecem no Portal atual.')),
      work&&goToWorks?h('button',{type:'button',className:'p-btn p-btn-light',onClick:goToWorks},'← Voltar à obra'):null),
    h('div',{className:'p-history-stats'},...[
      ['Medições no Neon',total.total],['Em execução',total.emExecucao],['Aprovadas',total.aprovadas],['Outras situações',total.revisao]
    ].map(([label,value])=>h('div',{className:'p-history-stat',key:label},h('small',null,label),h('strong',null,String(value))))),
    h('div',{className:'p-history-notice'},'Somente leitura. Uma planilha encontrada no Drive não significa que a medição foi criada ou aprovada no Neon.'),
    h('div',{className:'p-history-tools'},
      h('input',{type:'search',value:search,onChange:e=>setSearch(e.target.value),placeholder:'Pesquisar obra, arquivo, medição ou responsável...','aria-label':'Pesquisar histórico'}),
      h('select',{value:status,onChange:e=>setStatus(e.target.value),'aria-label':'Filtrar situação'},
        ...[['TODOS','Todas as situações'],['EM_EXECUCAO','Em execução'],['APROVADA','Aprovadas'],['DESAPROVADA','Desaprovadas'],['EXCLUIR','Outras situações']].map(([value,label])=>h('option',{key:value,value},label)))),
    data.phase==='loading'?h('p',{className:'p-empty'},'Consultando medições e versões no banco...'):null,
    data.phase==='error'?h('p',{className:'p-error',role:'alert'},data.error):null,
    data.phase==='ready'?h('div',{className:'p-history-layout'},
      h('div',{className:'p-history-list'},
        filtrados.length ? filtrados.map(item=>h('button',{type:'button',className:'p-history-row '+(selected===item.id?'selected':''),key:item.id,onClick:()=>setSelected(item.id)},
          h('span',{className:'p-history-number'},n(item.numero)),
          h('span',{className:'p-history-row-main'},h('strong',null,`${item.codigo} - ${item.obra_nome}`),h('small',null,`Versão ${item.versao??'—'} · ${item.arquivo_nome||'Arquivo não cadastrado'}`),
            h('span',{className:'p-history-status'},item.liberacao?.label||item.status||'Sem situação')),
          h('span',{className:'p-history-arrow'},'›'))) : h('div',{className:'p-history-empty'},
            h('strong',null,'Nenhuma medição registrada neste filtro'),
            h('p',null,'A consulta de documentos do Google Drive continua disponível na área de Obras. Este histórico não cria registros fictícios.'),
            goToWorks?h('button',{className:'p-btn p-btn-light',onClick:goToWorks},'Consultar obras'):null),
        data.limited?h('p',{className:'p-history-limit'},'Exibindo apenas as 150 medições mais recentes às quais você tem acesso.'):null),
      h('aside',{className:'p-history-detail'},
        !selected?h('div',{className:'p-history-empty'},h('strong',null,'Selecione uma medição'),h('p',null,'Veja a sequência das versões, o responsável por cada envio e o registro de ações do Portal.')):null,
        detail.phase==='loading'?h('p',null,'Carregando histórico da medição...'):null,
        detail.phase==='error'?h('p',{className:'p-error',role:'alert'},detail.error):null,
        detail.phase==='ready'&&detail.data?h(React.Fragment,null,
          h('span',{className:'p-eyebrow'},'DOSSIÊ DA MEDIÇÃO · SOMENTE LEITURA'),
          h('h3',null,`Medição ${n(detail.data.measurement.numero)}`),
          h('p',{className:'p-history-safety'},detail.data.measurement.liberacao.label),
          h('h4',null,`Versões (${detail.data.versions.length})`),
          ...detail.data.versions.map(v=>h('div',{className:'p-history-version',key:v.id},
            h('strong',null,`V${v.versao} · ${v.vigente?'Vigente':'Anterior'}`),
            h('small',null,v.arquivo_nome||'Arquivo sem nome'),
            h('small',null,`${v.status_versao||'—'} · ${v.processing_state||'—'}`),
            h('small',null,`Enviado por ${v.enviado_por||'—'} · ${moment(v.created_at)}`),
            h('small',null,`SHA-256: ${v.sha256_arquivo||'Não registrado'}`))),
          detail.data.limitedVersions?h('p',{className:'p-history-limit'},'Mais de 100 versões: consulta limitada.'):null,
          h('h4',null,`Trilha de auditoria (${detail.data.audit.length})`),
          detail.data.audit.length?detail.data.audit.map(a=>h('div',{className:'p-history-audit',key:a.id},
            h('strong',null,a.action),h('small',null,`${a.actor_email||'—'} · ${moment(a.created_at)}`))) : h('p',{className:'p-history-subtle'},'Nenhuma ação de auditoria registrada para esta medição.'),
          detail.data.limitedAudit?h('p',{className:'p-history-limit'},'Histórico exibido limitado às 40 ações mais recentes.'):null
        ):null)):null,
    h('div',{className:'p-history-tail'},'A liberação final de aprovação exige a validação integral das planilhas, PDF oficial, permissão de aprovador e teste transacional. Nenhuma dessas condições é presumida pelo histórico.')
  );
}
