'use client';
import React, { useEffect, useState } from 'react';
import { inspectLocalFiles } from '../../lib/pls/local-preflight.js';
const h = React.createElement;
const current = 'https://script.google.com/a/macros/lcmconstrucao.com.br/s/AKfycbzWwc9NnlJWSHoUywKObUCZjirQyznyZCGyJV7-uJlcUdifcntPFYxZEzKHfBCadxVR/exec';
const mn=n=>`M${String(n).padStart(2,'0')}`;
const date=raw=>raw?String(raw).slice(0,10).split('-').reverse().join('/'):'—';

function Flow({ status }) {
  const steps=[['01','Seleção','Escolher obra e medição'],['02','Envio','Excel e PDF'],['03','Conferência','Validação da PLS'],['04','Aprovação','Responsável autorizado'],['05','Arquivo','Versão e histórico imutável']];
  return h('div',{className:'p-ops-flow'},...steps.map(([num,title,desc],i)=>h('div',{key:num,className:'p-ops-step'},
    h('span',{className:'p-ops-index'},num),h('strong',null,title),h('small',null,desc),
    h('span',{className:'p-ops-stage'},i===0?'Consulta ativa':'Em implantação'))));
}
export default function WorkOperationsPanel({ work, rows=[] }) {
  const [numero,setNumero]=useState('');
  const [excel,setExcel]=useState(null);
  const [pdf,setPdf]=useState(null);
  const [result,setResult]=useState({phase:'idle',data:null,error:''});
  useEffect(()=>{setNumero('');setExcel(null);setPdf(null);setResult({phase:'idle',data:null,error:''});},[work?.id]);
  const records=Array.isArray(rows)?rows:[];
  const approved=records.filter(r=>r.status==='APROVADA').length;
  const execution=records.filter(r=>r.status==='EM_EXECUCAO').length;
  async function submit(e) {
    e.preventDefault();
    if(!work?.id || !excel) return;
    setResult({phase:'loading',data:null,error:''});
    try{
      const inspecao=await inspectLocalFiles({excel,pdf,faixaPls:work.faixa_pls,numero:Number(numero)});
      const r=await fetch(`/api/obras/${encodeURIComponent(work.id)}/envio/preflight`,{
        method:'POST',headers:{'Content-Type':'application/json'},cache:'no-store',
        body:JSON.stringify({numero:Number(numero),nomeArquivo:excel.name,tamanhoBytes:excel.size,
          pdfNome:pdf?.name||'',pdfTamanhoBytes:pdf?.size||0,
          sha256Excel:inspecao.excelSha256,sha256Pdf:inspecao.pdfSha256}),
      });
      const data=await r.json();
      if(!r.ok||!data.ok) throw Error(data.error||'Falha na pré-checagem.');
      setResult({phase:'done',data:data.resultado,inspecao,error:''});
    }catch(err){setResult({phase:'error',data:null,error:err.message||String(err)});}
  }
  return h('section',{className:'p-card p-ops-panel'},
    h('div',{className:'p-card-head'},h('div',null,h('div',{className:'p-small-label'},'GESTÃO DE MEDIÇÕES · FLUXO OPERACIONAL'),
      h('h2',null,'Envios, versões e aprovações'),h('p',null,'Conferência preliminar do Excel no navegador e situação real das medições no PostgreSQL.')),
      h('span',{className:'p-ops-live'},'Modo protegido')),
    h('div',{className:'p-ops-notice'},h('strong',null,'A operação oficial continua no Portal atual.'),
      h('p',null,'Nesta fase, não é possível enviar, substituir, aprovar ou disparar e-mails pelo novo Portal. Ao clicar em conferir, os arquivos são inspecionados somente neste navegador; a API recebe nomes, tamanhos e hashes SHA-256, nunca o conteúdo do Excel/PDF. Esta triagem não substitui a homologação oficial.'),
      h('a',{href:current,target:'_blank',rel:'noopener noreferrer'},'Acessar Portal PLS atual ↗')),
    h(Flow,{}),
    h('div',{className:'p-ops-grid'},
      h('div',{className:'p-ops-column'},
        h('div',{className:'p-ops-section-head'},h('h3',null,'Pré-conferência do arquivo'),h('span',null,'Sem transmissão de arquivos')),
        h('form',{onSubmit:submit,className:'p-ops-form'},
          h('label',null,'Número da medição',h('input',{type:'number',min:1,max:9999,step:1,required:true,value:numero,onChange:e=>{setNumero(e.target.value);setResult({phase:'idle',data:null,error:''});},placeholder:'Ex.: 19'})),
          h('label',null,'Planilha Excel (.xls, .xlsx, .xlsm, .xlsb)',h('input',{type:'file',accept:'.xls,.xlsx,.xlsm,.xlsb',required:true,onChange:e=>{setExcel(e.target.files?.[0]||null);setResult({phase:'idle',data:null,error:''});}})),
          h('label',null,'PDF complementar (opcional)',h('input',{type:'file',accept:'.pdf',onChange:e=>{setPdf(e.target.files?.[0]||null);setResult({phase:'idle',data:null,error:''});}})),
          h('button',{type:'submit',className:'p-btn',disabled:result.phase==='loading'||!excel||!numero},result.phase==='loading'?'Lendo arquivos no navegador...':'Conferir arquivo sem enviar')),
        result.phase==='error'?h('p',{className:'p-ops-error',role:'alert'},result.error):null,
        result.phase==='done'&&result.data?h('div',{className:'p-ops-result',role:'status'},
          h('strong',null,result.data.bloqueadoPorAprovacao?'Medição aprovada — alterações proibidas':'Pré-checagem concluída'),
          h('p',null,`${mn(result.data.numero)} · ${result.data.tipo.replaceAll('_',' ').toLowerCase()}`),
          h('small',null,`Status no Neon: ${result.data.statusNoNeon}`),
          result.inspecao?h('div',{className:'p-ops-local-inspect'},
            h('span',null,`Excel lido neste navegador · ${result.inspecao.quantidadeAbas} aba(s)`),
            h('span',null,`Aba principal: ${result.inspecao.abaPrincipal||'Não identificada'}`),
            h('span',null,`Medição interna indicativa: ${result.inspecao.numeroInternoIndicativo?mn(result.inspecao.numeroInternoIndicativo):'Pendente de validação'}`),
            h('span',null,`SHA-256 Excel: ${result.inspecao.excelSha256}`),
            result.inspecao.pdfSha256?h('span',null,`SHA-256 PDF: ${result.inspecao.pdfSha256}`):null,
            result.inspecao.indiciosParaRevisar.length?h('ul',null,...result.inspecao.indiciosParaRevisar.map((w,i)=>h('li',{key:'local'+i},w))):null,
            result.data.duplicidadeMesmoArquivo?h('strong',{className:'p-ops-dup'},'Arquivo idêntico já cadastrado nesta medição no Neon'):null,
            result.data.duplicidadeOutraMedicao?h('strong',{className:'p-ops-dup'},'Mesmo arquivo encontrado em outra medição desta obra'):null,
            h('small',null,'Esta é uma triagem local. Matriz, datas, aprovação e PDF oficial exigem validação do servidor.')):null,
          h('ul',null,...result.data.avisos.map((v,i)=>h('li',{key:i},v))),
          h('b',null,'Nenhum Excel/PDF foi transmitido ou gravado.')):null),
      h('div',{className:'p-ops-column'},
        h('div',{className:'p-ops-section-head'},h('h3',null,'Medições no novo banco'),h('span',null,`${records.length} cadastrada(s)`)),
        h('div',{className:'p-ops-summary'},
          h('div',null,h('strong',null,String(execution)),h('small',null,'Em execução')),
          h('div',null,h('strong',null,String(approved)),h('small',null,'Aprovadas')),
          h('div',null,h('strong',null,String(records.length)),h('small',null,'Total no Neon'))),
        records.length ? h('div',{className:'p-ops-records'},...records.slice(0,12).map(item=>h('div',{key:item.id,className:'p-ops-record'},
          h('strong',null,mn(item.numero)),h('span',null,item.competencia||'Sem competência'),
          h('span',{className:item.status==='APROVADA'?'approved':'pending'},item.status||'—'),
          h('small',null,item.versao?`Versão ${item.versao}`:'Sem versão')))) :
          h('div',{className:'p-ops-empty'},h('strong',null,'Histórico aguardando migração'),h('p',null,'As medições encontradas no Drive não são criadas automaticamente neste banco. A consulta documental permanece disponível logo abaixo.')),
        h('p',{className:'p-ops-note'},'Aprovações, assinaturas, e-mails e arquivos históricos não são inferidos pela existência de documentos no Drive.'))),
    h('p',{className:'p-ops-footer'},'Fluxo em homologação: o arquivo aprovado será imutável; a medição em execução poderá receber nova versão somente após validações, autorização e testes transacionais.'));
}
