'use client';
import React, { useEffect, useState } from 'react';

const h = React.createElement;
const money = v => v == null || !Number.isFinite(Number(v)) ? '—' : Number(v).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const percent = v => v == null || !Number.isFinite(Number(v)) ? '—' : `${Number(v).toLocaleString('pt-BR',{maximumFractionDigits:3})}%`;
const mnum = n => `M${String(n || 0).padStart(2,'0')}`;
const date = d => {
  if(!d) return '—';
  const text=String(d);
  if (/^\d{4}-\d\d-\d\d$/.test(text)) return `${text.slice(8,10)}/${text.slice(5,7)}/${text.slice(0,4)}`;
  const value=new Date(d); return Number.isNaN(value.getTime())?'—':value.toLocaleDateString('pt-BR');
};

export default function WorkDrivePanel({ work }) {
  const [listing,setListing]=useState({state:'idle',data:null,error:''});
  const [selected,setSelected]=useState(null);
  const [preview,setPreview]=useState({state:'idle',number:null,data:null,error:''});

  useEffect(()=>{setListing({state:'idle',data:null,error:''});setSelected(null);setPreview({state:'idle',number:null,data:null,error:''});},[work?.id]);

  async function loadListing() {
    if(!work?.id || listing.state==='loading') return;
    setListing({state:'loading',data:null,error:''});
    setSelected(null); setPreview({state:'idle',number:null,data:null,error:''});
    try {
      const r=await fetch(`/api/obras/${encodeURIComponent(work.id)}/documentos`,{cache:'no-store'});
      const payload=await r.json();
      if(!r.ok || !payload.ok) throw new Error(payload.error||'Não foi possível consultar o Drive.');
      setListing({state:'ready',data:payload,error:''});
    } catch(e) {setListing({state:'error',data:null,error:e.message||String(e)});}
  }

  async function openMeasurement(numero) {
    const num=Number(numero);
    setSelected(num);
    setPreview({state:'loading',number:num,data:null,error:''});
    try {
      const r=await fetch(`/api/obras/${encodeURIComponent(work.id)}/documentos/${num}`,{cache:'no-store'});
      const payload=await r.json();
      if(!r.ok || !payload.ok) throw new Error(payload.error||'Não foi possível interpretar a PLS.');
      setPreview(prev=>prev.number===num?{state:'ready',number:num,data:payload,error:''}:prev);
    } catch(e){setPreview(prev=>prev.number===num?{state:'error',number:num,data:null,error:e.message||String(e)}:prev);}
  }

  const info=listing.data;
  const selectedFile=info?.medicoes?.find(x=>x.numero===selected);
  const p=preview.data;
  return h('section',{className:'p-card p-drive-card'},
    h('div',{className:'p-card-head p-drive-head'},
      h('div',null,
        h('div',{className:'p-small-label'},'DOCUMENTOS VINCULADOS À OBRA'),
        h('h2',null,'Medições encontradas no Google Drive'),
        h('p',null,'Consulte arquivos existentes e seus dados reais antes da carga histórica no Neon.')),
      h('div',{className:'p-drive-head-actions'},
        info?.obra?.linkPasta ? h('a',{className:'p-btn p-btn-light',href:info.obra.linkPasta,target:'_blank',rel:'noopener noreferrer'},'Abrir pasta ↗') : null,
        h('button',{className:'p-btn',type:'button',onClick:loadListing,disabled:listing.state==='loading'},listing.state==='loading'?'Consultando Drive...':listing.state==='ready'?'Atualizar documentos':'Consultar documentos'))),
    listing.state==='idle' ? h('div',{className:'p-drive-welcome'},
      h('span',{className:'p-drive-illustration','aria-hidden':'true'},'▤'),
      h('div',null,h('strong',null,'Os arquivos da obra estão disponíveis para consulta.'),h('p',null,'Clique em “Consultar documentos” para listar as medições diretamente da pasta desta obra no Drive. Nenhum documento será modificado.'))) : null,
    listing.state==='loading' ? h('p',{className:'p-drive-status','role':'status'},'Localizando as pastas e planilhas da obra. Esta consulta pode levar alguns segundos...') : null,
    listing.state==='error' ? h('div',{className:'p-drive-alert','role':'alert'},h('strong',null,'Não foi possível consultar o Drive'),h('p',null,listing.error),h('button',{type:'button',onClick:loadListing,className:'p-text-action'},'Tentar novamente')) : null,
    info ? h(React.Fragment,null,
      h('div',{className:'p-drive-numbers'},
        h('div',null,h('strong',null,info.resumo.medicoesEncontradas),h('span',null,'medição(ões) identificadas')),
        h('div',null,h('strong',null,info.resumo.arquivosExcel),h('span',null,'arquivos Excel')),
        h('div',null,h('strong',null,info.resumo.necessitaRevisao),h('span',null,'fonte(s) para revisar')),
        h('div',null,h('strong',null,info.resumo.pastasExaminadas),h('span',null,'pastas examinadas'))),
      info.resumo.leituraIncompleta?h('p',{className:'p-drive-alert'},'A busca alcançou o limite de varredura; o resultado pode estar incompleto.') : null,
      info.resumo.lacunas?.length?h('p',{className:'p-drive-notice'},'Numeração sem planilhas identificadas no Drive: ', info.resumo.lacunas.map(mnum).join(', '),'. Isso não confirma que as medições inexistem.') : null,
      info.medicoes?.length ? h('div',{className:'p-drive-layout'},
        h('div',{className:'p-drive-list','aria-label':'Medições no Google Drive'},
          h('div',{className:'p-drive-list-title'},'Selecione uma medição'),
          ...info.medicoes.map(row=>h('button',{
            key:row.numero,type:'button',onClick:()=>openMeasurement(row.numero),
            className:'p-drive-item '+(selected===row.numero?'selected':''),'aria-pressed':selected===row.numero},
              h('div',{className:'p-drive-m'},mnum(row.numero)),
              h('div',{className:'p-drive-item-main'},h('strong',null,row.arquivo),h('small',null,row.pasta||'Pasta não identificada'),
                h('span',{className:'p-drive-item-state '+(row.alertas?.length?'review':'')},row.alertas?.length?'Verificar identificação':'Arquivo candidato')),h('span',{className:'p-drive-chevron'},'›')))),
        h('div',{className:'p-drive-detail'},
          selected == null ? h('div',{className:'p-drive-placeholder'},h('strong',null,'Selecione uma medição'),h('p',null,'As informações do Excel serão lidas sob demanda, sem gravação no banco.')) : null,
          selected != null && preview.state==='loading'?h('p',{className:'p-drive-status','role':'status'},`Lendo ${mnum(selected)} no servidor e conferindo seus dados...`):null,
          selected != null && preview.state==='error'?h('div',{className:'p-drive-alert','role':'alert'},h('strong',null,`Falha na leitura de ${mnum(selected)}`),h('p',null,preview.error),h('button',{className:'p-text-action',onClick:()=>openMeasurement(selected)},'Tentar novamente')):null,
          selected != null && preview.state==='ready' && p ? h(React.Fragment,null,
            h('div',{className:'p-drive-detail-top'},h('div',null,h('span',{className:'p-small-label'},'PRÉVIA DOCUMENTAL · SOMENTE LEITURA'),h('h3',null,`Medição ${mnum(selected)}`)),h('span',{className:'p-drive-validation review'},p.validacaoPreliminar==='APTO'?'Leitura preliminar apta · matriz não homologada':p.validacaoPreliminar)),
            selectedFile?.alertas?.length ? h('p',{className:'p-drive-alert'},'A identificação automática desta fonte requer revisão: ', selectedFile.alertas.join(', '),'.') : null,
            h('div',{className:'p-drive-facts'},
              ...[
                ['Medição no Excel',p.numeroInterno?mnum(p.numeroInterno):'Não identificada'],
                ['Faixa / modelo',p.perfil||'—'],['Aba principal',p.abaPrincipal||'—'],['Eventos encontrados',p.eventos??'—'],
                ['Período',p.periodo||'Não identificado'],['Levantamento',date(p.levantamento)],['Validação temporal',p.temporal||'NAO_AVALIADO'],['Abas no arquivo',(p.abas||[]).length],
              ].map(([name,value])=>h('div',{key:name},h('small',null,name),h('strong',null,value)))),
            p.resumo?h('div',{className:'p-drive-summary'},h('h4',null,'Resumo da medição'),h('div',null,...[
              ['Anterior',percent(p.resumo.anterior)],['No período',percent(p.resumo.periodo)],['Acumulado',percent(p.resumo.acumulado)],
              ['Valor no período',money(p.resumo.valorPeriodo)],['Valor acumulado',money(p.resumo.valorAcumulado)]
            ].map(([name,value])=>h('div',{key:name},h('small',null,name),h('strong',null,value))))) : null,
            p.orcamentos?h('div',{className:'p-drive-summary'},h('h4',null,'Orçamentos identificados'),h('div',null,...[
              ['Habitação',money(p.orcamentos.habitacao)],['Infraestrutura',money(p.orcamentos.infraestrutura)],['Equipamentos',money(p.orcamentos.equipamentos)],['Global',money(p.orcamentos.global)]
            ].map(([name,value])=>h('div',{key:name},h('small',null,name),h('strong',null,value))))) : null,
            p.observacoes?.length ? h('div',{className:'p-drive-warnings'},h('strong',null,'Observações da leitura'),h('ul',null,...p.observacoes.map((str,i)=>h('li',{key:i},str)))) : null,
            p.documentosRelacionados?h('div',{className:'p-ops-pdfs'},
              h('h4',null,`PDFs na pasta selecionada (${p.documentosRelacionados.arquivosPdf})`),
              h('p',null,p.documentosRelacionados.mensagem),
              p.documentosRelacionados.documentos?.length ?
                h('div',{className:'p-ops-pdf-list'},...p.documentosRelacionados.documentos.map(doc=>h('a',{
                  key:doc.id,href:doc.url,target:'_blank',rel:'noopener noreferrer'},'▧  ',doc.nome,' ↗'))) : null
            ):null,
            h('div',{className:'p-drive-detail-actions'}, p.linkArquivo?h('a',{href:p.linkArquivo,target:'_blank',rel:'noopener noreferrer',className:'p-btn p-btn-light'},'Ver Excel no Drive ↗'):null,h('span',null,'Matriz detalhada e importação exigem homologação técnica.')),
          ) : null))
        : h('p',{className:'p-empty'},'Nenhum candidato seguro foi localizado automaticamente nesta obra.'),
      h('p',{className:'p-drive-footnote'},'Consulta independente da migração: arquivos identificados não representam medições aprovadas ou importadas. Aprovações, uploads e envio de e-mails permanecem no sistema atual.')
    ) : null
  );
}
