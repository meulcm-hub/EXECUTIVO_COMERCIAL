import React from 'react';
const h=React.createElement;
const atual='https://script.google.com/a/macros/lcmconstrucao.com.br/s/AKfycbzWwc9NnlJWSHoUywKObUCZjirQyznyZCGyJV7-uJlcUdifcntPFYxZEzKHfBCadxVR/exec';
export default function UploadPage(){return h('main',{className:'shell'},
 h('section',{className:'hero compact'},
  h('span',{className:'badge'},'MIGRAÇÃO EM HOMOLOGAÇÃO'),
  h('h1',null,'Upload oficial no sistema atual'),
  h('p',null,'O novo Portal PLS ainda não recebeu autorização para gravar medições e aprovações. Continue utilizando a plataforma atual para os processos oficiais.'),
  h('div',{className:'actions'},h('a',{className:'button',href:atual,target:'_blank',rel:'noopener noreferrer'},'Abrir Portal PLS atual'),h('a',{className:'button secondary',href:'/'},'Voltar ao novo Portal'))
  ));}
