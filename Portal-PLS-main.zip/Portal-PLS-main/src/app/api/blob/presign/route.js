import { blockedOperationResponse } from '@/lib/pls/operation-guard.js';
import { requireWorkAccess } from '@/lib/authz.js';
import { APP } from '@/lib/config.js';
import { makePrivateUploadUrl, stagingPath } from '@/lib/blob.js';
import { validateUploadMeta } from '@/lib/pls/policies.js';

export const runtime = 'nodejs';

export async function POST(request) {
  return blockedOperationResponse();

  try {
    const body = await request.json();
    const user = await requireWorkAccess(body.obraId);
    validateUploadMeta({ filename: body.filename, size: Number(body.size) });
    const pathname = stagingPath({ uploaderEmail: user.email, filename: body.filename });
    const presignedUrl = await makePrivateUploadUrl({ pathname, contentType: body.contentType || 'application/octet-stream' });
    return Response.json({ ok: true, pathname, presignedUrl, expiresInSeconds: 900, maxBytes: APP.maxUploadBytes });
  } catch (error) {
    return Response.json({ ok: false, error: error.message }, { status: error.status || 400 });
  }
}
