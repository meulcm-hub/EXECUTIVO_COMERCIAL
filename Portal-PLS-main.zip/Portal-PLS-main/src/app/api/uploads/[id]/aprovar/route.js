import { blockedOperationResponse } from '@/lib/pls/operation-guard.js';
import { db, withTx } from '@/lib/db.js';
import { requireApprovalAccess } from '@/lib/authz.js';
import { audit } from '@/lib/audit.js';

export const runtime = 'nodejs';

export async function POST(_request, context) {
  return blockedOperationResponse();

  try {
    const { id } = await context.params;
    const sql = db();
    const rows = await sql`
      select v.id, v.measurement_id, v.vigente, v.status_versao, m.work_id, m.status,
             v.processing_state
        from measurement_versions v
        join measurements m on m.id = v.measurement_id
       where v.id = ${id}
       limit 1
    `;
    const item = rows[0];
    if (!item) throw new Error('Versão da PLS não encontrada.');
    const actor = await requireApprovalAccess(item.work_id);
    if (!item.vigente) throw new Error('Somente a versão vigente pode ser aprovada.');
    if (item.processing_state !== 'PROCESSADO') throw new Error('A PLS ainda não foi processada integralmente pelo novo motor. Aprovação bloqueada durante a migração.');
    if (item.status === 'APROVADA') return Response.json({ ok: true, alreadyApproved: true });

    await withTx(async (tx) => {
      await tx`update measurement_versions set status_versao = 'APROVADA', aprovado_em = now(), aprovado_por = ${actor.email} where id = ${id}`;
      await tx`update measurements set status = 'APROVADA', aprovado_em = now(), aprovado_por = ${actor.email}, updated_at = now() where id = ${item.measurement_id}`;
      await audit(tx, { workId: item.work_id, measurementId: item.measurement_id, uploadId: id, actorEmail: actor.email, action: 'APROVACAO_PLS', detail: {} });
    });
    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ ok: false, error: error.message }, { status: error.status || 400 });
  }
}
