import { blockedOperationResponse } from '@/lib/pls/operation-guard.js';
import { db, withTx } from '@/lib/db.js';
import { requireWorkAccess } from '@/lib/authz.js';
import { readPrivateBlob, deletePrivateBlob } from '@/lib/blob.js';
import { validateUploadMeta } from '@/lib/pls/policies.js';
import { sha256Buffer, sha256Json } from '@/lib/hash.js';
import { inspectWorkbook } from '@/lib/pls/parser.js';
import { getOrCreateMeasurementFolder, uploadBufferToDrive } from '@/lib/google/drive.js';
import { audit } from '@/lib/audit.js';

export const runtime = 'nodejs';
export const maxDuration = 300;

export async function POST(request) {
  return blockedOperationResponse();

  let pathname = '';
  try {
    const body = await request.json();
    pathname = String(body.pathname || '');
    const numero = Math.round(Number(body.numeroMedicao));
    if (!pathname.startsWith('pls-staging/')) throw new Error('Arquivo temporário inválido.');
    if (!Number.isFinite(numero) || numero <= 0) throw new Error('Número da medição inválido.');
    const actor = await requireWorkAccess(body.obraId, ['USUARIO', 'RESPONSAVEL', 'APROVADOR', 'ADMIN']);

    const sql = db();
    const obras = await sql`select * from works where id = ${body.obraId} and ativo = true limit 1`;
    const obra = obras[0];
    if (!obra?.drive_folder_id) throw new Error('Obra sem pasta oficial do Drive vinculada.');

    const temp = await readPrivateBlob(pathname);
    validateUploadMeta({ filename: body.filename, size: temp.buffer.length });
    const shaArquivo = sha256Buffer(temp.buffer);
    const workbook = inspectWorkbook(temp.buffer);
    if (!workbook.hasPls) throw new Error('O Excel não contém aba PLS identificável.');

    const pasta = await getOrCreateMeasurementFolder({
      workFolderId: obra.drive_folder_id,
      numeroMedicao: numero,
      competencia: body.competencia,
    });

    const fileDrive = await uploadBufferToDrive({
      folderId: pasta.id,
      filename: body.filename,
      mimeType: body.contentType,
      buffer: temp.buffer,
    });

    const result = await withTx(async (tx) => {
      const current = await tx`
        select m.id, m.status
          from measurements m
         where m.work_id = ${obra.id} and m.numero = ${numero}
         for update
      `;
      if (current[0]?.status === 'APROVADA') throw new Error('Esta medição está APROVADA e não pode receber nova versão.');

      let measurementId = current[0]?.id;
      if (!measurementId) {
        const inserted = await tx`
          insert into measurements(work_id, numero, competencia, status, criado_por)
          values (${obra.id}, ${numero}, ${body.competencia || null}, 'EM_EXECUCAO', ${actor.email})
          returning id
        `;
        measurementId = inserted[0].id;
      }

      const versionRows = await tx`
        select coalesce(max(versao), 0) as ultima_versao
          from measurement_versions
         where measurement_id = ${measurementId}
      `;
      const versao = Number(versionRows[0]?.ultima_versao || 0) + 1;
      await tx`update measurement_versions set vigente = false, status_versao = 'SUBSTITUIDA' where measurement_id = ${measurementId} and vigente = true`;
      const snapshotInicial = {
        obraId: obra.id,
        numeroMedicao: numero,
        competencia: body.competencia || null,
        sha256Arquivo: shaArquivo,
        abas: workbook.sheetNames,
        parser: 'PENDENTE_PORT_COMPLETO',
      };
      const snapshotHash = sha256Json(snapshotInicial);
      const insertedVersion = await tx`
        insert into measurement_versions(
          measurement_id, versao, vigente, status_versao, arquivo_nome, mime_type, tamanho_bytes,
          drive_file_id, drive_folder_id, drive_url, sha256_arquivo, sha256_snapshot,
          snapshot_json, enviado_por, origem
        ) values (
          ${measurementId}, ${versao}, true, 'EM_EXECUCAO', ${body.filename}, ${body.contentType || null}, ${temp.buffer.length},
          ${fileDrive.id}, ${pasta.id}, ${fileDrive.webViewLink || null}, ${shaArquivo}, ${snapshotHash},
          ${tx.json(snapshotInicial)}, ${actor.email}, 'UPLOAD_EXCEL'
        ) returning id
      `;
      await audit(tx, {
        workId: obra.id,
        measurementId,
        uploadId: insertedVersion[0].id,
        actorEmail: actor.email,
        action: 'UPLOAD_RECEBIDO_NEXT',
        detail: { versao, sha256Arquivo: shaArquivo, pasta: pasta.name, abas: workbook.sheetNames },
      });
      return { measurementId, versionId: insertedVersion[0].id, versao, snapshotHash };
    });

    await deletePrivateBlob(pathname).catch(() => {});
    return Response.json({
      ok: true,
      ...result,
      medicao: numero,
      sha256Arquivo: shaArquivo,
      driveFileId: fileDrive.id,
      driveFolder: pasta,
      abas: workbook.sheetNames,
      processingState: 'AGUARDANDO_PORT_DO_PARSER_PLS',
      mensagem: 'Arquivo recebido com sucesso no novo backend. A leitura completa das fórmulas PLS será ativada na próxima etapa da migração.',
    });
  } catch (error) {
    return Response.json({ ok: false, error: error.message }, { status: error.status || 400 });
  }
}
