import crypto from 'node:crypto';
import { get, put, del } from '@vercel/blob';
import { db } from '@/lib/db.js';
import { requireGlobalAdmin } from '@/lib/authz.js';
import { inspectWorkbook } from '@/lib/pls/parser.js';
import { isLabConfigured, validateLabFiles, sha256, labPath, LAB_MAX_TOTAL_BYTES } from '@/lib/pls/lab-upload.js';

export const runtime='nodejs';
export const dynamic='force-dynamic';
export const maxDuration=60;
const headers={'Cache-Control':'private, no-store, max-age=0'};
function resp(body,status=200) {return Response.json(body,{status,headers});}

export async function GET() {
  try {
    await requireGlobalAdmin();
    return resp({ok:true,version:'NEXT-0.8B',labConfigured:isLabConfigured(),maxTotalBytes:LAB_MAX_TOTAL_BYTES,
      driveWritesEnabled:false,neonWritesEnabled:false,officialUploadsEnabled:false});
  } catch(e) {return resp({ok:false,error:e?.status===401?'Faça login novamente.':e?.status===403?'Acesso restrito a administradores.':'Falha de autenticação.'},e?.status||500);}
}

export async function POST(request) {
  let objects=[];
  let deleteFailures=[];
  let uploadSucceeded=false;
  let result=null;
  let status=200;
  try {
    // 0.8B: esta chave autoriza somente arquivos sintéticos na Private Blob Store separada.
    // Nunca remover o bloqueio nos endpoints de produção como parte do laboratório.
    await requireGlobalAdmin();
    // Não aceitar submissões cross-origin mesmo com cookie autenticado.
    const origin=request.headers.get('origin');
    if (!origin || origin !== new URL(request.url).origin) return resp({ok:false,error:'Origem da solicitação não autorizada.'},403);
    if (!isLabConfigured()) return resp({ok:false,code:'LAB_DESATIVADO',error:'Laboratório desativado. Configure exclusivamente o armazenamento privado de testes.'},423);
    const sizeHeader=Number(request.headers.get('content-length'));
    if (sizeHeader && sizeHeader > LAB_MAX_TOTAL_BYTES + 256*1024) return resp({ok:false,error:'Solicitação excede o limite do laboratório.'},413);
    if (!(request.headers.get('content-type')||'').includes('multipart/form-data')) return resp({ok:false,error:'Formulário de upload inválido.'},415);
    const form=await request.formData();
    const workId=String(form.get('obraId')||'');
    const numero=Number(form.get('numero'));
    if (!/^[0-9a-f]{8}-[0-9a-f-]{27,}$/i.test(workId)) throw Object.assign(new Error('Obra inválida.'),{status:400});
    const workbookFile=form.get('excel');
    const pdfFile=form.get('pdf');
    if (!workbookFile || typeof workbookFile.arrayBuffer !== 'function') throw Object.assign(new Error('Selecione um Excel de teste.'),{status:400});
    const excel={name:String(workbookFile.name||''),buffer:Buffer.from(await workbookFile.arrayBuffer())};
    const pdf=pdfFile && typeof pdfFile.arrayBuffer==='function' && Number(pdfFile.size)>0
      ? {name:String(pdfFile.name||''),buffer:Buffer.from(await pdfFile.arrayBuffer())}:null;
    validateLabFiles({numero,excel,pdf});
    const sql=db();
    const works=await sql`select id,nome,codigo from works where id=${workId} and ativo=true limit 1`;
    if(!works[0]) throw Object.assign(new Error('Obra não encontrada.'),{status:404});
    const approved=await sql`select id from measurements where work_id=${workId} and numero=${numero} and (status='APROVADA' or aprovado_em is not null) limit 1`;
    if (approved.length) throw Object.assign(new Error('Medição aprovada: não pode participar do teste de envio.'),{status:409});
    // A inspeção é intencionalmente limitada: não homologa matrizes, período ou PDF.
    const inspected=inspectWorkbook(excel.buffer);
    const filePairs=[{kind:'excel',file:excel,contentType:'application/octet-stream'},...(pdf?[{kind:'pdf',file:pdf,contentType:'application/pdf'}]:[])];
    const labId=crypto.randomUUID();
    const token=process.env.PLS_LAB_BLOB_TOKEN;
    const receipts=[];
    for (const item of filePairs) {
      const pathname=labPath({labId,kind:item.kind,filename:item.file.name});
      // Registrar o pathname antes do upload para tentar limpeza mesmo em falhas intermediárias.
      objects.push(pathname);
      await put(pathname,item.file.buffer,{access:'private',token,contentType:item.contentType,addRandomSuffix:false});
      const response=await get(pathname,{access:'private',token,useCache:false});
      if (!response?.stream) throw new Error('Não foi possível reler o arquivo de teste no armazenamento privado.');
      let chunks=[],size=0;
      for await(const chunk of response.stream){const b=Buffer.from(chunk);size+=b.length;if(size>LAB_MAX_TOTAL_BYTES)throw new Error('Leitura do arquivo excedeu o limite.');chunks.push(b);}
      const original=sha256(item.file.buffer);
      const saved=sha256(Buffer.concat(chunks));
      if (saved!==original) throw new Error('Falha na conferência SHA-256 do arquivo recuperado.');
      receipts.push({tipo:item.kind,arquivo:item.file.name,tamanhoBytes:item.file.buffer.length,sha256:original,integridade:'CONFIRMADA'});
    }
    uploadSucceeded=true;
    result={ok:true,version:'NEXT-0.8B',labId,work:{codigo:works[0].codigo,nome:works[0].nome},numero,
      planilha:{abas:inspected.sheetNames,haAbaPls:inspected.hasPls},arquivos:receipts,
      armazenamento:'BLOB_PRIVADO_ISOLADO',neonWrites:false,driveWrites:false,emailsSent:false,approvalEnabled:false};
  }catch(e){
    status=e?.status||400;
    result={ok:false,code:'LAB_TESTE_NAO_CONCLUIDO',error:e?.status?e.message:'Não foi possível concluir o teste de envio privado. Verifique a configuração e os logs.',
      driveWrites:false,neonWrites:false};
  }finally{
    if(objects.length){
      const token=process.env.PLS_LAB_BLOB_TOKEN;
      for(const pathname of objects){try{await del(pathname,{token});}catch{deleteFailures.push(pathname);}}
    }
  }
  // Se a limpeza falhou, não afirmar que os arquivos foram descartados.
  if(deleteFailures.length){
    return resp({ok:false,code:'LAB_LIMPEZA_PENDENTE',error:'Envio de teste realizado, mas a limpeza automática não foi concluída. Verifique o prefixo lcm-pls-lab-08b/ na Private Blob Store.',
      uploadsConferidos:uploadSucceeded,quantidadeParaLimpeza:deleteFailures.length,driveWrites:false,neonWrites:false},500);
  }
  if(uploadSucceeded)result.arquivosDescartados=true;
  return resp(result,status);
}
