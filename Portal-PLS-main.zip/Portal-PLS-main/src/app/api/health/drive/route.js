import { requireUser } from '@/lib/authz.js';
import { discoverRootWorks } from '@/lib/work-sync.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const user = await requireUser();
    const result = await discoverRootWorks();
    return Response.json({
      ok: true,
      drive: 'connected',
      user: user.email,
      rootFolderReadable: true,
      childFolders: result.folders.length,
      workFolders: result.works.length,
      ignoredFolders: result.ignored,
      duplicateCodes: result.duplicateCodes,
      sampleWorks: result.works.slice(0, 12),
    });
  } catch (error) {
    return Response.json({ ok: false, drive: 'error', error: error.message }, { status: error.status || 503 });
  }
}
