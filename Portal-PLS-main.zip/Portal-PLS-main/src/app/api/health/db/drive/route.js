import { requireUser } from '@/lib/authz.js';
import { requireEnv } from '@/lib/config.js';
import { listChildFolders } from '@/lib/google/drive.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const user = await requireUser();

    const rootFolderId = requireEnv(
      'GOOGLE_DRIVE_PLS_ROOT_FOLDER_ID'
    );

    const folders = await listChildFolders(rootFolderId);

    const obra238 = folders.find((folder) => {
      const nome = String(folder.name || '').toUpperCase();
      return /\b238\b/.test(nome);
    });

    return Response.json({
      ok: true,
      drive: 'connected',
      user: user.email,
      rootFolderReadable: true,
      childFolders: folders.length,
      obra238: obra238
        ? {
            found: true,
            name: obra238.name,
          }
        : {
            found: false,
          },
      sampleFolders: folders
        .slice(0, 10)
        .map((folder) => folder.name),
    });
  } catch (error) {
    console.error('Drive health check failed', error);

    return Response.json(
      {
        ok: false,
        drive: 'error',
        error:
          error?.message ||
          'Falha ao conectar ao Google Drive.',
      },
      { status: 503 }
    );
  }
}
