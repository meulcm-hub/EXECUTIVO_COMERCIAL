import { db } from '@/lib/db.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const BASE_TABLES = [
  'app_users', 'works', 'work_access', 'measurements', 'measurement_versions',
  'measurement_events', 'audit_events', 'notification_outbox',
];
const CATALOG_COLUMNS = [
  'drive_name', 'drive_parent_id', 'source', 'drive_last_seen_at',
  'folder_strategy', 'parser_profile', 'sync_state', 'legacy_id',
];

export async function GET() {
  try {
    const sql = db();
    const tables = await sql`
      select table_name from information_schema.tables
       where table_schema = 'public'
    `;
    const columns = await sql`
      select column_name from information_schema.columns
       where table_schema = 'public' and table_name = 'works'
    `;
    const tableSet = new Set(tables.map((x) => x.table_name));
    const columnSet = new Set(columns.map((x) => x.column_name));
    const missingBase = BASE_TABLES.filter((x) => !tableSet.has(x));
    const missingCatalogColumns = CATALOG_COLUMNS.filter((x) => !columnSet.has(x));
    const catalogTableOk = tableSet.has('drive_sync_runs');
    const [{ now }] = await sql`select now() as now`;
    return Response.json({
      ok: missingBase.length === 0,
      app: 'Portal PLS LCM',
      version: 'NEXT-0.2',
      database: 'connected',
      baseSchema: { ok: missingBase.length === 0, missing: missingBase },
      catalogSchema: {
        ok: missingCatalogColumns.length === 0 && catalogTableOk,
        missingWorkColumns: missingCatalogColumns,
        driveSyncRuns: catalogTableOk,
      },
      deferredDomainSchema: 'sql/004_domain_schema_v2_DEFERRED.sql — NÃO EXECUTAR AINDA',
      databaseTime: now,
    }, { status: missingBase.length === 0 ? 200 : 503 });
  } catch (error) {
    return Response.json({ ok: false, database: 'error', error: error.message }, { status: 503 });
  }
}
