export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  return Response.json({ ok: true, app: 'Portal PLS LCM', version: 'NEXT-0.8B', operationalWritesEnabled: false, now: new Date().toISOString() });
}
