import { getSession } from '@/lib/session.js';
import { getUserContext } from '@/lib/authz.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  const session = await getSession();
  if (!session) return Response.json({ authenticated: false, user: null, profile: null });
  const profile = await getUserContext(session.email);
  return Response.json({
    authenticated: true,
    user: session,
    profile: profile ? {
      email: profile.email,
      nome: profile.nome,
      perfilGlobal: profile.perfil_global,
      ativo: profile.ativo,
    } : null,
  });
}
