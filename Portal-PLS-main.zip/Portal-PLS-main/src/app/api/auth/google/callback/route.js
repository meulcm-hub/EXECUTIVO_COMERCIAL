import { OAuth2Client } from 'google-auth-library';
import { cookies } from 'next/headers';
import { APP, requireEnv } from '@/lib/config.js';
import { makeSessionToken, setSessionCookie } from '@/lib/session.js';
import { db } from '@/lib/db.js';

export const runtime = 'nodejs';

export async function GET(request) {
  const url = new URL(request.url);
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  const jar = await cookies();
  const expectedState = jar.get('pls_oauth_state')?.value;
  jar.set('pls_oauth_state', '', { path: '/', maxAge: 0 });
  if (!code || !state || !expectedState || state !== expectedState) return new Response('OAuth state inválido.', { status: 400 });

  const redirectUri = `${requireEnv('APP_URL').replace(/\/$/, '')}/api/auth/google/callback`;
  const client = new OAuth2Client(requireEnv('GOOGLE_LOGIN_CLIENT_ID'), requireEnv('GOOGLE_LOGIN_CLIENT_SECRET'), redirectUri);
  const { tokens } = await client.getToken(code);
  const ticket = await client.verifyIdToken({ idToken: tokens.id_token, audience: requireEnv('GOOGLE_LOGIN_CLIENT_ID') });
  const payload = ticket.getPayload();
  const email = String(payload?.email || '').toLowerCase();
  if (!payload?.email_verified || payload?.hd !== APP.allowedDomain || !email.endsWith(`@${APP.allowedDomain}`)) {
    return new Response('Conta não autorizada para o Portal PLS.', { status: 403 });
  }

  const sql = db();
  const admins = String(process.env.BOOTSTRAP_ADMIN_EMAILS || '').toLowerCase().split(',').map((x) => x.trim()).filter(Boolean);
  const perfil = admins.includes(email) ? 'ADMIN' : 'USUARIO';
  await sql`
    insert into app_users(email, nome, perfil_global, ativo)
    values (${email}, ${payload?.name || email}, ${perfil}, true)
    on conflict (email) do update set nome = excluded.nome, updated_at = now()
  `;

  await setSessionCookie(makeSessionToken({ email, name: payload?.name || '', picture: payload?.picture || '' }));
  return Response.redirect(`${requireEnv('APP_URL').replace(/\/$/, '')}/`);
}
