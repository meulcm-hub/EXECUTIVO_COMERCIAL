import crypto from 'node:crypto';
import { cookies } from 'next/headers';
import { requireEnv, APP } from '@/lib/config.js';

export const runtime = 'nodejs';

export async function GET() {
  const state = crypto.randomBytes(24).toString('base64url');
  const jar = await cookies();
  jar.set('pls_oauth_state', state, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', path: '/', maxAge: 600 });
  const redirectUri = `${requireEnv('APP_URL').replace(/\/$/, '')}/api/auth/google/callback`;
  const params = new URLSearchParams({
    client_id: requireEnv('GOOGLE_LOGIN_CLIENT_ID'),
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: 'openid email profile',
    access_type: 'online',
    include_granted_scopes: 'true',
    prompt: 'select_account',
    state,
    hd: APP.allowedDomain,
  });
  return Response.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params}`);
}
