import { requireGlobalAdmin } from '@/lib/authz.js';
import { db } from '@/lib/db.js';
import { isLabConfigured } from '@/lib/pls/lab-upload.js';

export const runtime='nodejs';
export const dynamic='force-dynamic';
const headers={'Cache-Control':'private, no-store, max-age=0'};
const requiredTables=['works','app_users','work_access','measurements','measurement_versions','measurement_events','audit_events','notification_outbox'];

export async function GET() {
  try {
    await requireGlobalAdmin();
    const sql=db();
    const tables=await sql`select table_name from information_schema.tables where table_schema='public' and table_name in ('works','app_users','work_access','measurements','measurement_versions','measurement_events','audit_events','notification_outbox')`;
    const found=new Set(tables.map(t=>t.table_name));
    const missing=requiredTables.filter(t=>!found.has(t));
    const indexes=await sql`select indexname from pg_indexes where schemaname='public' and indexname='ux_measurement_one_current_version'`;
    const status=await sql`
      select (select count(*)::integer from works where ativo=true) as obras_ativas,
             (select count(*)::integer from measurements) as medicoes_no_neon,
             (select count(*)::integer from measurements where status='APROVADA') as medicoes_aprovadas,
             (select count(*)::integer from measurement_versions) as versoes_registradas,
             (select count(*)::integer from notification_outbox where status in ('PENDENTE','ERRO')) as emails_pendentes
    `;
    const readReady=missing.length===0&&indexes.length>0;
    return Response.json({
      ok:true,version:'NEXT-0.8B',onlyRead:true,operationalWritesEnabled:false,
      database:{readReady,missingTables:missing,currentVersionUniqueIndex:indexes.length>0,...status[0]},
      phases:[
        {name:'Consulta de obras e documentação',state:'DISPONIVEL'},
        {name:'Histórico e auditoria do Neon',state:readReady?'DISPONIVEL':'REVISAR_ESTRUTURA'},
        {name:'Validação integral de Excel/PDF',state:'EM_HOMOLOGACAO'},
        {name:'Laboratório privado de upload (sem gravações oficiais)',state:isLabConfigured()?'CONFIGURADO_PARA_TESTE':'DESATIVADO'},
        {name:'Upload oficial com versionamento',state:'BLOQUEADO'},
        {name:'Aprovação definitiva e assinatura',state:'BLOQUEADO'},
        {name:'E-mails e importação histórica',state:'BLOQUEADO'},
      ],
      message:'Nenhuma medição ou arquivo é criado neste endpoint; o Apps Script permanece como sistema operacional oficial.'
    },{headers});
  }catch(e){
    return Response.json({ok:false,error:e?.status===401?'Sessão expirada.':e?.status===403?'Acesso restrito ao administrador.':'Não foi possível verificar a prontidão do banco.'},{status:e?.status||500,headers});
  }
}
