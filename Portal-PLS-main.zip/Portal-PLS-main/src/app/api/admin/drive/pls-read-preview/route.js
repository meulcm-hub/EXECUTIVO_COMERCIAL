import { requireGlobalAdmin } from '@/lib/authz.js';
import { db } from '@/lib/db.js';
import { inventoryPlsFilesForWork } from '@/lib/pls/drive-inventory.js';
import { readPlsWorkbookPreview } from '@/lib/pls/server-reader.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 120;

export async function GET(request) {
  try {
    await requireGlobalAdmin();
    const url = new URL(request.url);
    const workId = String(url.searchParams.get('workId') || '').trim();
    const requestedMeasurement = Math.max(0, Math.round(Number(url.searchParams.get('measurement') || 0)));
    if (!workId) return Response.json({ ok: false, error: 'workId é obrigatório.' }, { status: 400 });

    const sql = db();
    const rows = await sql`
      select id, codigo, nome, faixa_pls, drive_folder_id, drive_name
        from works
       where id = ${workId} and ativo = true
       limit 1
    `;
    const work = rows[0];
    if (!work) return Response.json({ ok: false, error: 'Obra não encontrada.' }, { status: 404 });

    const siblings = await sql`
      select id, nome
        from works
       where codigo = ${work.codigo} and ativo = true
    `;

    const inventory = await inventoryPlsFilesForWork(work, { siblingWorks: siblings });
    const measurement = requestedMeasurement || Math.max(0, ...(inventory.preferredMeasurements || []));
    if (!measurement) {
      return Response.json({ ok: false, error: 'Nenhuma medição possui arquivo candidato seguro para leitura.' }, { status: 409 });
    }

    const file = (inventory.preferredPerMeasurement || []).find((x) => Number(x.numeroMedicao) === measurement);
    if (!file) {
      return Response.json({
        ok: false,
        error: `A M${String(measurement).padStart(2, '0')} não possui candidato seguro automático. Revise os arquivos sinalizados na auditoria.`,
      }, { status: 409 });
    }

    const reviewGroup = (inventory.reviewCandidatesPerMeasurement || [])
      .find((x) => Number(x.numeroMedicao) === measurement);
    const candidateReviewRequired = Boolean(reviewGroup?.candidatos?.length > 1);

    const preview = await readPlsWorkbookPreview({
      work,
      file,
      selection: {
        candidateReviewRequired,
        candidateAlternatives: reviewGroup?.candidatos || [],
      },
    });
    return Response.json({
      ok: true,
      work: inventory.work,
      selectedMeasurement: measurement,
      selectedFileReason: preview?.candidateComparison?.allIdentical
        ? 'CANDIDATOS_DUPLICADOS_BYTE_A_BYTE_IDENTICOS'
        : (candidateReviewRequired ? 'CANDIDATO_ESCOLHIDO_PARA_PREVIA_MAS_REQUER_REVISAO' : 'CANDIDATO_SEGURO_MELHOR_PONTUADO'),
      preview,
    });
  } catch (error) {
    return Response.json({ ok: false, error: error.message || String(error) }, { status: error.status || 500 });
  }
}
