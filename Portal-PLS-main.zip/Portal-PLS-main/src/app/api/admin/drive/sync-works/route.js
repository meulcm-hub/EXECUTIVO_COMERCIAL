import { requireGlobalAdmin } from '@/lib/authz.js';
import { commitWorkSync, previewWorkSync } from '@/lib/work-sync.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 120;

export async function GET() {
  try {
    await requireGlobalAdmin();
    const result = await previewWorkSync();
    return Response.json({
      ok: true,
      mode: 'PREVIEW',
      discovered: result.works.length,
      ignored: result.ignored,
      duplicateCodes: result.duplicateCodes,
      items: result.preview,
      warning: 'Prévia somente leitura. Nenhum arquivo ou pasta do Drive foi alterado.',
    });
  } catch (error) {
    return Response.json({ ok: false, error: error.message }, { status: error.status || 500 });
  }
}

export async function POST(request) {
  try {
    const actor = await requireGlobalAdmin();
    const body = await request.json().catch(() => ({}));
    if (body.confirm !== true) {
      return Response.json({ ok: false, error: 'Confirmação obrigatória: envie confirm=true.' }, { status: 400 });
    }
    const result = await commitWorkSync(actor.email);
    return Response.json({
      ok: true,
      mode: 'COMMIT',
      discovered: result.works.length,
      duplicateCodes: result.duplicateCodes,
      summary: result.summary,
      warning: 'A sincronização altera somente o PostgreSQL. Nenhuma pasta/arquivo do Drive é movido, criado ou excluído.',
    });
  } catch (error) {
    return Response.json({ ok: false, error: error.message }, { status: error.status || 500 });
  }
}
