import { requireGlobalAdmin } from '@/lib/authz.js';
import { db } from '@/lib/db.js';
import { inventoryPlsFilesForWork } from '@/lib/pls/drive-inventory.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 120;

export async function GET(request) {
  try {
    await requireGlobalAdmin();
    const url = new URL(request.url);
    const workId = String(url.searchParams.get('workId') || '').trim();
    if (!workId) return Response.json({ ok: false, error: 'workId é obrigatório.' }, { status: 400 });

    const sql = db();
    const rows = await sql`
      select id, codigo, nome, faixa_pls, drive_folder_id, drive_name
        from works
       where id = ${workId} and ativo = true
       limit 1
    `;
    const work = rows[0];
    if (!work) return Response.json({ ok: false, error: 'Obra não encontrada.' }, { status: 404 });

    const siblings = await sql`
      select id, nome
        from works
       where codigo = ${work.codigo} and ativo = true
    `;

    const inventory = await inventoryPlsFilesForWork(work, { siblingWorks: siblings });
    return Response.json({ ok: true, ...inventory });
  } catch (error) {
    return Response.json({ ok: false, error: error.message }, { status: error.status || 500 });
  }
}
