import { requireGlobalAdmin } from '@/lib/authz.js';
import { db } from '@/lib/db.js';
import { inventoryPlsFilesForWork } from '@/lib/pls/drive-inventory.js';
import { readPlsWorkbookPreview } from '@/lib/pls/server-reader.js';
import { buildMigrationPreviewRecord } from '@/lib/pls/migration-preview.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 120;

function normalizeMeasurements(value) {
  const list = Array.isArray(value) ? value : [];
  return [...new Set(list.map((x) => Math.round(Number(x))).filter((x) => Number.isInteger(x) && x > 0))].slice(0, 2);
}

function dbStateMap(rows) {
  const map = new Map();
  for (const row of rows || []) {
    const key = Number(row.numero);
    if (!map.has(key)) {
      map.set(key, {
        measurementId: row.measurement_id,
        measurementStatus: row.measurement_status,
        versions: [],
      });
    }
    if (row.version_id) {
      map.get(key).versions.push({
        id: row.version_id,
        versao: Number(row.versao || 0),
        vigente: Boolean(row.vigente),
        status_versao: row.status_versao,
        sha256_arquivo: row.sha256_arquivo,
        arquivo_nome: row.arquivo_nome,
        drive_file_id: row.drive_file_id,
      });
    }
  }
  return map;
}

export async function POST(request) {
  try {
    await requireGlobalAdmin();
    const body = await request.json().catch(() => ({}));
    const workId = String(body.workId || '').trim();
    const measurements = normalizeMeasurements(body.measurements);
    if (!workId) return Response.json({ ok: false, error: 'workId é obrigatório.' }, { status: 400 });
    if (!measurements.length) return Response.json({ ok: false, error: 'Informe de 1 a 2 medições para a prévia.' }, { status: 400 });

    const sql = db();
    const rows = await sql`
      select id, codigo, nome, faixa_pls, drive_folder_id, drive_name
        from works
       where id = ${workId} and ativo = true
       limit 1
    `;
    const work = rows[0];
    if (!work) return Response.json({ ok: false, error: 'Obra não encontrada.' }, { status: 404 });

    const siblings = await sql`
      select id, nome
        from works
       where codigo = ${work.codigo} and ativo = true
    `;

    const inventory = await inventoryPlsFilesForWork(work, { siblingWorks: siblings });
    const dbRows = await sql`
      select
        m.numero,
        m.id as measurement_id,
        m.status as measurement_status,
        mv.id as version_id,
        mv.versao,
        mv.vigente,
        mv.status_versao,
        mv.sha256_arquivo,
        mv.arquivo_nome,
        mv.drive_file_id
      from measurements m
      left join measurement_versions mv on mv.measurement_id = m.id
      where m.work_id = ${workId}
      order by m.numero, mv.versao
    `;
    const dbStates = dbStateMap(dbRows);

    const records = [];
    for (const measurement of measurements) {
      const file = (inventory.preferredPerMeasurement || []).find((x) => Number(x.numeroMedicao) === Number(measurement));
      if (!file) {
        records.push({
          measurement,
          error: `M${String(measurement).padStart(2, '0')} não possui candidato seguro automático.`,
          proposedAction: 'NAO_IMPORTAR',
          readOnly: true,
        });
        continue;
      }

      const reviewGroup = (inventory.reviewCandidatesPerMeasurement || [])
        .find((x) => Number(x.numeroMedicao) === Number(measurement));
      const candidateReviewRequired = Boolean(reviewGroup?.candidatos?.length > 1);

      try {
        const preview = await readPlsWorkbookPreview({
          work,
          file,
          selection: {
            candidateReviewRequired,
            candidateAlternatives: reviewGroup?.candidatos || [],
          },
        });
        const selectedFileReason = preview?.candidateComparison?.allIdentical
          ? 'CANDIDATOS_DUPLICADOS_BYTE_A_BYTE_IDENTICOS'
          : (candidateReviewRequired ? 'CANDIDATO_ESCOLHIDO_PARA_PREVIA_MAS_REQUER_REVISAO' : 'CANDIDATO_SEGURO_MELHOR_PONTUADO');
        records.push(buildMigrationPreviewRecord({
          work,
          measurement,
          selectedFileReason,
          preview,
          dbState: dbStates.get(Number(measurement)) || {},
        }));
      } catch (error) {
        records.push({
          measurement,
          error: error?.message || String(error),
          proposedAction: 'NAO_IMPORTAR',
          readOnly: true,
        });
      }
    }

    return Response.json({
      ok: true,
      readOnly: true,
      work: inventory.work,
      requestedMeasurements: measurements,
      records,
      warning: 'Prévia histórica somente leitura. Nenhuma medição, versão ou evento é gravado no PostgreSQL e nenhum arquivo é alterado no Google Drive.',
    });
  } catch (error) {
    return Response.json({ ok: false, error: error?.message || String(error) }, { status: error?.status || 500 });
  }
}
