import { requireGlobalAdmin } from '@/lib/authz.js';
import { db } from '@/lib/db.js';
import { inventoryPlsFilesForWork } from '@/lib/pls/drive-inventory.js';
import { readPlsWorkbookPreview } from '@/lib/pls/server-reader.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 120;

const LIMIT_EVENT_SAMPLE = 12;

function proposedOperation({ preview, existingVersions, measurement }) {
  const matchSha = existingVersions.find((x) => String(x.sha256_arquivo || '').toLowerCase() === String(preview.file.sha256).toLowerCase());
  if (matchSha) return 'JA_EXISTE_MESMO_SHA';
  if (!preview.validation?.importAllowed) return 'NAO_IMPORTAR_VALIDACAO';
  if (!preview.eventPayload || preview.eventPayload.status !== 'PAYLOAD_PRONTO_PARA_CONFERENCIA') return 'REVISAR_MAPEAMENTO_EVENTOS';
  if (measurement?.status === 'APROVADA') return 'NAO_IMPORTAR_APROVADA';
  return 'PAYLOAD_PRONTO_SEM_GRAVAR';
}

function buildRowsPreview(work, measurementNo, preview) {
  const p = preview.parsed;
  const f = preview.file;
  const ev = preview.eventPayload;
  const validation = preview.validation;
  const status = validation?.status || 'NAO_AVALIADO';
  const parentFolderId = f.parentFolderId || null;
  // Identificadores da fonte/medição/versão serão resolvidos por SELECT na futura transação;
  // não se inventam UUIDs nem se escreve no banco nesta versão.
  return {
    measurement_source_files: {
      work_id: work.id,
      detected_measurement: measurementNo,
      folder_measurement: Number(f.measurementFromFolder || 0) || null,
      filename_measurement: Number(f.measurementFromFilename || 0) || null,
      internal_measurement: Number(p.internalMeasurementNumber || 0) || null,
      drive_file_id: f.driveFileId,
      drive_parent_id: parentFolderId,
      measurement_folder_name: f.measurementFolderName || null,
      arquivo_nome: f.name,
      source_path: f.path || null,
      mime_type: f.mimeType || null,
      tamanho_bytes: Number(f.sizeBytes || 0) || null,
      drive_modified_at: f.modifiedTime || null,
      source_role: f.role || null,
      path_classification: f.pathClassification || null,
      parser_profile: p.parserProfile,
      sha256_arquivo: f.sha256,
      period_reference_raw: p.periodReference || null,
      survey_date: p.surveyDate || null,
      validation_status: status,
      validation_reasons: validation?.reasons || [],
      temporal_validation_status: preview.temporalValidation?.status || 'NAO_AVALIADO',
      is_selected_source: false, // não se declara fonte oficial antes da conciliação/autorização
    },
    measurements: {
      work_id: work.id,
      numero: measurementNo,
      competencia: p.periodEnd ? p.periodEnd.slice(0, 7) : null,
      periodo_inicio: p.periodStart || null,
      periodo_fim: p.periodEnd || null,
      data_levantamento: p.surveyDate || null,
      status: 'EM_EXECUCAO', // não inferir APROVADA de um arquivo legado
      engine: work.faixa_pls,
      faixa_pls_snapshot: work.faixa_pls,
      criado_por: '__IDENTIDADE_DA_MIGRACAO_A_DEFINIR__',
    },
    measurement_versions: {
      measurement_id: null, // resolver por (work_id, numero) na futura transação
      source_file_id: null, // resolver por drive_file_id em measurement_source_files
      versao: null, // calcular sob lock, jamais em preview
      vigente: null, // decidir na transação a partir do estado do banco
      status_versao: 'EM_EXECUCAO', // não presumir aprovação histórica
      processing_state: 'PROCESSADO',
      arquivo_nome: f.name,
      mime_type: f.mimeType || null,
      tamanho_bytes: Number(f.sizeBytes || 0) || null,
      drive_file_id: f.driveFileId,
      drive_folder_id: parentFolderId, // obrigatório no schema; nulo é impedimento até resolver ID
      sha256_arquivo: f.sha256,
      sha256_snapshot: null, // hash de snapshot operacional distinto do fingerprint estrutural
      parser_profile: p.parserProfile,
      source_filename: f.name,
      source_path: f.path || null,
      source_parent_folder_id: parentFolderId,
      source_measurement_folder_name: f.measurementFolderName || null,
      internal_measurement_number: p.internalMeasurementNumber || null,
      period_reference_raw: p.periodReference || null,
      validation_status: status,
      validation_reasons: validation?.reasons || [],
      temporal_validation_status: preview.temporalValidation?.status || 'NAO_AVALIADO',
      candidate_resolution: preview.candidateComparison?.allIdentical ? 'DUPLICADOS_IDENTICOS_SHA256' : (validation.candidateReviewRequired ? 'REVISAR' : 'UNICO'),
      structure_sha256: ev.structureSha256,
      structure_snapshot_json: ev.structureSnapshot,
      snapshot_json: { summary: p.summary || null, budgets: p.budgets || null, eventCount: ev.mappedEventCount },
      origem: 'MIGRACAO_HISTORICA',
      enviado_por: '__IDENTIDADE_DA_MIGRACAO_A_DEFINIR__',
    },
    measurement_events: {
      total: ev.eventRecords.length,
      sample: ev.eventRecords.slice(0, LIMIT_EVENT_SAMPLE),
      sampleLimit: LIMIT_EVENT_SAMPLE,
      fullPayloadCreatedInMemory: true,
    },
  };
}

export async function POST(request) {
  try {
    await requireGlobalAdmin();
    const input = await request.json().catch(() => ({}));
    const workId = String(input.workId || '').trim();
    const measurementNo = Number(input.measurement);
    if (!/^[a-f0-9]{8}-[a-f0-9-]{27,}$/i.test(workId) || !Number.isInteger(measurementNo) || measurementNo < 1 || measurementNo > 9999) {
      return Response.json({ ok: false, error: 'Obra e número da medição inválidos.' }, { status: 400 });
    }
    const sql = db();
    const works = await sql`select id, codigo, nome, faixa_pls, drive_folder_id, drive_name from works where id = ${workId} and ativo = true limit 1`;
    const work = works[0];
    if (!work) return Response.json({ ok: false, error: 'Obra não encontrada.' }, { status: 404 });
    const siblings = await sql`select id, nome from works where codigo = ${work.codigo} and ativo = true`;
    const inventory = await inventoryPlsFilesForWork(work, { siblingWorks: siblings });
    const file = (inventory.preferredPerMeasurement || []).find((x) => Number(x.numeroMedicao) === measurementNo);
    if (!file) return Response.json({ ok: false, error: 'Medição sem candidato seguro para leitura. Nada foi importado.' }, { status: 409 });
    const alternatives = (inventory.reviewCandidatesPerMeasurement || []).find((x) => Number(x.numeroMedicao) === measurementNo)?.candidatos || [];
    const preview = await readPlsWorkbookPreview({
      work, file, includeEventPayload: true,
      selection: { candidateReviewRequired: alternatives.length > 1, candidateAlternatives: alternatives },
    });
    const measurementRows = await sql`select id, status from measurements where work_id = ${workId} and numero = ${measurementNo} limit 1`;
    const measurement = measurementRows[0] || null;
    const existingVersions = measurement ? await sql`
      select id, versao, sha256_arquivo, vigente, status_versao from measurement_versions
       where measurement_id = ${measurement.id} order by versao
    ` : [];
    const shaRows = await sql`select id, work_id, drive_file_id from measurement_source_files where drive_file_id = ${preview.file.driveFileId} limit 1`;
    const payload = buildRowsPreview(work, measurementNo, preview);
    const proposedAction = shaRows[0] && shaRows[0].work_id !== work.id
      ? 'NAO_IMPORTAR_CONFLITO_FONTE_OUTRA_OBRA'
      : proposedOperation({ preview, existingVersions, measurement });
    const missingRequired = [];
    if (!payload.measurement_versions.drive_folder_id) missingRequired.push('measurement_versions.drive_folder_id: ID da pasta da medição não conhecido');
    if (!payload.measurement_versions.mime_type) missingRequired.push('measurement_versions.mime_type: tipo não identificado');
    if (preview.eventPayload.status !== 'PAYLOAD_PRONTO_PARA_CONFERENCIA') missingRequired.push('Mapeamento dos eventos precisa de homologação');

    return Response.json({
      ok: true, version: 'NEXT-0.6F', readOnly: true, importEnabled: false,
      work: { id: work.id, codigo: work.codigo, nome: work.nome, faixaPls: work.faixa_pls },
      measurement: measurementNo,
      file: preview.file,
      validation: preview.validation,
      temporalValidation: preview.temporalValidation,
      proposedAction,
      payload: {
        status: preview.eventPayload.status,
        completeSourceCount: preview.eventPayload.sourceEventCount,
        mappedEvents: preview.eventPayload.mappedEventCount,
        countsMatch: preview.eventPayload.match,
        structureSha256: preview.eventPayload.structureSha256,
        structureSnapshotSchema: preview.eventPayload.structureSnapshot.schema,
        coverage: preview.eventPayload.coverage,
        diagnostics: preview.eventPayload.diagnostics,
        warnings: preview.eventPayload.warnings,
        completeness: preview.eventPayload.completeness,
      },
      database: { measurementExists: Boolean(measurement), measurementStatus: measurement?.status || null, existingVersionCount: existingVersions.length, sameShaExists: existingVersions.some((x) => x.sha256_arquivo === preview.file.sha256), sourceFileAlreadyCatalogued: Boolean(shaRows[0]), sourceWorkConflict: Boolean(shaRows[0] && shaRows[0].work_id !== work.id) },
      dbRowsPreview: { ...payload, measurement_versions: { ...payload.measurement_versions, structure_snapshot_json: { schema: preview.eventPayload.structureSnapshot.schema, eventCount: preview.eventPayload.structureSnapshot.events.length, sheets: preview.eventPayload.structureSnapshot.sheets } } },
      pendingBeforeRealImport: missingRequired,
      warning: 'NEXT-0.6F é exclusivamente auditoria: preserva matrizes com rótulos e valores da planilha, sinaliza divergências e NÃO autoriza importação. Nenhum INSERT/UPDATE/DELETE, nenhuma alteração no Drive e nenhum e-mail.',
    });
  } catch (error) {
    return Response.json({ ok: false, error: error?.message || String(error) }, { status: error?.status || 500 });
  }
}
