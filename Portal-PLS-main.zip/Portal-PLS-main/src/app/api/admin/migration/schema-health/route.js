import { requireGlobalAdmin } from '@/lib/authz.js';
import { db } from '@/lib/db.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const REQUIRED_TABLES = [
  'measurement_source_files',
  'migration_review_decisions',
  'migration_runs',
  'migration_run_items',
];

const REQUIRED_VERSION_COLUMNS = [
  'parser_profile',
  'source_filename',
  'source_path',
  'source_parent_folder_id',
  'source_measurement_folder_name',
  'internal_measurement_number',
  'period_reference_raw',
  'validation_status',
  'validation_reasons',
  'temporal_validation_status',
  'candidate_resolution',
  'source_file_id',
  'structure_sha256',
  'structure_snapshot_json',
];

export async function GET() {
  try {
    await requireGlobalAdmin();
    const sql = db();

    const tableRows = await sql`
      select table_name
        from information_schema.tables
       where table_schema = 'public'
         and table_name in ${sql(REQUIRED_TABLES)}
    `;
    const existingTables = new Set(tableRows.map((x) => x.table_name));

    const columnRows = await sql`
      select column_name
        from information_schema.columns
       where table_schema = 'public'
         and table_name = 'measurement_versions'
         and column_name in ${sql(REQUIRED_VERSION_COLUMNS)}
    `;
    const existingColumns = new Set(columnRows.map((x) => x.column_name));

    const missingTables = REQUIRED_TABLES.filter((x) => !existingTables.has(x));
    const missingMeasurementVersionColumns = REQUIRED_VERSION_COLUMNS.filter((x) => !existingColumns.has(x));
    const ready = missingTables.length === 0 && missingMeasurementVersionColumns.length === 0;

    return Response.json({
      ok: true,
      version: 'NEXT-0.6F',
      historicalMigrationSchema: ready ? 'ready' : 'pending',
      missingTables,
      missingMeasurementVersionColumns,
      importEnabled: false,
      warning: 'A NEXT-0.6F apenas verifica a estrutura. Nenhuma medição histórica é importada por este endpoint.',
    });
  } catch (error) {
    return Response.json({ ok: false, error: error?.message || String(error) }, { status: error?.status || 500 });
  }
}
