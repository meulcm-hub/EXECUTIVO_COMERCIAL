import { requireUser } from '@/lib/authz.js';
import { db } from '@/lib/db.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const user = await requireUser();
    const sql = db();
    const rows = await sql`
      select distinct w.id, w.codigo, w.nome, w.cidade, w.uf, w.faixa_pls,
             w.drive_folder_id, w.drive_name, w.source, w.drive_last_seen_at,
             coalesce(a.perfil, case when u.perfil_global = 'ADMIN' then 'ADMIN' end) as perfil
        from works w
        join app_users u on lower(u.email) = lower(${user.email}) and u.ativo = true
        left join work_access a on a.work_id = w.id and a.user_id = u.id and a.ativo = true
       where w.ativo = true
         and (u.perfil_global = 'ADMIN' or a.id is not null)
       order by w.codigo, w.nome, w.drive_folder_id
    `;
    return Response.json({ ok: true, obras: rows });
  } catch (error) {
    return Response.json({ ok: false, error: error.message }, { status: error.status || 500 });
  }
}
