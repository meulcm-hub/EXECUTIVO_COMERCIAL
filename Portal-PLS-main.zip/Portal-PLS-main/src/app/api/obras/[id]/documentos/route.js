import { requireWorkAccess } from '@/lib/authz.js';
import { db } from '@/lib/db.js';
import { inventoryPlsFilesForWork } from '@/lib/pls/drive-inventory.js';
import { mapInventoryForWork, driveFolderViewUrl } from '@/lib/pls/drive-work-view.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 120;
const noStore = { 'Cache-Control': 'private, no-store, max-age=0' };

export async function GET(_request, context) {
  try {
    const { id } = await context.params;
    if (!/^[0-9a-f]{8}-[0-9a-f-]{27,}$/.test(String(id))) return Response.json({ ok: false, error: 'Obra inválida.' }, { status: 400, headers: noStore });
    await requireWorkAccess(id);
    const sql = db();
    const works = await sql`select id,codigo,nome,faixa_pls,drive_folder_id,drive_name from works where id=${id} and ativo=true limit 1`;
    const work = works[0];
    if (!work) return Response.json({ ok: false, error: 'Obra não encontrada.' }, { status: 404, headers: noStore });
    if (!work.drive_folder_id) return Response.json({ ok: false, error: 'Esta obra ainda não possui pasta do Drive vinculada.' }, { status: 422, headers: noStore });
    const siblings = await sql`select id,nome from works where codigo=${work.codigo} and ativo=true`;
    const inventory = await inventoryPlsFilesForWork(work, { siblingWorks: siblings });
    const info = mapInventoryForWork(inventory);
    return Response.json({ ok: true, obra: { id:work.id, codigo:work.codigo, nome:work.nome, linkPasta:driveFolderViewUrl(work.drive_folder_id) }, ...info }, { headers: noStore });
  } catch (e) {
    return Response.json({ ok: false, error: e?.message || 'Não foi possível consultar os documentos.' }, { status: e?.status || 500, headers: noStore });
  }
}
