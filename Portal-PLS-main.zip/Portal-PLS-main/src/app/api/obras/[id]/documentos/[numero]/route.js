import { requireWorkAccess } from '@/lib/authz.js';
import { db } from '@/lib/db.js';
import { inventoryPlsFilesForWork } from '@/lib/pls/drive-inventory.js';
import { readPlsWorkbookPreview } from '@/lib/pls/server-reader.js';
import { mapPreviewForWork } from '@/lib/pls/drive-work-view.js';
import { listChildItems } from '@/lib/google/drive.js';
import { mapRelatedDocuments } from '@/lib/pls/related-documents.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 120;
const noStore = { 'Cache-Control': 'private, no-store, max-age=0' };

export async function GET(_request, context) {
  try {
    const { id, numero: rawNumero } = await context.params;
    const numero = Number(rawNumero);
    if (!/^[0-9a-f]{8}-[0-9a-f-]{27,}$/.test(String(id))) return Response.json({ ok:false, error:'Obra inválida.' }, { status:400, headers:noStore });
    if (!/^\d{1,4}$/.test(String(rawNumero)) || !Number.isInteger(numero) || numero < 1) return Response.json({ ok:false, error:'Número de medição inválido.' }, { status:400, headers:noStore });
    await requireWorkAccess(id);
    const sql = db();
    const works = await sql`select id,codigo,nome,faixa_pls,drive_folder_id,drive_name from works where id=${id} and ativo=true limit 1`;
    const work = works[0];
    if (!work?.drive_folder_id) return Response.json({ ok:false, error:'Obra inexistente ou sem pasta do Drive.' }, { status:404, headers:noStore });
    const siblings = await sql`select id,nome from works where codigo=${work.codigo} and ativo=true`;
    const inventory = await inventoryPlsFilesForWork(work, { siblingWorks:siblings });
    const file = (inventory.preferredPerMeasurement || []).find(x=>Number(x.numeroMedicao)===numero);
    if (!file) return Response.json({ ok:false, error:`M${String(numero).padStart(2,'0')} sem arquivo candidato selecionável.` }, { status:404, headers:noStore });
    const group = (inventory.reviewCandidatesPerMeasurement || []).find(x=>Number(x.numeroMedicao)===numero);
    const candidates = group?.candidatos || [];
    const preview = await readPlsWorkbookPreview({ work, file, selection: { candidateReviewRequired: candidates.length > 1, candidateAlternatives:candidates } });
    const details = mapPreviewForWork({ preview, numero, allCandidatesCount:candidates.length || 1 });
    let documentosRelacionados;
    try {
      const neighbors = file.parentFolderId ? await listChildItems(file.parentFolderId) : [];
      documentosRelacionados = mapRelatedDocuments(neighbors, file.driveFileId);
    } catch (_) {
      documentosRelacionados = { documentos:[], arquivosPdf:0, fonte:'NAO_DISPONIVEL', mensagem:'Não foi possível consultar PDFs nesta etapa. A planilha continua disponível para leitura.', somenteLeitura:true };
    }
    // Esta consulta não cria medições, não autentica fonte oficial e não aprova/importa PLS.
    return Response.json({ ok:true, ...details, documentosRelacionados }, { headers:noStore });
  } catch (e) {
    return Response.json({ ok:false, error:e?.message || 'Falha ao ler a planilha.' }, { status:e?.status || 500, headers:noStore });
  }
}
