import { requireWorkAccess } from '@/lib/authz.js';
import { db } from '@/lib/db.js';

export const runtime = 'nodejs';

export async function GET(_request, context) {
  try {
    const { id } = await context.params;
    await requireWorkAccess(id);
    const sql = db();
    const rows = await sql`
      select m.id, m.numero, m.competencia, m.status, m.avanco_periodo, m.avanco_acumulado,
             m.aprovado_em, m.aprovado_por,
             v.id as versao_id, v.versao, v.arquivo_nome, v.drive_file_id, v.sha256_arquivo, v.vigente
        from measurements m
        left join measurement_versions v on v.measurement_id = m.id and v.vigente = true
       where m.work_id = ${id}
       order by m.numero desc
    `;
    return Response.json({ ok: true, medicoes: rows });
  } catch (error) {
    return Response.json({ ok: false, error: error.message }, { status: error.status || 500 });
  }
}
