import { requireWorkAccess } from '@/lib/authz.js';
import { db } from '@/lib/db.js';
import { validatePreflight, resolvePreflight } from '@/lib/pls/operation-guard.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
const noStore = { 'Cache-Control': 'private, no-store, max-age=0' };

export async function POST(request, context) {
  try {
    const { id } = await context.params;
    if (!/^[0-9a-f]{8}-[0-9a-f-]{27,}$/.test(String(id))) return Response.json({ok:false,error:'Obra inválida.'},{status:400,headers:noStore});
    const actor = await requireWorkAccess(id, ['USUARIO','RESPONSAVEL','APROVADOR','ADMIN']);
    const body = await request.json();
    const meta = validatePreflight({
      numero: Number(body.numero), nomeArquivo: body.nomeArquivo,
      tamanhoBytes: body.tamanhoBytes, pdfNome: body.pdfNome,
      pdfTamanhoBytes: body.pdfTamanhoBytes,
      sha256Excel:body.sha256Excel,sha256Pdf:body.sha256Pdf,
    });
    const sql = db();
    const works = await sql`select id, nome, codigo from works where id = ${id} and ativo=true limit 1`;
    if (!works[0]) return Response.json({ok:false,error:'Obra não encontrada.'},{status:404,headers:noStore});
    const rows = await sql`
      select m.id, m.status, m.aprovado_em,
             (select max(v.versao) from measurement_versions v where v.measurement_id=m.id and v.vigente=true) as versao_vigente
        from measurements m
       where m.work_id=${id} and m.numero=${meta.numero}
       limit 1
    `;
    const hashesExistentes=meta.excel.sha256 ? await sql`
      select m.numero, v.versao from measurement_versions v
      join measurements m on m.id=v.measurement_id
      where m.work_id=${id} and v.sha256_arquivo=${meta.excel.sha256}
      order by m.numero desc,v.versao desc limit 4
    ` : [];
    return Response.json({
      ok:true, somenteLeitura:true, obra: {id, nome: works[0].nome, codigo: works[0].codigo},
      usuario: actor.email, resultado:resolvePreflight({meta,measurement:rows[0]||null,hashesExistentes}),
    },{headers:noStore});
  } catch (error) {
    return Response.json({ok:false,error:error?.message||'Não foi possível conferir os metadados.'},{status:error?.status||400,headers:noStore});
  }
}
