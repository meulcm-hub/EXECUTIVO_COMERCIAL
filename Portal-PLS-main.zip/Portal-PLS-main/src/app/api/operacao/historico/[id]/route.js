import { requireUser, requireWorkAccess } from '@/lib/authz.js';
import { db } from '@/lib/db.js';
import { classifyLifecycle } from '@/lib/pls/lifecycle-status.js';

export const runtime='nodejs';
export const dynamic='force-dynamic';
const headers={'Cache-Control':'private, no-store, max-age=0'};
const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export async function GET(_request,context) {
  try {
    const {id}=await context.params;
    if(!uuid.test(String(id))) return Response.json({ok:false,error:'Medição inválida.'},{status:400,headers});
    await requireUser();
    const sql=db();
    const record=await sql`select id,work_id,numero,status,aprovado_em from measurements where id=${id} limit 1`;
    if(!record[0]) return Response.json({ok:false,error:'Medição não encontrada.'},{status:404,headers});
    await requireWorkAccess(record[0].work_id);
    const versions=await sql`
      select id,versao,vigente,status_versao,processing_state,validation_status,
             arquivo_nome,tamanho_bytes,sha256_arquivo,sha256_snapshot,
             enviado_por,aprovado_por,aprovado_em,origem,created_at
      from measurement_versions where measurement_id=${id}
      order by versao desc limit 100
    `;
    const audit=await sql`
      select id,actor_email,action,created_at,detail
      from audit_events where measurement_id=${id}
      order by created_at desc limit 40
    `;
    const now=versions.find(v=>v.vigente)||null;
    return Response.json({ok:true,onlyRead:true,writeEnabled:false,measurement:{...record[0],liberacao:classifyLifecycle(record[0],now)},versions,audit,limitedVersions:versions.length===100,limitedAudit:audit.length===40},{headers});
  } catch(e) {
    return Response.json({ok:false,error:e?.status===401?'Sessão expirada.':e?.status===403?'Você não possui acesso a esta obra.':'Falha ao consultar as versões.'},{status:e?.status||500,headers});
  }
}
