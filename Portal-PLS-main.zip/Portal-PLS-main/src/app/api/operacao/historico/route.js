import { requireUser, getUserContext } from '@/lib/authz.js';
import { db } from '@/lib/db.js';
import { classifyLifecycle } from '@/lib/pls/lifecycle-status.js';

export const runtime='nodejs';
export const dynamic='force-dynamic';
const headers={'Cache-Control':'private, no-store, max-age=0'};
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export async function GET(request) {
  try {
    const session=await requireUser();
    const actor=await getUserContext(session.email);
    if(!actor?.ativo) return Response.json({ok:false,error:'Usuário sem perfil ativo.'},{status:403,headers});
    const filter=new URL(request.url).searchParams.get('obra')?.trim()||null;
    if(filter&&!uuid.test(filter)) return Response.json({ok:false,error:'Identificador de obra inválido.'},{status:400,headers});
    const isAdmin=actor.perfil_global==='ADMIN';
    const sql=db();
    const rows=await sql`
      select m.id, m.work_id, w.codigo, w.nome as obra_nome,
             m.numero, m.competencia, m.status, m.avanco_periodo, m.avanco_acumulado,
             m.valor_periodo, m.valor_acumulado, m.criado_por, m.aprovado_por, m.aprovado_em,
             v.id as versao_id, v.versao, v.vigente, v.status_versao,
             v.processing_state, v.validation_status, v.arquivo_nome, v.enviado_por,
             v.sha256_arquivo, v.created_at as versao_criada_em,
             (select count(*)::integer from measurement_versions allv where allv.measurement_id=m.id) as total_versoes
      from measurements m
      join works w on w.id=m.work_id and w.ativo=true
      left join measurement_versions v on v.measurement_id=m.id and v.vigente=true
      where (${isAdmin}::boolean or exists (
        select 1 from work_access a where a.work_id=w.id and a.user_id=${actor.id} and a.ativo=true
      ))
        and (${filter}::uuid is null or m.work_id=${filter}::uuid)
      order by m.updated_at desc, m.numero desc
      limit 151
    `;
    const countsRows=await sql`
      select count(*)::integer as total,
             count(*) filter(where m.status='APROVADA')::integer as aprovadas,
             count(*) filter(where m.status='EM_EXECUCAO')::integer as "emExecucao",
             count(*) filter(where m.status not in ('APROVADA','EM_EXECUCAO'))::integer as revisao
      from measurements m join works w on w.id=m.work_id and w.ativo=true
      where (${isAdmin}::boolean or exists (
        select 1 from work_access a where a.work_id=w.id and a.user_id=${actor.id} and a.ativo=true
      ))
        and (${filter}::uuid is null or m.work_id=${filter}::uuid)
    `;
    const limited=rows.length>150;
    const items=rows.slice(0,150).map(r=>({...r,liberacao:classifyLifecycle(r,r.versao_id ? {...r,id:r.versao_id}:null)}));
    return Response.json({ok:true,onlyRead:true,writeEnabled:false,items,limited,counts:countsRows[0]||{total:0,aprovadas:0,emExecucao:0,revisao:0},scope:filter?'OBRA':'ACESSIVEIS'},{headers});
  } catch(e) {
    return Response.json({ok:false,error:e?.status===401?'Sessão expirada.':e?.status===403?'Acesso negado.':'Falha ao consultar o histórico.'},{status:e?.status||500,headers});
  }
}
