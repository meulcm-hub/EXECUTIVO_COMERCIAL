'use client';
import React, { useEffect, useMemo, useState } from 'react';
import WorkDrivePanel from './components/WorkDrivePanel.js';
import WorkOperationsPanel from './components/WorkOperationsPanel.js';
import HistoryPanel from './components/HistoryPanel.js';
import OperationalReadiness from './components/OperationalReadiness.js';

const h = React.createElement;
const PORTAL_ANTIGO = 'https://script.google.com/a/macros/lcmconstrucao.com.br/s/AKfycbzWwc9NnlJWSHoUywKObUCZjirQyznyZCGyJV7-uJlcUdifcntPFYxZEzKHfBCadxVR/exec';
const fase = [
  { n: '01', titulo: 'Acesso e permissões', detalhe: 'Google Workspace e perfis de acesso', situacao: 'feito' },
  { n: '02', titulo: 'Catálogo de obras', detalhe: 'Obras ativas sincronizadas no PostgreSQL', situacao: 'feito' },
  { n: '03', titulo: 'Conexão documental', detalhe: 'Localização das planilhas pelo Google Drive', situacao: 'feito' },
  { n: '04', titulo: 'Leitura e conferência', detalhe: 'Faixas 1 e 2, matrizes, contagens e divergências', situacao: 'feito' },
  { n: '05', titulo: 'Homologação por obra', detalhe: 'Exceções de cada planilha e regras de aprovação', situacao: 'andamento' },
  { n: '06', titulo: 'Migração histórica', detalhe: 'Carga transacional segura e auditável', situacao: 'pendente' },
  { n: '07', titulo: 'Fluxo operacional', detalhe: 'Painel de gestão e pré-checagem prontos; uploads e aprovações ainda bloqueados', situacao: 'andamento' },
  { n: '08', titulo: 'Documentos e relatórios', detalhe: 'Consulta de PLS pelo Drive em andamento; PDFs e relatórios ainda pendentes', situacao: 'andamento' },
];

function Icon({ name, size=20 }) {
  const shapes = {
    grid: [h('rect',{key:1,x:3,y:3,width:7,height:7,rx:1}),h('rect',{key:2,x:14,y:3,width:7,height:7,rx:1}),h('rect',{key:3,x:3,y:14,width:7,height:7,rx:1}),h('rect',{key:4,x:14,y:14,width:7,height:7,rx:1})],
    building: [h('rect',{key:1,x:4,y:2,width:16,height:20,rx:2}),...[7,12,17].flatMap((y)=>[h('path',{key:y+'a',d:`M8 ${y}h2`}),h('path',{key:y+'b',d:`M14 ${y}h2`})])],
    chart: [h('path',{key:1,d:'M3 3v18h18'}),h('path',{key:2,d:'M7 16l4-5 3 3 6-8'})],
    shield: [h('path',{key:1,d:'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z'}),h('path',{key:2,d:'m9 12 2 2 4-4'})],
    file: [h('path',{key:1,d:'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z'}),h('path',{key:2,d:'M14 2v6h6'}),h('path',{key:3,d:'M8 13h8M8 17h8'})],
    check: [h('path',{key:1,d:'m5 12 4 4L19 6'})],
    chevron: [h('path',{key:1,d:'m9 18 6-6-6-6'})],
    arrow: [h('path',{key:1,d:'M5 12h14m-6-6 6 6-6 6'})],
    search: [h('circle',{key:1,cx:11,cy:11,r:7}),h('path',{key:2,d:'m20 20-4-4'})],
    clock: [h('circle',{key:1,cx:12,cy:12,r:9}),h('path',{key:2,d:'M12 7v5l4 2'})],
    lock: [h('rect',{key:1,x:5,y:10,width:14,height:11,rx:2}),h('path',{key:2,d:'M8 10V7a4 4 0 0 1 8 0v3'})],
    external: [h('path',{key:1,d:'M14 4h6v6m0-6-9 9'}),h('path',{key:2,d:'M20 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h5'})],
    logout: [h('path',{key:1,d:'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4'}),h('path',{key:2,d:'m16 17 5-5-5-5M21 12H9'})],
  };
  return h('svg',{width:size,height:size,viewBox:'0 0 24 24',fill:'none',stroke:'currentColor',strokeWidth:1.8,strokeLinecap:'round',strokeLinejoin:'round','aria-hidden':'true'},...(shapes[name]||shapes.file));
}

function Tag({state,children}) { return h('span',{className:'p-tag p-tag-'+state},children); }
function Card({className='',children}) { return h('section',{className:'p-card '+className},children); }
function ProgressBadge({state}) {
  return h(Tag,{state:state==='feito'?'success':state==='andamento'?'warn':'neutral'},
    state==='feito'?'Concluído':state==='andamento'?'Em andamento':'Próxima etapa');
}
function toName(o) { return [o.codigo,o.nome].filter(Boolean).join(' - '); }
function norm(v) { return String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('pt-BR'); }
function localDate(v) { if(!v) return '—'; const d=new Date(v); return isNaN(d.getTime())?'—':d.toLocaleDateString('pt-BR'); }
function displayPercent(v) { const n=Number(v); return Number.isFinite(n)?n.toLocaleString('pt-BR',{maximumFractionDigits:2})+'%':'—'; }

export default function Portal() {
  const [me,setMe]=useState(null);
  const [obras,setObras]=useState([]);
  const [loading,setLoading]=useState(true);
  const [error,setError]=useState('');
  const [aba,setAba]=useState('painel');
  const [termo,setTermo]=useState('');
  const [selecionada,setSelecionada]=useState(null);
  const [medicoes,setMedicoes]=useState({workId:null,loading:false,rows:[],error:''});
  const [faixaSelecionada,setFaixaSelecionada]=useState('TODAS');
  const [historicoObra,setHistoricoObra]=useState(null);

  useEffect(()=>{
    let live=true;
    (async()=>{
      try {
        const mRes=await fetch('/api/me',{cache:'no-store'});
        if(!mRes.ok) throw new Error('Não foi possível validar a sessão.');
        const m=await mRes.json();
        if(!live) return;
        setMe(m);
        if(m?.authenticated) {
          const wRes=await fetch('/api/obras',{cache:'no-store'});
          const w=await wRes.json();
          if(!wRes.ok || !w?.ok) throw new Error(w.error||'Não foi possível carregar as obras.');
          if(live) setObras(Array.isArray(w.obras)?w.obras:[]);
        }
      } catch(e){if(live) setError(e?.message||'Falha ao carregar o Portal.');}
      finally {if(live) setLoading(false);}
    })();
    return ()=>{live=false;};
  },[]);

  useEffect(()=>{
    if(!selecionada?.id) return;
    const controller=new AbortController();
    setMedicoes({workId:selecionada.id,loading:true,rows:[],error:''});
    (async()=>{
      try {
        const res=await fetch(`/api/obras/${encodeURIComponent(selecionada.id)}/medicoes`,{cache:'no-store',signal:controller.signal});
        const data=await res.json();
        if(!res.ok || !data.ok) throw new Error(data.error||'Falha ao consultar as medições.');
        setMedicoes({workId:selecionada.id,loading:false,rows:data.medicoes||[],error:''});
      } catch(e) { if(!controller.signal.aborted) setMedicoes({workId:selecionada.id,loading:false,rows:[],error:e.message||String(e)}); }
    })();
    return ()=>controller.abort();
  },[selecionada?.id]);

  const admin=me?.profile?.perfilGlobal==='ADMIN';
  const obrasDaFaixa=useMemo(()=>obras.filter(o=>faixaSelecionada==='TODAS'||String(o.faixa_pls||'').toUpperCase()===faixaSelecionada),[obras,faixaSelecionada]);
  const filtradas=useMemo(()=>obrasDaFaixa.filter(o=>norm(toName(o)+' '+o.cidade+' '+o.uf+' '+o.faixa_pls).includes(norm(termo))),[obrasDaFaixa,termo]);
  const primeiroNome=String(me?.user?.name||me?.profile?.nome||'').split(' ')[0]||'equipe LCM';

  function ir(a) { setAba(a); setSelecionada(null); setHistoricoObra(null); }
  function abrir(o) {setSelecionada(o);setAba('obras');}
  function abrirHistorico(o) {setHistoricoObra(o);setSelecionada(null);setAba('historico');}
  async function sair() { try{await fetch('/api/auth/logout',{method:'POST'});}finally{window.location.href='/';} }

  if(loading) return h('main',{className:'p-boot'},h('img',{src:'/logo-lcm.png',alt:'LCM Construção'}),h('p',null,'Carregando Portal PLS...'));
  if(error) return h('main',{className:'p-boot'},h('img',{src:'/logo-lcm.png',alt:'LCM Construção'}),h('h2',null,'Não foi possível abrir o Portal'),h('p',null,error),h('button',{className:'p-btn',onClick:()=>window.location.reload()},'Tentar novamente'));
  if(!me?.authenticated) return h('main',{className:'p-login'},
    h('section',{className:'p-login-panel'},h('img',{src:'/logo-lcm.png',className:'p-login-logo',alt:'LCM Construção'}),h('span',{className:'p-eyebrow'},'GESTÃO DE OBRAS E MEDIÇÕES'),h('h1',null,'Sua operação de obras em um só lugar.'),h('p',null,'Acompanhe as obras, consulte medições e documentos e visualize a evolução da migração com segurança.'),h('a',{href:'/api/auth/google/start',className:'p-btn p-login-cta'},'Entrar com Google LCM',h(Icon,{name:'arrow'})),h('div',{className:'p-login-fine'},h(Icon,{name:'lock',size:15}),' Acesso exclusivo para usuários autorizados da LCM.')),
    h('aside',{className:'p-login-aside'},h('div',{className:'p-login-mark'},'PLS'),h('h2',null,'Informação confiável para decisões melhores.'),h('p',null,'Nova plataforma em implantação. O sistema operacional atual permanece disponível durante a transição.'),h('a',{href:PORTAL_ANTIGO,target:'_blank',rel:'noopener noreferrer'},'Acessar sistema atual ',h(Icon,{name:'external',size:15}))));
  if(me?.profile?.ativo===false || !me?.profile) return h('main',{className:'p-boot'},h('h2',null,'Aguardando permissão de acesso'),h('p',null,'A conta está autenticada, mas não há um perfil ativo para este usuário.'),h('button',{className:'p-btn',onClick:sair},'Sair'));

  const nav=[{id:'painel',title:'Dashboard',icon:'grid'}];
  const menusLegados=[{title:'Preencher / Editar PLS',icon:'file'},{title:'PLS Caixa (Upload)',icon:'file'},{title:'Curva S & Gráficos',icon:'chart'}];
  return h('div',{className:'p-app p-app-legacy'},
    h('header',{className:'p-legacy-header'},
      h('div',{className:'p-legacy-bar'},
        h('button',{type:'button',className:'p-legacy-brand',onClick:()=>ir('painel'),'aria-label':'Voltar ao Dashboard'},
          h('span',{className:'p-legacy-logo'},h('img',{src:'/logo-lcm.png',alt:'LCM Construção'})),
          h('span',{className:'p-legacy-brand-text'},h('strong',null,'Portal PLS'),h('small',null,'LCM Construção • Engenharia • PLS Caixa • Medições'))),
        h('label',{className:'p-legacy-search'},h(Icon,{name:'search',size:16}),
          h('input',{type:'search',value:termo,onChange:e=>{setTermo(e.target.value);if(e.target.value){setSelecionada(null);setAba('obras');}},placeholder:'Buscar obra por código ou nome...','aria-label':'Buscar obras'})),
        h('div',{className:'p-legacy-bar-right'},
          h('span',{className:'p-legacy-implementation'},'Em implantação'),
          h('div',{className:'p-legacy-user'},h('span',{className:'p-legacy-avatar'},primeiroNome[0]?.toUpperCase()||'L'),h('span',null,h('strong',null,me?.user?.name||me?.profile?.nome||'Equipe LCM'),h('small',null,admin?'ADMIN':'USUÁRIO'))),
          h('button',{type:'button',className:'p-legacy-logout',onClick:sair,title:'Sair','aria-label':'Sair'},h(Icon,{name:'logout',size:17})))),
      h('nav',{className:'p-legacy-tabs','aria-label':'Menu do Portal PLS'},
        h('div',{className:'p-legacy-tabs-inner'},
          h('div',{className:'p-legacy-faixas','aria-label':'Filtrar obras por faixa'},
            h('span',{className:'p-legacy-module'},'MÓDULO'),
            ...[{value:'FAIXA_1',label:'FAIXA 1'},{value:'FAIXA_2',label:'FAIXA 2'},{value:'TODAS',label:'TODAS'}].map(x=>
              h('button',{key:x.value,type:'button',className:'p-legacy-faixa '+(faixaSelecionada===x.value?'selected':''),onClick:()=>{setFaixaSelecionada(x.value);setTermo('');setSelecionada(null);setAba('obras');},'aria-pressed':faixaSelecionada===x.value},x.label))),
          ...nav.slice(0,1).map(n=>h('button',{key:n.id,type:'button',className:'p-legacy-tab '+(aba===n.id?'selected':''),onClick:()=>ir(n.id)},h(Icon,{name:n.icon,size:15}),n.title)),
          ...menusLegados.map(n=>h('a',{key:n.title,className:'p-legacy-tab p-legacy-external',href:PORTAL_ANTIGO,target:'_blank',rel:'noopener noreferrer',title:n.title+' — função disponível no Portal atual'},h(Icon,{name:n.icon,size:15}),n.title,h('span',{className:'p-legacy-new-tab'},'↗'))),
          h('button',{type:'button',className:'p-legacy-tab '+(aba==='historico'?'selected':''),onClick:()=>ir('historico')},h(Icon,{name:'clock',size:15}),'Histórico'),
          h('button',{type:'button',className:'p-legacy-tab '+(aba==='obras'?'selected':''),onClick:()=>ir('obras')},h(Icon,{name:'building',size:15}),'Obras'),
          h('button',{type:'button',className:'p-legacy-tab '+(aba==='implantacao'?'selected':''),onClick:()=>ir('implantacao')},h(Icon,{name:'chart',size:15}),'Implantação'),
          admin?h('a',{className:'p-legacy-tab',href:'/admin/auditoria'},h(Icon,{name:'shield',size:15}),'Auditoria'):null,
          admin?h('a',{className:'p-legacy-tab p-legacy-tab-lab',href:'/laboratorio'},h(Icon,{name:'lock',size:15}),'Laboratório de envio'):null))),
    h('div',{className:'p-main'},
      h('header',{className:'p-topbar'},h('div',null,h('span',{className:'p-breadcrumb'},'Portal PLS',h(Icon,{name:'chevron',size:14}),selecionada?'Detalhe da obra':aba==='painel'?'Visão geral':aba==='obras'?'Obras e medições':aba==='historico'?'Histórico e aprovações':'Evolução do projeto'),h('div',{className:'p-top-title'},'Gestão de Obras e Medições')),h('div',{className:'p-topbar-right'},h(Tag,{state:'warn'},'Em implantação'),h('span',{className:'p-top-version'},'NEXT-0.8B'))),
      h('main',{className:'p-content'},
        aba==='painel' ? h(React.Fragment,null,
          h('section',{className:'p-welcome'},h('div',null,h('span',{className:'p-eyebrow'},'LCM CONSTRUÇÃO • DASHBOARD DE OBRAS'),h('h1',null,`Bem-vindo ao Portal PLS, ${primeiroNome}.`),h('p',null,'Uma visão centralizada das obras da LCM, com identidade visual reforçada, dados conectados ao novo banco e acompanhamento transparente da implantação.')),
            h('button',{className:'p-btn p-btn-white',type:'button',onClick:()=>ir('obras')},'Explorar obras ',h(Icon,{name:'arrow',size:17}))),
          h('div',{className:'p-metrics'},
            h('div',{className:'p-metric'},h('div',{className:'p-metric-top'},'Obras acessíveis',h(Icon,{name:'building'})),h('strong',null,String(obrasDaFaixa.length).padStart(2,'0')),h('small',null,faixaSelecionada==='TODAS'?'Carregadas do PostgreSQL':'Filtro ativo: '+faixaSelecionada.replace('_',' '))),
            h('div',{className:'p-metric'},h('div',{className:'p-metric-top'},'Conexão com documentos',h(Icon,{name:'file'})),h('strong',{className:'p-metric-label'},'Drive'),h('small',null,'Auditoria por obra disponível ao administrador')),
            h('div',{className:'p-metric'},h('div',{className:'p-metric-top'},'Situação da migração',h(Icon,{name:'shield'})),h('strong',{className:'p-metric-label'},'Homologação'),h('small',null,'Carga histórica ainda não habilitada'))),
          h('div',{className:'p-two-columns'},
            h(Card,null,h('div',{className:'p-card-head'},h('div',null,h('h2',null,'Obras cadastradas'),h('p',null,'Relação atual de obras que seu perfil pode acessar.')),h('button',{className:'p-text-action',onClick:()=>ir('obras')},'Ver todas ',h(Icon,{name:'arrow',size:16}))),
              obrasDaFaixa.length ? h('div',{className:'p-work-list'},...obrasDaFaixa.slice(0,7).map(o=>h('button',{className:'p-work-line',key:o.id,onClick:()=>abrir(o)},h('span',{className:'p-work-initial'},String(o.codigo||'?').slice(0,3)),h('span',{className:'p-work-name'},h('strong',null,toName(o)),h('small',null,[o.cidade,o.uf].filter(Boolean).join(' / ')||'Obra cadastrada')),h(Icon,{name:'chevron',size:17})))) : h('p',{className:'p-empty'},'Nenhuma obra disponível para seu perfil.')),
            h(Card,null,h('div',{className:'p-card-head'},h('div',null,h('h2',null,'Evolução da implantação'),h('p',null,'Entregas técnicas concluídas e próximas etapas.'))),h('div',{className:'p-milestones'},...fase.slice(0,6).map(x=>h('div',{className:'p-milestone',key:x.n},h('span',{className:'p-milestone-dot '+x.situacao},x.situacao==='feito'?h(Icon,{name:'check',size:13}):x.n),h('div',null,h('strong',null,x.titulo),h('small',null,x.detalhe)),h(ProgressBadge,{state:x.situacao})))),h('button',{className:'p-text-action p-milestone-link',onClick:()=>ir('implantacao')},'Ver plano completo ',h(Icon,{name:'arrow',size:16})))),
          h('div',{className:'p-inline-notice'},h(Icon,{name:'shield',size:20}),h('div',null,h('strong',null,'Operação atual preservada'),h('p',null,'Aprovações, assinaturas e uploads oficiais continuam no Apps Script até a homologação dos fluxos no novo portal.')),h('a',{href:PORTAL_ANTIGO,target:'_blank',rel:'noopener noreferrer'},'Abrir sistema atual ',h(Icon,{name:'external',size:16})))
        ) : null,
        aba==='obras' ? h(React.Fragment,null,
          h('section',{className:'p-page-header'},h('div',null,h('span',{className:'p-eyebrow'},'OBRAS • GESTÃO DE MEDIÇÕES'),h('h1',null,selecionada?toName(selecionada):'Obras e medições'),h('p',null,selecionada?'Consulte PLS, documentos, versões e conferências da obra, com os mesmos conceitos do Portal atual.':'Selecione a obra para consultar documentos, medições e histórico. Use as abas Faixa 1 e Faixa 2 para filtrar.')),
            selecionada?h('button',{className:'p-btn p-btn-light',onClick:()=>setSelecionada(null)},'← Todas as obras'):null),
          selecionada?h(React.Fragment,null,
            h('div',{className:'p-work-summary'},h('div',null,h('small',null,'OBRA'),h('strong',null,toName(selecionada))),h('div',null,h('small',null,'LOCALIZAÇÃO'),h('strong',null,[selecionada.cidade,selecionada.uf].filter(Boolean).join(' / ')||'Não cadastrada')),h('div',null,h('small',null,'PERFIL DE PLS'),h('strong',null,selecionada.faixa_pls||'Não definido')),h('div',null,h('small',null,'ACESSO'),h('strong',null,selecionada.perfil||'Autorizado'))),
            h(WorkOperationsPanel,{key:'ops-'+selecionada.id,work:selecionada,rows:medicoes.rows}),
            h('div',{className:'p-work-history-shortcut'},h('button',{className:'p-btn p-btn-light',type:'button',onClick:()=>abrirHistorico(selecionada)},h(Icon,{name:'clock',size:16}),'Consultar versões e aprovações desta obra')), 
            h(WorkDrivePanel,{key:selecionada.id,work:selecionada}),
            h(Card,null,h('div',{className:'p-card-head'},h('div',null,h('h2',null,'Medições registradas'),h('p',null,'Consulta direta à tabela de medições do Neon, respeitando seu acesso à obra.'))),
              medicoes.loading?h('p',{className:'p-empty'},'Consultando o PostgreSQL...'):medicoes.error?h('p',{className:'p-error'},medicoes.error):medicoes.rows.length===0?h('div',{className:'p-empty-state'},h(Icon,{name:'clock',size:30}),h('h3',null,'Histórico ainda não migrado'),h('p',null,'Não há medições cadastradas nesta obra no novo banco. Os arquivos oficiais continuam disponíveis no sistema atual.')):h('div',{className:'p-table-wrap'},h('table',{className:'p-table'},h('thead',null,h('tr',null,...['Medição','Competência','Status','Avanço do período','Avanço acumulado','Versão'].map(k=>h('th',{key:k},k)))),h('tbody',null,...medicoes.rows.map(m=>h('tr',{key:m.id},h('td',null,`M${String(m.numero||0).padStart(2,'0')}`),h('td',null,m.competencia||'—'),h('td',null,h(Tag,{state:m.status==='APROVADA'?'success':'neutral'},m.status||'—')),h('td',null,displayPercent(m.avanco_periodo)),h('td',null,displayPercent(m.avanco_acumulado)),h('td',null,m.versao||'—'))))))),
              h('div',{className:'p-card-footer'},admin?h('a',{className:'p-btn p-btn-light',href:'/admin/auditoria'},'Abrir auditoria técnica ',h(Icon,{name:'arrow',size:16})):null,h('a',{className:'p-btn p-btn-light',href:PORTAL_ANTIGO,target:'_blank',rel:'noopener noreferrer'},'Sistema operacional atual ',h(Icon,{name:'external',size:16})))
          ):h(React.Fragment,null,
            h('div',{className:'p-search-panel'},h(Icon,{name:'search',size:19}),h('input',{type:'search',value:termo,onChange:e=>setTermo(e.target.value),placeholder:'Buscar por nome, código, cidade ou faixa...','aria-label':'Buscar obras'}),h('span',null,`${filtradas.length} obra(s)`)),
            filtradas.length?h('div',{className:'p-works-grid'},...filtradas.map(o=>h('button',{type:'button',className:'p-work-tile',key:o.id,onClick:()=>abrir(o)},h('div',{className:'p-tile-top'},h('span',{className:'p-tile-code'},o.codigo||'—'),h(Icon,{name:'chevron',size:18})),h('h3',null,o.nome||'Sem nome cadastrado'),h('p',null,[o.cidade,o.uf].filter(Boolean).join(' / ')||'Localização não cadastrada'),h('div',{className:'p-tile-bottom'},h(Tag,{state:'neutral'},o.faixa_pls||'Faixa não definida'),h('span',null,'Consultar medições'))))):h('p',{className:'p-empty'},'Nenhuma obra encontrada para esta busca.'))
        ):null,
        aba==='historico' ? h(HistoryPanel,{work:historicoObra,goToWorks:()=>historicoObra?abrir(historicoObra):ir('obras')}) : null,
        aba==='implantacao' ? h(React.Fragment,null,
          h('section',{className:'p-page-header'},h('div',null,h('span',{className:'p-eyebrow'},'TRANSPARÊNCIA DA MIGRAÇÃO'),h('h1',null,'Da plataforma antiga ao novo Portal PLS'),h('p',null,'Entregas já verificadas e atividades pendentes. Esta visão não equivale à liberação do processamento oficial de medições.'))),
          h(Card,null,h('div',{className:'p-card-head'},h('div',null,h('h2',null,'Etapas da implantação'),h('p',null,'Situação funcional do novo sistema, separada da análise das planilhas históricas.'))),h('div',{className:'p-roadmap'},...fase.map(x=>h('div',{className:'p-roadmap-step',key:x.n},h('span',{className:'p-roadmap-num'},x.n),h('div',null,h('h3',null,x.titulo),h('p',null,x.detalhe)),h(ProgressBadge,{state:x.situacao}))))),
          admin?h(OperationalReadiness,{}):null,
          h('div',{className:'p-inline-notice'},h(Icon,{name:'lock',size:20}),h('div',null,h('strong',null,'Salvaguardas obrigatórias'),h('p',null,'Imutabilidade da medição aprovada, versionamento, identidade pelo ID da pasta e reconciliação dos eventos serão exigidos antes da ativação de escrita.')),h('a',{href:'/admin/auditoria',className:'p-optional-link'},admin?'Conferir auditoria':'',admin?h(Icon,{name:'arrow',size:16}):null))
        ):null
      )
    )
  );
}
