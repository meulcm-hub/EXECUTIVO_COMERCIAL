const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.resolve(__dirname,'..');
const uid='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';

function makeRoute(filename, forbidden=false) {
 let code=fs.readFileSync(path.join(root,filename),'utf8')
   .replace(/^import .*;$/gm,'')
   .replace(/export const /g,'const ')
   .replace('export async function GET(', 'async function GET(')
   + '\nthis.run=GET;';
 let checks=0, dbReads=0, driveReads=0;
 const work={id:uid,codigo:'328',nome:'VILLAGE MOD III',faixa_pls:'FAIXA_2',drive_folder_id:'driveFolder12345',drive_name:'328 - VILLAGE MOD III'};
 const inventory={foldersScanned:19,excelFiles:20,measurementsFound:[18],preferredPerMeasurement:[{driveFileId:'driveFile1234567',numeroMedicao:18,arquivo:'PLS 18.xlsm',classificacaoCaminho:'PRINCIPAL'}]};
 const ctx={
  URL,Number,String,Array,Boolean,Response,
  requireWorkAccess: async id=>{checks++;if(forbidden){const e=new Error('Sem acesso.'); e.status=403;throw e;}assert.equal(id,uid);},
  db:()=>async (...args)=>{dbReads++;const query=args[0].join(''); if(/select id,codigo,nome/.test(query)) return [work];return [{id:uid,nome:work.nome}];},
  inventoryPlsFilesForWork:async()=>{driveReads++;return inventory;},
  mapInventoryForWork:()=>({resumo:{medicoesEncontradas:1,arquivosExcel:20},medicoes:[{numero:18,arquivo:'PLS 18.xlsm'}],somenteLeitura:true}),
  driveFolderViewUrl:id=>`https://drive.google.com/drive/folders/${id}`,
  readPlsWorkbookPreview:async()=>({file:{name:'PLS 18.xlsm'},parsed:{eventCount:83,internalMeasurementNumber:18},validation:{status:'APTO'}}),
  mapPreviewForWork:()=>({medicao:18,eventos:83,validacaoPreliminar:'APTO',importacaoPermitida:false,somenteLeitura:true}),
 };
 vm.createContext(ctx);vm.runInContext(code,ctx,{filename});
 return {GET:ctx.run,counts:()=>({checks,dbReads,driveReads})};
}
(async()=>{
 for(const [file,number] of [
  ['src/app/api/obras/[id]/documentos/route.js',false],
  ['src/app/api/obras/[id]/documentos/[numero]/route.js',true],
 ]) {
  const authorized=makeRoute(file);
  const response=await authorized.GET({url:`https://portal-pls.vercel.app/api/obras/${uid}/documentos`},{params:Promise.resolve({id:uid,numero:'18'})});
  const body=await response.json();assert.equal(response.status,200);assert.equal(body.ok,true);assert.equal(body.somenteLeitura,true);
  assert.ok(authorized.counts().driveReads>0);
  const denied=makeRoute(file,true);
  const no=await denied.GET({url:'https://portal-pls.vercel.app'},{params:Promise.resolve({id:uid,numero:'18'})});
  assert.equal(no.status,403);assert.equal(denied.counts().dbReads,0);assert.equal(denied.counts().driveReads,0);
 }
 console.log('OK NEXT-0.7B: acesso por obra, sem leitura de Drive para usuário sem permissão; respostas somente leitura.');
})().catch(e=>{console.error(e);process.exitCode=1;});
