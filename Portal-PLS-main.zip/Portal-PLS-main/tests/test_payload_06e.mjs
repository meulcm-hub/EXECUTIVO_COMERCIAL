import assert from 'node:assert/strict';
import { buildEventPayloadFromWorkbook, structureFingerprint } from '../src/lib/pls/event-payload.js';
function colIndex(col){return col.split('').reduce((n,c)=>n*26+c.charCodeAt(0)-64,0)-1;}
function colName(idx){let s='';for(let n=idx+1;n;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s;}
const XLSX={utils:{
  encode_cell:({r,c})=>`${colName(c)}${r+1}`,
  encode_col:colName,
  decode_range:(s)=>{const m=s.split(':').at(-1).match(/([A-Z]+)(\d+)/);return {s:{r:0,c:0},e:{r:Number(m[2])-1,c:colIndex(m[1])}};},
  sheet_to_json:(sheet)=>sheet.__rows,
}};
function lines(n){return Array.from({length:n},()=>[]);}
function ws(rows, lastCol=33){
  const out={__rows:rows,'!ref':`A1:${colName(lastCol)}${rows.length}`};
  rows.forEach((row,r)=>row.forEach((v,c)=>{if(v!==null&&v!==undefined&&v!=='')out[`${colName(c)}${r+1}`]={v};}));
  return out;
}
const hab=lines(26);
hab[17][19]='BLOCO A';hab[18][19]='ETAPA';hab[19][19]='APTO 101';
hab[20]=['1.1','Fundação','DIRETO',2,1,'',0.5,'',1000,500];hab[20][19]=1;
hab[21]=['1.2','Paredes','DIRETO',2,1,'',0.3,'',600,300];hab[21][19]=2;
hab[22]=['1.3','Administração','INDIRETO',0,0,'',0.2,'',400,0];
const infra=lines(22);infra[17][19]='INFRA';infra[19][19]='LOCAL';infra[20]=['2.1','Pavimento','DIRETO',1,1,'',1,'',200,200];infra[20][19]=2;
const equip=lines(22);equip[17][19]='EQUIP';equip[19][19]='LOCAL';equip[20]=['3.1','Equipamento','DIRETO',1,1,'',1,'',100,100];equip[20][19]=2;
for (const [rows,r,prev,per,acc] of [[hab,20,1,0,1],[hab,21,0,1,1],[infra,20,0,1,1],[equip,20,0,1,1]]) { rows[r][10]=prev;rows[r][11]=per;rows[r][12]=acc; }
const wb1={SheetNames:['Medição Global','PLS-Habitação','PLS-INFRA','PLS-Equipamentos'],Sheets:{'PLS-Habitação':ws(hab),'PLS-INFRA':ws(infra),'PLS-Equipamentos':ws(equip)}};
const p1={parserProfile:'FAIXA_1_GENERICA',selectedSheet:'Medição Global',internalMeasurementNumber:2,eventCount:5,areaSheets:{habitacao:'PLS-Habitação',infraestrutura:'PLS-INFRA',equipamentos:'PLS-Equipamentos'},budgets:{habitacao:2000,infraestrutura:200,equipamentos:100,global:2300}};
const f1=buildEventPayloadFromWorkbook({XLSX,wb:wb1,parsed:p1,faixaPls:'FAIXA_1'});
assert.equal(f1.status,'PAYLOAD_PRONTO_PARA_CONFERENCIA');
assert.equal(f1.mappedEventCount,5);
assert.equal(f1.eventRecords[0].matriz_json.values[0],1);
assert.equal(f1.eventRecords[1].exec_periodo,1);
assert.equal(f1.eventRecords[2].tipo_evento,'INDIRETO');
assert.equal(f1.canImport,false);
assert.equal(f1.readOnly,true);

// Faixa 2 com metadados reais de layout: posição O/R, rótulos 101/102 por BLOCO,
// dois eventos físicos com mesmo item e macros diferentes, um evento temporal sem matriz.
const rows=lines(30);
rows[13][14]='LOCAL E ÉPOCA DE EXECUÇÃO DO EVENTO';
rows[14][14]='QUADRA';
rows[15]=['SERVIÇOS','MACRO','DISCRIMINAÇÃO','', 'UNIDADE','QUANTIDADE','INCIDÊNCIA','NA OBRA'];
rows[16][14]='BLOCO 19';rows[16][16]='BLOCO 20';
rows[17][14]=101;rows[17][15]=102;rows[17][16]=101;rows[17][17]=102;
rows[18]=[1,'Habitação',1,'Serviço A','GLOBAL',4,5,0.5,2,2,4,50,100];
rows[18][14]=1;rows[18][15]=1;rows[18][16]=2;rows[18][17]=2;
rows[19]=[2,'Fundação',1,'Serviço B','GLOBAL',4,3,0.3,0,2,2,50,50];
rows[19][16]=2;rows[19][17]=2;
rows[20]=[null,null,2,'Administração local','MESES',36,1,0.1,0,0,0,1.42,100];
const p2={parserProfile:'FAIXA_2_RESUMO',selectedSheet:'PLS HAB',internalMeasurementNumber:2,eventCount:3};
const wb2={SheetNames:['PLS HAB','RESUMO'],Sheets:{'PLS HAB':ws(rows),RESUMO:ws([])}};
const f2=buildEventPayloadFromWorkbook({XLSX,wb:wb2,parsed:p2,faixaPls:'FAIXA_2'});
assert.equal(f2.mappedEventCount,3,JSON.stringify(f2.warnings));
assert.equal(f2.status,'PAYLOAD_PRONTO_PARA_CONFERENCIA',JSON.stringify(f2.warnings));
assert.equal(f2.coverage[0].matrixPositions,4);
assert.equal(f2.coverage[0].matrixEvents,2);
assert.equal(f2.coverage[0].temporalWithoutMatrix,1);
assert.equal(f2.eventRecords[0].matriz_json.values.length,4);
assert.equal(f2.eventRecords[0].matriz_json.derived.previous,2);
assert.equal(f2.eventRecords[0].matriz_json.derived.period,2);
assert.equal(f2.eventRecords[0].matriz_json.positions[0].group,'BLOCO 19');
assert.equal(f2.eventRecords[0].matriz_json.positions[2].group,'BLOCO 20');
assert.equal(f2.eventRecords[0].matriz_json.positions[0].label,'101');
assert.equal(f2.eventRecords[1].item,f2.eventRecords[0].item);
assert.notEqual(f2.eventRecords[1].macro_codigo,f2.eventRecords[0].macro_codigo);
assert.equal(f2.eventRecords[2].matriz_json,null);
assert.match(f2.structureSha256,/^[a-f0-9]{64}$/);
assert.equal(structureFingerprint({a:2,b:3}),structureFingerprint({b:3,a:2}));
// Hash do modelo muda com os rótulos estruturais, não com avanço de execução.
const changedExec=structuredClone(rows);changedExec[18][14]=2;
const fe=buildEventPayloadFromWorkbook({XLSX,wb:{...wb2,Sheets:{...wb2.Sheets,'PLS HAB':ws(changedExec)}},parsed:p2,faixaPls:'FAIXA_2'});
assert.equal(fe.structureSha256,f2.structureSha256);
const changedLabel=structuredClone(rows);changedLabel[17][14]=201;
const fl=buildEventPayloadFromWorkbook({XLSX,wb:{...wb2,Sheets:{...wb2.Sheets,'PLS HAB':ws(changedLabel)}},parsed:p2,faixaPls:'FAIXA_2'});
assert.notEqual(fl.structureSha256,f2.structureSha256);
const invalid=structuredClone(rows);invalid[18][17]=999;
const fi=buildEventPayloadFromWorkbook({XLSX,wb:{...wb2,Sheets:{...wb2.Sheets,'PLS HAB':ws(invalid)}},parsed:p2,faixaPls:'FAIXA_2'});
assert.equal(fi.status,'PAYLOAD_REVISAR_MAPEAMENTO');
assert.ok(fi.warnings.some((w)=>w.includes('NUMERO_MEDICAO_MATRIZ_INVALIDO')));
const more=buildEventPayloadFromWorkbook({XLSX,wb:{...wb2,SheetNames:['PLS HAB','PLS INFRA','RESUMO'],Sheets:{...wb2.Sheets,'PLS INFRA':ws([])}},parsed:p2,faixaPls:'FAIXA_2'});
assert.equal(more.status,'PAYLOAD_REVISAR_MAPEAMENTO');
assert.ok(more.warnings.some((w)=>w.includes('PLS INFRA')));
// Sem rótulos de posições, não declarar carga completa.
const noHeader=structuredClone(rows);noHeader[17]=[];noHeader[16]=[];
const blocked=buildEventPayloadFromWorkbook({XLSX,wb:{...wb2,Sheets:{...wb2.Sheets,'PLS HAB':ws(noHeader)}},parsed:p2,faixaPls:'FAIXA_2'});
assert.equal(blocked.status,'PAYLOAD_REVISAR_MAPEAMENTO');
console.log('PASSOU 0.6E (base 0.6D): Faixa 1 sem regressão; matrizes por bloco Faixa 2; temporal; hashes; duplicidade de item; cabeçalho; posições inválidas; abas complementares; sem escrita.');

// 0.6E — datas da medição não podem compor a assinatura do modelo estrutural.
const withBusinessDates=structuredClone(rows);
withBusinessDates[12][14]='20/08/2026 a 18/09/2026';
withBusinessDates[12][16]=46284; // serial Excel de data, nunca um grupo de local
const fd=buildEventPayloadFromWorkbook({XLSX,wb:{...wb2,Sheets:{...wb2.Sheets,'PLS HAB':ws(withBusinessDates)}},parsed:p2,faixaPls:'FAIXA_2'});
assert.equal(fd.structureSha256,f2.structureSha256,'Datas de competência afetaram indevidamente o hash de estrutura.');
assert.equal(fd.eventRecords[0].matriz_json.positions[0].group,'BLOCO 19');

// 0.6E — um serviço com quatro locais preenchidos e quantidade 2 deve registrar
// evidência, não alterar o Excel nem atribuir arbitrariamente quais são os extras.
const qtyMismatch=structuredClone(rows);
qtyMismatch[18][5]=2; // F19
const fm=buildEventPayloadFromWorkbook({XLSX,wb:{...wb2,Sheets:{...wb2.Sheets,'PLS HAB':ws(qtyMismatch)}},parsed:p2,faixaPls:'FAIXA_2'});
assert.equal(fm.status,'PAYLOAD_REVISAR_MAPEAMENTO');
assert.equal(fm.diagnostics.eventDiscrepancies[0].quantity,2);
assert.equal(fm.diagnostics.eventDiscrepancies[0].matrixDerived.accumulated,4);
assert.equal(fm.diagnostics.eventDiscrepancies[0].populatedPositions.length,4);
assert.deepEqual(fm.diagnostics.eventDiscrepancies[0].countsByGroup.map(g=>g.countedPositions),[2,2]);

// 0.6E — rótulo atípico em apenas um bloco gera OBSERVAÇÃO, nunca substituição.
const oddLabel=structuredClone(rows);
oddLabel[16][18]='BLOCO 21';oddLabel[16][20]='BLOCO 22';
oddLabel[17][18]=101;oddLabel[17][19]=102;
oddLabel[17][20]=169;oddLabel[17][21]=102;
const fo=buildEventPayloadFromWorkbook({XLSX,wb:{...wb2,Sheets:{...wb2.Sheets,'PLS HAB':ws(oddLabel)}},parsed:p2,faixaPls:'FAIXA_2'});
assert.ok(fo.diagnostics.labelObservations.some(x=>x.cell==='U18'&&x.actualLabel==='169'));
assert.equal(fo.diagnostics.labelObservations[0].usualLabel,'101');
console.log('PASSOU 0.6E: hash estável sem datas, grupos reais, contagens divergentes por bloco, rótulo atípico e diagnóstico sem escrita.');
