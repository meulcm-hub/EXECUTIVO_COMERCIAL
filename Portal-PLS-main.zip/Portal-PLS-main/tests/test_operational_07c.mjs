import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { validatePreflight, resolvePreflight, OPERATIONAL_WRITES_ENABLED } from '../src/lib/pls/operation-guard.js';
import { mapRelatedDocuments } from '../src/lib/pls/related-documents.js';

assert.equal(OPERATIONAL_WRITES_ENABLED,false);
const meta=validatePreflight({numero:19,nomeArquivo:'PLS 19.xlsm',tamanhoBytes:128000,pdfNome:'PLS 19.pdf',pdfTamanhoBytes:12700});
assert.equal(resolvePreflight({meta,measurement:null}).tipo,'NOVA_MEDICAO_PLANEJADA');
assert.equal(resolvePreflight({meta,measurement:{status:'EM_EXECUCAO',versao_vigente:2}}).tipo,'NOVA_VERSAO_PLANEJADA');
const approved=resolvePreflight({meta,measurement:{status:'APROVADA',versao_vigente:3}});
assert.equal(approved.tipo,'ALTERACAO_BLOQUEADA');
assert.equal(approved.escritaPermitida,false);
for(const incorrect of [
  {numero:0,nomeArquivo:'PLS.xlsm',tamanhoBytes:500},
  {numero:1.5,nomeArquivo:'PLS.xlsm',tamanhoBytes:500},
  {numero:1,nomeArquivo:'../../private.xlsm',tamanhoBytes:500},
  {numero:1,nomeArquivo:'PLS.pdf',tamanhoBytes:500},
  {numero:1,nomeArquivo:'PLS.xlsm',tamanhoBytes:16000000},
  {numero:1,nomeArquivo:'PLS.xlsm',tamanhoBytes:500,pdfNome:'PLS.txt',pdfTamanhoBytes:100}
])assert.throws(()=>validatePreflight(incorrect));
const docs=mapRelatedDocuments([
 {id:'fileABCabcdefgh1',name:'PLS - medição.pdf',mimeType:'application/pdf'},
 {id:'fileABCabcdefgh2',name:'PLS-18.xlsm'},
 {id:'fileABCabcdefgh3',name:'PLS Luciano.pdf'},
], 'fileABCabcdefgh2');
assert.equal(docs.documentos.length,2);
assert.equal(docs.somenteLeitura,true);
assert.equal(docs.documentos[0].url.startsWith('https://drive.google.com/file/d/'),true);

// HTTP 423 obrigatório mesmo que o endpoint seja chamado diretamente, sem login na UI.
for(const path of [
  'src/app/api/blob/presign/route.js',
  'src/app/api/uploads/finalize/route.js',
  'src/app/api/uploads/[id]/aprovar/route.js'
]){
 let c=readFileSync(new URL('../'+path,import.meta.url),'utf8')
   .replace(/^import .*;$/gm,'').replace(/export const /g,'const ')
   .replace('export async function POST(', 'async function POST(')
   + '\nthis.execute=POST;';
 const ctx={Response,blockedOperationResponse:()=>Response.json({ok:false,code:'OPERACAO_NAO_HOMOLOGADA'},{status:423}),URL};
 vm.createContext(ctx);vm.runInContext(c,ctx,{filename:path});
 const res=await ctx.execute({json:async()=>{throw Error('Should never run');}}, {params:Promise.resolve({id:'x'})});
 assert.equal(res.status,423,path);
 assert.equal((await res.json()).code,'OPERACAO_NAO_HOMOLOGADA',path);
}
console.log('OK NEXT-0.7C: PDF por pasta, pré-checagem, aprovado imutável e três endpoints de gravação bloqueados por HTTP 423.');
