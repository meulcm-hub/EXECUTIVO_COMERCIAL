import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {labPath,sha256,validateLabFiles,LAB_MAX_TOTAL_BYTES} from '../src/lib/pls/lab-upload.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const source=fs.readFileSync(root+'/src/app/api/laboratorio/envio/route.js','utf8')
 .replace(/^import .*;$/gm,'')
 .replace(/export const /g,'const ')
 .replace(/export async function /g,'async function ')
 + '\nthis.GET=GET;this.POST=POST;';
const work='11111111-2222-3333-4444-555555555555';
let approved=false,configured=true,loggedIn=true,corruptRead=false,putCalled=0,delCalled=0;
const store=new Map();
const context={
 crypto, Buffer, Response, URL, console, process:{env:{PLS_LAB_BLOB_TOKEN:'TEST_TOKEN'}},
 isLabConfigured:()=>configured,LAB_MAX_TOTAL_BYTES,labPath,sha256,validateLabFiles,
 async requireGlobalAdmin(){if(!loggedIn)throw Object.assign(new Error('não admin'),{status:403});return {email:'admin@example.test'};},
 db:()=>async (strings,...values)=>{
  const q=strings.join('?');
  if(q.includes('select id,nome,codigo from works'))return [{id:work,nome:'Obra fictícia',codigo:'999'}];
  if(q.includes('select id from measurements'))return approved?[{id:'approved'}]:[];
  throw Error('Consulta inesperada.');
 },
 inspectWorkbook:()=>({sheetNames:['PLS HAB','RESUMO'],hasPls:true}),
 async put(name,buffer,opts){assert.equal(opts.access,'private');assert.equal(opts.token,'TEST_TOKEN');putCalled++;store.set(name,Buffer.from(buffer));return {pathname:name};},
 async get(name,opts){assert.equal(opts.access,'private');const contents=store.get(name);return {stream:(async function*(){yield corruptRead?Buffer.from('Arquivo adulterado'):contents;})()};},
 async del(name,opts){assert.equal(opts.token,'TEST_TOKEN');delCalled++;store.delete(name);},
};
vm.createContext(context);vm.runInContext(source,context,{filename:'route.js'});
function makeRequest({origin='https://portal-pls.vercel.app',badPdf=false}={}){
 const excelBytes=Buffer.concat([Buffer.from('504b0304','hex'),Buffer.alloc(128)]);
 const excel={name:'ficticio.xlsx',size:excelBytes.length,arrayBuffer:async()=>excelBytes};
 const form=new Map([['obraId',work],['numero','99'],['excel',excel]]);
 if(badPdf)form.set('pdf',{name:'falso.pdf',size:9,arrayBuffer:async()=>Buffer.from('SEM PDF!!')});
 return {url:'https://portal-pls.vercel.app/api/laboratorio/envio',headers:{get(name){return name==='origin'?origin:name==='content-type'?'multipart/form-data;boundary=fake':name==='content-length'?'150':null;}},formData:async()=>form};
}
let r=await context.GET();assert.equal((await r.json()).labConfigured,true);
r=await context.POST(makeRequest());let j=await r.json();assert.equal(r.status,200);assert.equal(j.ok,true);assert.equal(j.arquivosDescartados,true);assert.equal(j.arquivos[0].integridade,'CONFIRMADA');assert.equal(putCalled,1);assert.equal(delCalled,1);assert.equal(store.size,0);
corruptRead=true;
r=await context.POST(makeRequest());j=await r.json();assert.equal(j.ok,false);assert.equal(store.size,0);corruptRead=false;
approved=true;
r=await context.POST(makeRequest());j=await r.json();assert.equal(r.status,409);assert.equal(store.size,0);approved=false;
r=await context.POST(makeRequest({origin:'https://site-externo.test'}));j=await r.json();assert.equal(r.status,403);
configured=false;
r=await context.POST(makeRequest());j=await r.json();assert.equal(r.status,423);
configured=true;loggedIn=false;
r=await context.POST(makeRequest());j=await r.json();assert.equal(r.status,403);
console.log('OK NEXT-0.8B: envio privado, leitura, hash, descarte, origem, bloqueios por aprovação/perfil/configuração.');
