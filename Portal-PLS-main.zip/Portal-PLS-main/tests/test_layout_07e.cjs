const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const file = fs.readFileSync(path.join(root, 'src/app/page.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'src/app/globals.css'), 'utf8');
const health = fs.readFileSync(path.join(root, 'src/app/api/health/route.js'), 'utf8');
const config = fs.readFileSync(path.join(root, 'src/lib/config.js'), 'utf8');
const user={authenticated:true,user:{name:'Pessoa Teste'},profile:{nome:'Pessoa Teste',perfilGlobal:'ADMIN',ativo:true}};
const obras=[
 {id:'id1',codigo:'607',nome:'PATOS I',faixa_pls:'FAIXA_1'},
 {id:'id2',codigo:'328',nome:'VILLAGE MOD III',faixa_pls:'FAIXA_2'},
 {id:'id3',codigo:'216',nome:'JATOBÁ',faixa_pls:'FAIXA_2'},
];
const context = {React:{createElement(type,props,...children){return {type,props:props||{},children};},Fragment:'fragment'},useEffect(){},useMemo(fn){return fn();},window:{location:{href:''}},console,WorkDrivePanel:()=>null,WorkOperationsPanel:()=>null,HistoryPanel:()=>null};
let slots=[],index=0;
context.useState=(initial)=>{const i=index++;return [i in slots?slots[i]:initial,()=>{}];};
vm.createContext(context);
vm.runInContext(file.replace(/^'use client';\s*/,'').replace(/^import .*;$/gm,'').replace('export default function Portal','function Portal')+'\nthis.__render=Portal;',context);
function flatten(n,out=[]){if(Array.isArray(n)){for(const x of n) flatten(x,out);return out;}if(n&&typeof n==='object'){if(n.type)out.push(n);for(const x of n.children||[])flatten(x,out);}return out;}
function text(node){return (node.children||[]).map(x=>typeof x==='string'?x:(x&&x.type?text(x):'')).join('');}
function render(faixa='TODAS',aba='obras'){
 index=0; slots=[user,obras,false,'',aba,'',null,{workId:null,loading:false,rows:[],error:''},faixa];return flatten(context.__render());
}
const tree=render();
const menu=tree.filter(x=>x.props.className?.includes('p-legacy-tab'));
const names=menu.map(text);
for(const t of ['Dashboard','Preencher / Editar PLS','PLS Caixa (Upload)','Curva S & Gráficos','Histórico','Obras','Implantação','Auditoria']) assert(names.some(x=>x.includes(t)),t);
const external=menu.filter(x=>x.props.className?.includes('p-legacy-external'));
assert.equal(external.length,3);
for(const x of external){ assert.equal(x.type,'a');assert.match(x.props.href,/script\.google\.com/);assert.equal(x.props.target,'_blank'); }
const tiles=xs=>xs.filter(x=>x.props.className==='p-work-tile').map(x=>text(x));
assert.equal(tiles(render('FAIXA_1')).length,1);
assert.equal(tiles(render('FAIXA_2')).length,2);
assert.equal(tiles(render('TODAS')).length,3);
assert(css.includes('.p-legacy-header')&&css.includes('#89aa40'));
assert(health.includes('NEXT-0.8B')&&config.includes('NEXT-0.8B'));
assert(!file.includes('function aprovar'));
console.log('OK NEXT-0.8A: menus familiares, links para funções legadas, filtros 1/2/todas, versão e responsividade.');

assert(names.some(x=>x==='Histórico'));
assert(external.every(x=>!text(x).includes('Histórico')));
