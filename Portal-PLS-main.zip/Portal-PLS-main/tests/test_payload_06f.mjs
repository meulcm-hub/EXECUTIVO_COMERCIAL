import assert from 'node:assert/strict';
import { buildEventPayloadFromWorkbook } from '../src/lib/pls/event-payload.js';
const colName = (idx) => { let s=''; for(let n=idx+1;n;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s; };
const colIndex = (txt) => txt.split('').reduce((n,c)=>n*26+c.charCodeAt(0)-64,0)-1;
const XLSX={utils:{ encode_cell:({r,c})=>`${colName(c)}${r+1}`,encode_col:colName,
  decode_range:s=>{const m=s.split(':').at(-1).match(/([A-Z]+)(\d+)/);return {s:{r:0,c:0},e:{r:+m[2]-1,c:colIndex(m[1])}};},
  sheet_to_json:ws=>ws.__rows }};
const blank=()=>Array.from({length:40},()=>[]);
function sheet(rows){const o={__rows:rows,'!ref':`A1:AD${rows.length}`};for(let r=0;r<rows.length;r++)for(let c=0;c<(rows[r]||[]).length;c++){
 const v=rows[r][c];if(v!==undefined&&v!==null&&v!=='')o[`${colName(c)}${r+1}`]={v};}return o;}
function evt(rows,r,item,name,n,prev,per,acc,mat){rows[r]=[item,name,'GLOBAL',n,0.3,0.2,0.2,0,100,100,prev,per,acc];rows[r][19]=mat;}
const hab=blank();hab[17][19]='BLOCO 01';hab[18][19]='ETAPAS';hab[19][19]='101';evt(hab,20,'1.1','Fundação',1,1,0,1,1);
const infra=blank();infra[17][19]='BLOCO 02';infra[18][19]='ETAPAS';infra[19][19]='101';evt(infra,30,'2.1.1','DESTOCAMENTO',1,1,0,1,0);
const equip=blank();equip[17][19]='BLOCO 03';equip[18][19]='ETAPAS';equip[19][19]='101';evt(equip,20,'3.1','Portaria',1,1,0,1,1);
const wb={SheetNames:['Medição Global','PLS-Habitação','PLS-INFRA','PLS-Equipamentos'],Sheets:{'PLS-Habitação':sheet(hab),'PLS-INFRA':sheet(infra),'PLS-Equipamentos':sheet(equip)}};
const parsed={parserProfile:'FAIXA_1_GENERICA',selectedSheet:'Medição Global',internalMeasurementNumber:13,eventCount:3,
  areaSheets:{habitacao:'PLS-Habitação',infraestrutura:'PLS-INFRA',equipamentos:'PLS-Equipamentos'},budgets:{habitacao:100,infraestrutura:100,equipamentos:100,global:300}};
const p=buildEventPayloadFromWorkbook({XLSX,wb,parsed,faixaPls:'FAIXA_1'});
assert.equal(p.status,'PAYLOAD_REVISAR_MAPEAMENTO');
assert.equal(p.mappedEventCount,3);
assert.equal(p.diagnostics.eventDiscrepancies.length,1);
assert.equal(p.diagnostics.eventDiscrepancies[0].sheet,'PLS-INFRA');
assert.equal(p.diagnostics.eventDiscrepancies[0].line,31);
assert.equal(p.diagnostics.eventDiscrepancies[0].matrixDerived.accumulated,0);
assert.equal(p.diagnostics.eventDiscrepancies[0].official.accumulated,1);
assert.deepEqual(p.diagnostics.eventDiscrepancies[0].zeroPositions,['T31']);
assert.ok(p.eventRecords[1].matriz_json.values[0]===0);
assert.equal(p.eventRecords[1].exec_acumulado,1); // OFICIAL, não substituído pela matriz
assert.equal(p.eventRecords[0].matriz_json.nonEmpty,1);
assert.equal(p.eventRecords[0].matriz_json.derived.accumulated,1);
assert.equal(p.coverage.find(x=>x.area==='INFRAESTRUTURA').matrixWarnings,1);
assert.equal(p.canImport,false);
const revised=structuredClone(infra);revised[30][19]=1;
const q=buildEventPayloadFromWorkbook({XLSX,wb:{...wb,Sheets:{...wb.Sheets,'PLS-INFRA':sheet(revised)}},parsed,faixaPls:'FAIXA_1'});
assert.equal(q.status,'PAYLOAD_PRONTO_PARA_CONFERENCIA',JSON.stringify(q.warnings));
assert.equal(q.structureSha256,p.structureSha256); // execução não integra estrutura
assert.equal(q.diagnostics.eventDiscrepancies.length,0);
console.log('OK NEXT-0.6F: divergência Faixa 1 bloqueada, dados oficiais preservados, posição 0 identificada, quantidade de eventos inalterada, hash V3 estável, sem gravação.');
