const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const p=path.resolve(__dirname,'../src/app/api/obras/[id]/envio/preflight/route.js');
const code=fs.readFileSync(p,'utf8').replace(/^import .*;$/gm,'').replace(/export const /g,'const ')
 .replace('export async function POST(', 'async function POST(')+'\nthis.handle=POST;';
const uid='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
function factory(deny=false, approved=false){
 let dbReads=0,auth=0;
 const ctx={Response,Number,String,Boolean,
 requireWorkAccess:async id=>{auth++;if(deny){const e=new Error('Sem acesso');e.status=403;throw e;}assert.equal(id,uid);return {email:'teste@lcmconstrucao.com.br'}},
 validatePreflight:({numero,nomeArquivo,tamanhoBytes})=>{assert.equal(numero,10);assert.equal(nomeArquivo,'medicao.xlsm');assert.equal(tamanhoBytes,400);return {numero,excel:{nome:nomeArquivo}}},
 resolvePreflight:({meta,measurement})=>({numero:meta.numero,status:measurement?.status||'NOVO',escritaPermitida:false}),
 db:()=>async strings=>{dbReads++;return /from works/.test(strings.join(''))?[{id:uid,nome:'Obra',codigo:'216'}]:approved?[{status:'APROVADA'}]:[]}
 };
 vm.createContext(ctx);vm.runInContext(code,ctx,{filename:p});
 return {ctx,counts:()=>({auth,dbReads})};
}
(async()=>{
 const ok=factory(false,true);
 const r=await ok.ctx.handle({json:async()=>({numero:10,nomeArquivo:'medicao.xlsm',tamanhoBytes:400})},{params:Promise.resolve({id:uid})});
 assert.equal(r.status,200); const data=await r.json();assert.equal(data.resultado.escritaPermitida,false);assert.equal(data.resultado.status,'APROVADA');
 const blocked=factory(true);
 const err=await blocked.ctx.handle({json:async()=>{throw Error('JSON should not be parsed when access fails')}},{params:Promise.resolve({id:uid})});
 assert.equal(err.status,403);assert.equal(blocked.counts().dbReads,0);
 console.log('OK NEXT-0.7C: preflight exige acesso antes de ler metadados e não escreve.');
})().catch(e=>{console.error(e);process.exitCode=1});
