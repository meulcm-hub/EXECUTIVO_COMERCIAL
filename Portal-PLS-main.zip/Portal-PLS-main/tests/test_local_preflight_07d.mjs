import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { inspectLocalFiles } from '../src/lib/pls/local-preflight.js';
import { validatePreflight, resolvePreflight, OPERATIONAL_WRITES_ENABLED } from '../src/lib/pls/operation-guard.js';
const make=(name, signature, size)=>({name,size:size||signature.length, arrayBuffer:async()=>Uint8Array.from(signature).buffer});
const zip=[0x50,0x4b,0x03,0x04,1,2,3,4];
const pdf=[...Buffer.from('%PDF-1.7\n')];
const hash=async()=>Uint8Array.from({length:32},(_,i)=>i).buffer;
const workbook1={SheetNames:['Medição Global','PLS-Habitação','PLS-INFRA','PLS-Equipamentos'], Sheets:{'Medição Global':{H6:{v:13}}}};
const result=await inspectLocalFiles({excel:make('planilha.xlsm',zip),pdf:make('documento.pdf',pdf),faixaPls:'FAIXA_1',numero:13,
 digest:hash,loadXlsx:async()=>({read:()=>workbook1,utils:{sheet_to_json:()=>[]}})});
assert.equal(result.quantidadeAbas,4);
assert.equal(result.abaPrincipal,'Medição Global');
assert.equal(result.numeroInternoIndicativo,13);
assert.equal(result.excelSha256.length,64);
assert.equal(result.pdfSha256.length,64);
assert.deepEqual(result.indiciosParaRevisar,[]);
assert.equal(result.conteudoEnviadoAoServidor,false);
assert.equal(result.homologado,false);
const result2=await inspectLocalFiles({excel:make('planilha.xlsx',zip),faixaPls:'FAIXA_2',numero:18,
 digest:hash,loadXlsx:async()=>({read:()=>({SheetNames:['PLS HAB','RESUMO'],Sheets:{'PLS HAB':{}}}),utils:{sheet_to_json:()=>[['Numero da medicao',18]]}})});
assert.equal(result2.abaPrincipal,'PLS HAB');
assert.equal(result2.numeroInternoIndicativo,18);
await assert.rejects(()=>inspectLocalFiles({excel:make('arquivo.xlsm',pdf),faixaPls:'FAIXA_1',numero:13}),/bytes/);
await assert.rejects(()=>inspectLocalFiles({excel:make('planilha.xlsm',zip),pdf:make('falso.pdf',zip),digest:hash,loadXlsx:async()=>({read:()=>workbook1,utils:{sheet_to_json:()=>[]}})}),/PDF válida/);
const hashHex=result.excelSha256;
const meta=validatePreflight({numero:18,nomeArquivo:'PLS.xlsm',tamanhoBytes:800,sha256Excel:hashHex,pdfNome:'Anexo.pdf',pdfTamanhoBytes:200,sha256Pdf:result.pdfSha256});
assert.equal(meta.excel.sha256,hashHex);
assert.equal(meta.pdf.sha256,result.pdfSha256);
assert.throws(()=>validatePreflight({numero:18,nomeArquivo:'PLS.xlsm',tamanhoBytes:100,sha256Excel:'123'}),/SHA-256/);
assert.throws(()=>validatePreflight({numero:18,nomeArquivo:'PLS.xlsm',tamanhoBytes:100,sha256Pdf:hashHex}),/SHA-256/);
const other=resolvePreflight({meta,measurement:{status:'EM_EXECUCAO'},hashesExistentes:[{numero:17,versao:1}]});
assert.equal(other.duplicidadeOutraMedicao,true);
assert.equal(other.escritaPermitida,false);
const approved=resolvePreflight({meta,measurement:{status:'APROVADA',aprovado_em:'x'},hashesExistentes:[{numero:18,versao:1}]});
assert.equal(approved.duplicidadeMesmoArquivo,true);
assert.equal(approved.bloqueadoPorAprovacao,true);
assert.equal(OPERATIONAL_WRITES_ENABLED,false);
const client=readFileSync(new URL('../src/app/components/WorkOperationsPanel.js',import.meta.url),'utf8');
assert.ok(client.includes('inspectLocalFiles('));
assert.ok(!client.includes('new FormData'));
const http=readFileSync(new URL('../src/app/api/obras/[id]/envio/preflight/route.js',import.meta.url),'utf8');
assert.ok(http.indexOf('await requireWorkAccess')<http.indexOf('await request.json()'));
assert.ok(http.includes('measurement_versions v'));
assert.ok(http.includes('sha256Excel'));
for (const n of ['src/app/api/blob/presign/route.js','src/app/api/uploads/finalize/route.js','src/app/api/uploads/[id]/aprovar/route.js']) {
 assert.ok(readFileSync(new URL('../'+n,import.meta.url),'utf8').includes('blockedOperationResponse'));
}
console.log('OK NEXT-0.7D: leitura local, SHA, PDF, número indicativo, repetição, proteção por aprovação e bloqueio de gravação.');
