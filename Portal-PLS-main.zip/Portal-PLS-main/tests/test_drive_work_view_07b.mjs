import assert from 'node:assert/strict';
import { driveFileViewUrl,driveFolderViewUrl,mapInventoryForWork,mapPreviewForWork } from '../src/lib/pls/drive-work-view.js';

assert.equal(driveFileViewUrl('!bad'), null);
assert.equal(driveFolderViewUrl('1AbCD012345xyz_-'), 'https://drive.google.com/drive/folders/1AbCD012345xyz_-');
const inventory = mapInventoryForWork({foldersScanned:19,excelFiles:20,measurementsFound:[1,2,3],missingMeasurements:[4],reviewMeasurements:[2],
 preferredPerMeasurement:[
  {numeroMedicao:1,arquivo:'01.xlsm',driveFileId:'file123456789A',classificacaoCaminho:'PRINCIPAL'},
  {numeroMedicao:2,arquivo:'02.xlsm',driveFileId:'file987654321B',classificacaoCaminho:'PRINCIPAL',conflitoNumero:true},
  {numeroMedicao:3,arquivo:'03.xlsm',driveFileId:'file2222222222C',classificacaoCaminho:'PRINCIPAL'}]});
assert.equal(inventory.medicoes.length,3);
assert.equal(inventory.resumo.necessitaRevisao,1);
assert.equal(inventory.medicoes[0].numero,3);
assert.equal(inventory.medicoes[1].situacao,'REVISAR_FONTE');
assert.equal(inventory.somenteLeitura,true);
const view=mapPreviewForWork({numero:10,preview:{file:{name:'Jatoba.xlsm',driveFileId:'file123456789A'},
 parsed:{internalMeasurementNumber:9,parserProfile:'FAIXA_2_JATOBA',eventCount:133,summary:{previous:54.17,period:2.26,accumulated:56.43,periodValue:356343.93,valid:true}},
 validation:{status:'BLOQUEADO_DIVERGENCIA', reasons:['Número interno difere da pasta.']},
 temporalValidation:{status:'NAO_AVALIADO'}, warnings:['Número interno da planilha difere da pasta.']},allCandidatesCount:1});
assert.equal(view.numeroInterno,9);
assert.equal(view.validacaoPreliminar,'BLOQUEADO_DIVERGENCIA');
assert.equal(view.resumo.valorPeriodo,356343.93);
assert.equal(view.importacaoPermitida,false);
assert.equal(view.homologacaoMatrizes,'NAO_AVALIADA_NESTA_CONSULTA');
console.log('OK NEXT-0.7B: resumo documental, conflitos e rótulos, bloqueios, nomes duplicados e somente leitura.');
