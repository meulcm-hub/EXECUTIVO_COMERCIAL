import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {isLabConfigured,validateLabFiles,LAB_MAX_TOTAL_BYTES,LAB_PREFIX,labPath,sha256} from '../src/lib/pls/lab-upload.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const excel={name:'exemplo.xlsx',buffer:Buffer.concat([Buffer.from('504b0304','hex'),Buffer.alloc(30)])};
const pdf={name:'exemplo.pdf',buffer:Buffer.from('%PDF-1.7\nArquivo ficticio')};
const okay=validateLabFiles({numero:99,excel,pdf});assert.equal(okay.totalBytes,excel.buffer.length+pdf.buffer.length);
assert.equal(isLabConfigured({}),false);
assert.equal(isLabConfigured({PLS_LAB_UPLOAD_ENABLED:'true',PLS_LAB_BLOB_TOKEN:'separate',BLOB_READ_WRITE_TOKEN:'main'}),true);
assert.equal(isLabConfigured({PLS_LAB_UPLOAD_ENABLED:'true',PLS_LAB_BLOB_TOKEN:'same',BLOB_READ_WRITE_TOKEN:'same'}),false);
assert.equal(isLabConfigured({PLS_LAB_UPLOAD_ENABLED:'false',PLS_LAB_BLOB_TOKEN:'separate'}),false);
assert.throws(()=>validateLabFiles({numero:99,excel:{...excel,buffer:Buffer.alloc(15)}}),/Conteúdo/);
assert.throws(()=>validateLabFiles({numero:99,excel:{...excel,name:'..\\bad.xlsx'}}),/inválido/);
assert.throws(()=>validateLabFiles({numero:99,excel,pdf:{...pdf,name:'fake.pdf',buffer:Buffer.from('BADPDF')}}),/PDF/);
assert.throws(()=>validateLabFiles({numero:99,excel:{...excel,buffer:Buffer.concat([excel.buffer,Buffer.alloc(LAB_MAX_TOTAL_BYTES)])}}),/3 MiB/);
assert.match(labPath({labId:'11111111-2222-3333-4444-555555555555',kind:'excel',filename:'teste.xlsx'}),new RegExp('^'+LAB_PREFIX));
assert.equal(sha256(Buffer.from('abc')),'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
const lab=fs.readFileSync(root+'/src/app/api/laboratorio/envio/route.js','utf8');
assert.match(lab,/await requireGlobalAdmin\(\)/);assert.match(lab,/origin !== new URL\(request.url\).origin/);assert.match(lab,/isLabConfigured\(\)/);assert.match(lab,/access:'private'/);assert.match(lab,/await put\(/);assert.match(lab,/await get\(/);assert.match(lab,/await del\(/);
assert.doesNotMatch(lab,/insert into|update\s+measurements|delete\s+from|uploadBufferToDrive|sendPlsNotification|gmail/i);
const page=fs.readFileSync(root+'/src/app/page.js','utf8');assert.match(page,/href:'\/laboratorio'/);
const health=fs.readFileSync(root+'/src/app/api/health/route.js','utf8');assert.match(health,/NEXT-0.8B/);assert.match(health,/operationalWritesEnabled:\s*false/);
for(const route of ['src/app/api/blob/presign/route.js','src/app/api/uploads/finalize/route.js','src/app/api/uploads/[id]/aprovar/route.js']){
 const c=fs.readFileSync(root+'/'+route,'utf8');assert.match(c,/return blockedOperationResponse\(\);/);
}
console.log('OK NEXT-0.8B: laboratório isolado fechado por padrão, validação de assinaturas, SHA, armazenamento privado, descarte e endpoints oficiais bloqueados.');
