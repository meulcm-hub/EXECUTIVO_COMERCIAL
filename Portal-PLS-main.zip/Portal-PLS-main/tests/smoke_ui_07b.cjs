const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
function render(filename, componentName, values) {
 const code=fs.readFileSync(path.join(root, filename),'utf8')
  .replace(/^'use client';\s*/, '')
  .replace(/^import .*;$/gm,'')
  .replace(new RegExp(`export default function ${componentName}`), `function ${componentName}`)
  + `\nthis.__component=${componentName};`;
 const state={next:0,count:0};
 const createElement=(type,props,...children)=>{state.count+=1;return {type,props,children};};
 const useState=(initial)=>{const i=state.next++;return [Object.hasOwn(values,i)?values[i]:initial,()=>{}];};
 const react={createElement,Fragment:'fragment'};
 const context={React:react,useState,useEffect(){},useMemo(fn){return fn();},WorkDrivePanel:()=>({}),WorkOperationsPanel:()=>({}),OperationalReadiness:()=>({}),HistoryPanel:()=>({}),window:{location:{href:''}},console,Date};
 vm.createContext(context);vm.runInContext(code,context,{filename});
 const props=filename.includes('WorkDrivePanel')?{work:{id:'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',codigo:'216',nome:'Jatobá'}}:{};
 const node=context.__component(props);
 if(!node?.type || state.count<2) throw Error('Render falhou '+filename);
 return state.count;
}
const me={authenticated:true,user:{name:'Equipe LCM'},profile:{nome:'Equipe LCM',ativo:true,perfilGlobal:'ADMIN'}};
const obra={id:'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',codigo:'216',nome:'JATOBÁ',cidade:'BH',uf:'MG',faixa_pls:'FAIXA_2',perfil:'ADMIN'};
const rows={workId:obra.id,loading:false,rows:[],error:''};
const base=[me,[obra],false,'','obras','',obra,rows];
for(const [title,vals] of [
 ['Inicial',[null,[],true,'','painel','',null,rows]],
 ['Painel',[...base.slice(0,4),'painel','',null,rows]],
 ['Obras',[...base.slice(0,4),'obras','',null,rows]],
 ['Detalhe',base],
 ['Evolucao',[...base.slice(0,4),'implantacao','',null,rows]],
]) console.log('OK',title,render('src/app/page.js','Portal',vals));
const data={resumo:{medicoesEncontradas:1,arquivosExcel:1,necessitaRevisao:0,pastasExaminadas:15,lacunas:[]},medicoes:[{numero:18,arquivo:'Village.xlsm',pasta:'PLS 18',alertas:[]}],obra:{linkPasta:'https://drive.google.com/drive/folders/somefakeid'} };
console.log('OK Componente inicial',render('src/app/components/WorkDrivePanel.js','WorkDrivePanel',{}));
console.log('OK Componente com documentos',render('src/app/components/WorkDrivePanel.js','WorkDrivePanel',{0:{state:'ready',data,error:''},1:null,2:{state:'idle',number:null,data:null,error:''}}));
console.log('OK Componente com detalhe',render('src/app/components/WorkDrivePanel.js','WorkDrivePanel',{0:{state:'ready',data,error:''},1:18,2:{state:'ready',number:18,data:{validacaoPreliminar:'APTO',numeroInterno:18,eventos:83,perfil:'FAIXA_2_RESUMO',abas:['PLS HAB','RESUMO'],resumo:{anterior:98.58,periodo:1.42,acumulado:100,valorPeriodo:195417.44},observacoes:[]},error:''}}));

console.log('OK Operações',render('src/app/components/WorkOperationsPanel.js','WorkOperationsPanel',{}));
