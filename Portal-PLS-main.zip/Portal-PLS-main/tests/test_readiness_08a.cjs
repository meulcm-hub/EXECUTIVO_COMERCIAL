const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.resolve(__dirname,'..');
const api=fs.readFileSync(root+'/src/app/api/admin/operacao/prontidao/route.js','utf8');
const js=fs.readFileSync(root+'/src/app/components/HistoryPanel.js','utf8');
const readiness=fs.readFileSync(root+'/src/app/components/OperationalReadiness.js','utf8');
const page=fs.readFileSync(root+'/src/app/page.js','utf8');
const css=fs.readFileSync(root+'/src/app/globals.css','utf8');
assert.match(api,/export async function GET/);
assert.match(api,/await requireGlobalAdmin\(\)/);
assert(api.indexOf('await requireGlobalAdmin()')<api.indexOf('const sql=db()'));
assert.match(api,/operationalWritesEnabled:false/);
assert.match(api,/information_schema\.tables/);
assert.doesNotMatch(api,/insert into|delete from|update measurements|export async function POST/i);
assert.match(readiness,/fetch\('\/api\/admin\/operacao\/prontidao'/);
assert.match(page,/admin\?h\(OperationalReadiness,\{\}\):null/);
assert.match(css,/p-history-layout/);

let slots=[],idx=0;
const doc={items:[{id:'measurement1',numero:3,codigo:'328',obra_nome:'VILLAGE MOD III',versao:1,arquivo_nome:'PLS.xlsx',status:'EM_EXECUCAO',liberacao:{label:'Processamento pendente'}}],counts:{total:1,emExecucao:1,aprovadas:0,revisao:0},limited:false};
const ctx={React:{createElement(t,props,...children){return {type:t,props:props||{},children};},Fragment:'fragment'},useEffect(){},useMemo(fn){return fn();},useState(value){return [slots[idx++]??value,()=>{}];},console};
vm.createContext(ctx);
vm.runInContext(js.replace(/^'use client';\s*/,'').replace(/^import .*;$/gm,'').replace('export default function HistoryPanel','function HistoryPanel')+'\nthis.__HistoryPanel=HistoryPanel;',ctx);
function flat(value,result=[]){if(Array.isArray(value)){for(const x of value)flat(x,result);return result;}if(value&&typeof value==='object'){if(value.type)result.push(value);for(const x of value.children||[])flat(x,result);}return result;}
function text(value){return (value.children||[]).map(x=>typeof x==='string'?x:((x&&x.type)?text(x):'')).join('');}
function render(items){slots=[{phase:'ready',...items},'', 'TODOS',null,{phase:'idle',data:null,error:''}];idx=0;return flat(ctx.__HistoryPanel({work:{id:'work1',codigo:'328',nome:'VILLAGE MOD III'},goToWorks:()=>{}}));}
let tree=render(doc);
assert(tree.some(x=>x.type==='button'&&x.props.className?.trim()==='p-history-row'));
assert(tree.some(x=>x.type==='h1'&&text(x).includes('328')));
assert(tree.some(x=>x.type==='strong'&&text(x)==='1'));
tree=render({...doc,items:[],counts:{total:0,emExecucao:0,aprovadas:0,revisao:0}});
assert(tree.some(x=>x.type==='strong'&&text(x).includes('Nenhuma medição registrada')));
assert(!tree.some(x=>x.props?.type==='submit'));
console.log('OK NEXT-0.8A: prontidão admin, histórico real e empty state sem dados fictícios.');
