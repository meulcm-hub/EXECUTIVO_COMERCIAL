import assert from 'node:assert/strict';
import { buildEventPayloadFromWorkbook, structureFingerprint } from '../src/lib/pls/event-payload.js';

function colIndex(col) { return col.split('').reduce((n,c) => n*26 + c.charCodeAt(0)-64,0)-1; }
function colName(idx) { let s='';for(let n=idx+1;n;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s; }
const XLSX = { utils: {
  encode_cell: ({r,c}) => `${colName(c)}${r+1}`,
  encode_col: colName,
  decode_range: (s) => { const last = s.split(':').at(-1); const m = last.match(/([A-Z]+)(\d+)/); return { s: {r:0,c:0}, e: {c:colIndex(m[1]), r:Number(m[2])-1} }; },
  sheet_to_json: (ws) => ws.__rows,
}};
function ws(rows, formulas = {}) {
  const x = { __rows: rows, '!ref': `A1:${colName(Math.max(30,...rows.map((r)=>r.length)))}${rows.length}` };
  rows.forEach((row, r) => row.forEach((v,c) => { if (v !== undefined && v !== '') x[`${colName(c)}${r+1}`] = { v }; }));
  for(const [ref,formula] of Object.entries(formulas)) x[ref] = { ...x[ref], f:formula };
  return x;
}
function lines(length) { return Array.from({length},()=>[]); }

// Faixa 1: três eventos: dois DIRETO e um INDIRETO.
const hab = lines(25);
hab[17][19]='BLOCO A'; hab[18][19]='ETAPA'; hab[19][19]='APTO 101';
hab[20] = ['1.1','Fundação','DIRETO',2,1,'',0.5,'',1000,500];
hab[20][19]=1;
hab[21] = ['1.2','Paredes','DIRETO',2,1,'',0.3,'',600,300];
hab[21][19]=2;
hab[22] = ['1.3','Administração','INDIRETO',0,0,'',0.2,'',400,0];
const infra = lines(22);infra[17][19]='INFRA';infra[19][19]='LOCAL';infra[20]=['2.1','Pavimento','DIRETO',1,1,'',1,'',200,200];infra[20][19]=2;
const equip = lines(22);equip[17][19]='EQUIP';equip[19][19]='LOCAL';equip[20]=['3.1','Equipamento','DIRETO',1,1,'',1,'',100,100];equip[20][19]=2;
for (const [rows,r,prev,per,acc] of [[hab,20,1,0,1],[hab,21,0,1,1],[infra,20,0,1,1],[equip,20,0,1,1]]) {rows[r][10]=prev;rows[r][11]=per;rows[r][12]=acc;}
const w1={SheetNames:['Medição Global','PLS-Habitação','PLS-INFRA','PLS-Equipamentos'],Sheets:{
  'PLS-Habitação':ws(hab),'PLS-INFRA':ws(infra),'PLS-Equipamentos':ws(equip),
}};
const p1={parserProfile:'FAIXA_1_GENERICA', selectedSheet:'Medição Global', internalMeasurementNumber:2, eventCount:5,
  areaSheets:{habitacao:'PLS-Habitação',infraestrutura:'PLS-INFRA',equipamentos:'PLS-Equipamentos'}, budgets:{habitacao:2000,infraestrutura:200,equipamentos:100,global:2300}};
const r1=buildEventPayloadFromWorkbook({XLSX,wb:w1,parsed:p1,faixaPls:'FAIXA_1'});
assert.equal(r1.status, 'PAYLOAD_PRONTO_PARA_CONFERENCIA');
assert.equal(r1.eventRecords.length,5);
assert.equal(r1.eventRecords[0].exec_anterior,1);
assert.equal(r1.eventRecords[1].exec_periodo,1);
assert.ok(r1.eventRecords.find(e=>e.tipo_evento==='INDIRETO').perc_periodo!==null);
assert.match(r1.structureSha256,/^[a-f0-9]{64}$/);
assert.equal(structureFingerprint({a:2,b:3}),structureFingerprint({b:3,a:2}));
assert.notEqual(structureFingerprint({quantity:2}),structureFingerprint({quantity:3}));

// Faixa 2: duas linhas mensuráveis, um subtotal ignorado; contagem idêntica ao leitor.
const h2=lines(18);
h2[7]=['SERVIÇOS','MACRO','CÓD.','DISCRIMINAÇÃO','UNIDADE','QUANTIDADE','INCIDÊNCIA','PESO','','','','','','',''];
h2[8]=['1','Habitação','1.1','Serviço A','GLOBAL',4,0.4,0.4,1,1,2,25,50];
h2[9]=['1','Habitação','1.2','Serviço B','MES',12,0.6,0.6,2,1,3,10,30];
h2[10]=['1','Habitação','', 'SUBTOTAL','',12];
const w2={SheetNames:['PLS','RESUMO'],Sheets:{PLS:ws(h2),RESUMO:ws([])}};
const p2={parserProfile:'FAIXA_2_MED_GLOBAL',selectedSheet:'PLS',eventCount:2};
const r2=buildEventPayloadFromWorkbook({XLSX,wb:w2,parsed:p2,faixaPls:'FAIXA_2'});
assert.equal(r2.mappedEventCount,2);
assert.equal(r2.match,true);
assert.equal(r2.status,'PAYLOAD_REVISAR_MAPEAMENTO'); // Sem rótulos físicos não é carga apta.
assert.equal(r2.eventRecords[0].descricao,'Serviço A');
const r3=buildEventPayloadFromWorkbook({XLSX,wb:w2,parsed:{...p2,eventCount:3},faixaPls:'FAIXA_2'});
assert.equal(r3.status,'PAYLOAD_REVISAR_MAPEAMENTO');

// Quando a Faixa 2 contém outras abas PLS, exige reconciliação adicional.
const w3={...w2,SheetNames:['PLS','PLS INFRA','RESUMO'],Sheets:{...w2.Sheets,'PLS INFRA':ws([])}};
const r4=buildEventPayloadFromWorkbook({XLSX,wb:w3,parsed:p2,faixaPls:'FAIXA_2'});
assert.equal(r4.status,'PAYLOAD_REVISAR_MAPEAMENTO');
console.log('OK: 0.6C — Faixa 1, Faixa 2, indiretos, SHA estrutural, contagens e abas complementares.');
