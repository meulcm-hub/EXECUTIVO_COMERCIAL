import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {classifyLifecycle,statusCounts} from '../src/lib/pls/lifecycle-status.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const good={id:'version',vigente:true,status_versao:'EM_EXECUCAO',processing_state:'PROCESSADO',validation_status:'APTO'};
assert.equal(classifyLifecycle(null,null).code,'SEM_REGISTRO');
assert.equal(classifyLifecycle({status:'APROVADA'},null).code,'APROVADA_IMUTAVEL');
assert.equal(classifyLifecycle({status:'EM_EXECUCAO',aprovado_em:'2026-10-16'},good).code,'APROVADA_IMUTAVEL');
assert.equal(classifyLifecycle({status:'EM_EXECUCAO'},null).code,'SEM_VERSAO');
assert.equal(classifyLifecycle({status:'EM_EXECUCAO'},{...good,vigente:false}).code,'VERSAO_NAO_VIGENTE');
assert.equal(classifyLifecycle({status:'DESAPROVADA'},good).code,'ESTADO_RESTRITO');
assert.equal(classifyLifecycle({status:'EM_EXECUCAO'},{...good,processing_state:'AGUARDANDO_PARSER'}).code,'PROCESSAMENTO_PENDENTE');
assert.equal(classifyLifecycle({status:'EM_EXECUCAO'},{...good,validation_status:'BLOQUEADO_DIVERGENCIA'}).code,'VALIDACAO_PENDENTE');
assert.equal(classifyLifecycle({status:'EM_EXECUCAO'},{...good,validation_status:null}).code,'VALIDACAO_PENDENTE');
assert.equal(classifyLifecycle({status:'EM_EXECUCAO'},good).code,'HOMOLOGACAO_PENDENTE');
for (const state of ['APROVADA_IMUTAVEL','SEM_VERSAO','VALIDACAO_PENDENTE','HOMOLOGACAO_PENDENTE']) {
 const item=state==='APROVADA_IMUTAVEL'?classifyLifecycle({status:'APROVADA'},good):state==='SEM_VERSAO'?classifyLifecycle({status:'EM_EXECUCAO'},null):state==='VALIDACAO_PENDENTE'?classifyLifecycle({status:'EM_EXECUCAO'},{...good,validation_status:null}):classifyLifecycle({status:'EM_EXECUCAO'},good);
 assert.equal(item.permitted,false);
}
assert.deepEqual(statusCounts([{status:'APROVADA',versao_id:'v1'},{status:'EM_EXECUCAO',versao_id:null},{status:'DESAPROVADA',versao_id:'v2'}]),{total:3,aprovadas:1,emExecucao:1,revisao:1,semVersao:1});
const api=fs.readFileSync(root+'/src/app/api/operacao/historico/route.js','utf8');
const detail=fs.readFileSync(root+'/src/app/api/operacao/historico/[id]/route.js','utf8');
const ui=fs.readFileSync(root+'/src/app/components/HistoryPanel.js','utf8');
const page=fs.readFileSync(root+'/src/app/page.js','utf8');
const health=fs.readFileSync(root+'/src/app/api/health/route.js','utf8');
for (const code of [api,detail]) {
 assert.match(code,/export async function GET/);
 assert.doesNotMatch(code,/export async function POST|insert into|update\s+measurements|delete from|sendPlsNotification/);
 assert.match(code,/no-store/);
}
assert.match(api,/requireUser\(/);
assert.match(api,/getUserContext\(/);
assert.match(api,/work_access/);
assert.match(detail,/requireWorkAccess\(/);
assert.match(ui,/Histórico da obra|Histórico e aprovações/);
assert.match(page,/abrirHistorico\(/);
assert.match(health,/operationalWritesEnabled:\s*false/);
for(const route of ['src/app/api/blob/presign/route.js','src/app/api/uploads/finalize/route.js','src/app/api/uploads/[id]/aprovar/route.js']) {
 const code=fs.readFileSync(root+'/'+route,'utf8');
 assert.match(code,/return blockedOperationResponse\(\);/);
}
console.log('OK NEXT-0.8A: histórico nativo, bloqueio de homologação, acesso por obra e endpoints somente leitura.');
