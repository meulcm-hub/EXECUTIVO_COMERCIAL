# NEXT-0.6E — Conferência detalhada e assinatura estrutural V3

## Evidência que motivou o ajuste

No teste real de **328 - VILLAGE MOD III, M18**, a 0.6D mapeou 83/83 eventos, 120 posições físicas, 76 serviços com matriz e 5.674 células preenchidas. Ela bloqueou o payload por divergência na linha 71, unidade FACE.

Na planilha original `PLS_18 VILLAGE LAGOAS_MOD-03 -.xlsm`:
- `F71` usa a fórmula `=7*10`, quantidade oficial 70;
- `I71` registra 70 anteriores, `J71` 0 no período e `K71` 70 acumulados;
- 72 células de matriz estão preenchidas com números de medições anteriores (12 em cada BLOCO 19 a 24);
- `DG18` contém o rótulo de posição `169`, atípico frente ao padrão `101` na primeira posição dos demais blocos.

**Nenhum desses dados foi alterado.** É necessária conciliação com a engenharia antes de considerar a fonte integralmente pronta.

## Corrigido/novo

1. O leitor separa cabeçalhos de locais físicos (`BLOCO ...`, `QUADRA ...`, `TORRE ...`, etc.) de datas/seriais Excel e dados operacionais. Esses últimos não entram mais na identidade dos grupos do `structure_snapshot_json`. Por isso o schema do fingerprint passou para **V3**; V2 e V3 não são comparáveis diretamente.
2. Para cada divergência em serviço locacional, a API retorna quantidade e contagens oficiais, contagens derivadas, fórmula da quantidade quando disponível, referências de células preenchidas e totais **por grupo físico**. Esses dados não substituem os valores oficiais.
3. Para cabeçalhos sem rótulo, o endpoint expõe `labelIssues` com referências exatas das células, facilitando depuração de casos específicos do leitor.
4. O portal mostra como **observação** rótulos iniciais de grupos que fogem de um padrão predominante (ex. DG18), sem editar o Excel ou presumir que seja erro.
5. Mantidas as regras existentes: candidato seguro, validação temporal, SHA-256 dos arquivos, bloqueio por candidatos divergentes, impossibilidade de alterar medição aprovada e controle administrativo de acesso.

## Segurança e limites

- Somente leitura de Drive e SELECT do Neon. Nenhum INSERT/UPDATE/DELETE; `importEnabled:false`.
- Importação histórica permanece desabilitada, independentemente do status do relatório.
- A 0.6E **não reconcilia** as demais abas complementares não processadas e **não homologa** fórmulas/quantidades automaticamente.
- O alerta de `ROTULOS_INCOMPLETOS` só poderá ser encerrado quando soubermos quais células são de fato identificadas como ausentes no mesmo leitor de produção; a API agora as expõe.
- Os rótulos/quantidades atípicos devem ser avaliados pelas equipes responsáveis; não há edição do Excel.

## Testes

- `node tests/test_payload_06c.mjs`
- `node tests/test_payload_06d.mjs`
- `node tests/test_payload_06e.mjs`
- conferir saúde e medição M18 na Vercel, depois Patos I M13 sem regressão.
