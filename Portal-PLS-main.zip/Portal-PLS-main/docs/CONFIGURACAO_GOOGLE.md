# Configuração Google necessária para homologação

Serão necessárias duas integrações OAuth.

## Login dos usuários

OAuth Client para Web Application com callback:

`https://SEU-DOMINIO/api/auth/google/callback`

Escopos: `openid email profile`.

## Conta corporativa para Drive/Gmail

Uma conta corporativa dedicada ou conta aprovada pela TI deve autorizar os escopos mínimos necessários para:

- Google Drive: localizar/criar pasta da medição e criar arquivos.
- Gmail: enviar o e-mail único da PLS.

O refresh token deve ficar somente nas variáveis de ambiente. Nunca no repositório.
