# NEXT-0.7C — Gestão de medições (homologação segura)

## Evidências utilizadas
- Na pasta `0 - PLS` do Drive há 15 obras ativas catalogadas.
- Em `328 - VILLAGE MOD III / PLS 18 - 09.2026 (17º medição)` coexistem Excel, PDFs e um arquivo 7z.
- O portal 0.7B lê o Drive e o Neon, mas ainda não substituiu os fluxos de upload/aprovação da V3.44.2.

## Entrega técnica
1. Novo componente `WorkOperationsPanel` em **Obras e medições → Obra** com o fluxo operacional visual: seleção, envio, conferência, aprovação e arquivo.
2. Indicadores do Neon baseados em `measurements`, nunca na mera existência de arquivos do Drive.
3. **Pré-checagem sem envio**: selecionar Excel (XLS/XLSX/XLSM/XLSB), PDF opcional e número de medição. O cliente envia **apenas nome e tamanho** dos arquivos à API `POST /api/obras/[id]/envio/preflight`.
4. A API exige usuário autorizado na obra, valida metadados, verifica medição existente e detecta aprovação bloqueante no Neon. Não baixa, não transmite arquivo e não grava. Resultado explícito `escritaPermitida:false`.
5. Leitura sob demanda dos **PDFs que estão na mesma pasta do Excel candidato**, após a conferência existente da PLS; nenhum PDF é marcado como assinado/oficial apenas pelo nome.
6. Previews `APTO` agora dizem **leitura preliminar apta, matriz não homologada**, para não confundir contagem de eventos com liberação de importação.
7. Bloqueio explícito HTTP 423 nos endpoints antigos `POST /api/blob/presign`, `POST /api/uploads/finalize`, `POST /api/uploads/[id]/aprovar`, evitando que uma chamada direta escape da interface `/upload` protegida.
8. Sem SQL, sem alteração de schema, sem envio de e-mail e sem upload de documentos nesta versão.

## Limites e salvaguardas
- Documentos em subpastas diferentes do Excel selecionado não são pesquisados pela lista de PDFs desta versão.
- O formulário não analisa o conteúdo binário dos arquivos locais, apenas seus metadados. Não substitui o parser nem detecta o número de medição interno.
- Arquivos no Drive não são automaticamente declarados medições aprovadas nem versões oficiais.
- O Portal original Google Apps Script permanece operacional e oficial para uploads, alterações, aprovações, PDFs e notificações.
- A futura ativação de escrita requer implementação atômica, autorização de usuários, aprovação imutável, controles de concorrência, conciliação de matriz, origem e SHA, e tratamento de falhas de Drive/Neon.
- Não executar `sql/004_domain_schema_v2_DEFERRED.sql`.

## Teste na Vercel
1. `/api/health` deve exibir `NEXT-0.7C` e `operationalWritesEnabled:false`.
2. Login Google → Obras e medições → 328 - VILLAGE MOD III.
3. Conferir a seção `Envios, versões e aprovações`, status vazio ou real proveniente do Neon.
4. Na pré-checagem, selecionar um Excel local sem enviar e um número de medição, clicar `Conferir sem enviar`. Deve aparecer o resultado de homologação sem nova versão no Neon.
5. Em `Consultar documentos`, abrir M18 e ver **83 eventos, 1,42% no período, 100% acumulado** e lista de PDFs existentes na mesma pasta, sem indicar assinatura garantida.
6. Verificar `POST /api/blob/presign`, `POST /api/uploads/finalize`, `POST /api/uploads/<id>/aprovar` retorna HTTP 423. Não executar chamadas com credenciais ou payloads reais de escrita.
7. Administrador → Auditoria técnica e comparar Patos I M13 237, Village MOD III M18 83. Escrita continua proibida.

## Próxima etapa
- 0.7D: fluxo controlado de upload/versionamento (piloto isolado, confirmação explícita, parser validado, dupla checagem no Neon/Drive), assinatura/aprovação e outbox de notificações após homologação específica. Não ativar escrita só pela existência da pré-checagem.
