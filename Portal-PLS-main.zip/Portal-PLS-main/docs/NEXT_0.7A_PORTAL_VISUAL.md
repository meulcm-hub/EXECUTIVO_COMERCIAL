# NEXT-0.7A — Portal executivo e consulta de obras

## Entrega
- Página inicial autenticada, com logo LCM extraída da referência legada V3.44.2 e layout responsivo.
- Painel executivo com quantidade REAL de obras acessíveis vinda de `GET /api/obras`, lista de obras do Neon, estágios de implantação (marcos de engenharia identificados como tais).
- Lista pesquisável de obras pelo nome, código, local e faixa. Identidade preservada pelo ID UUID da obra, não apenas código numérico.
- Detalhe da obra: `GET /api/obras/[id]/medicoes` com dados reais da tabela `measurements`. Sem medições gravadas => mensagem transparente, sem simulação.
- Acesso separado ao diagnóstico preservado em `/admin/auditoria` (cópia do código NEXT-0.6F). APIs continuam impondo ADMIN.
- Link explícito ao Apps Script atual para processos de operação ainda não migrados.
- Nenhum novo endpoint de gravação, sem alterações de banco ou schema.

## Não entregue (não alegar na reunião)
- Importação histórica e versionamento populado no Neon.
- Aprovação, assinatura, edição de medições, geração de PLS/PDF, e-mail em produção na NEXT.
- Dados de progresso físico por obra sem que as medições estejam migradas.

## Publicação
1. Fazer backup ou guardar commit da NEXT-0.6F como ponto de retorno.
2. Extraia e copie arquivos `src` e `public` deste patch para raiz do repositório GitHub, preservando diretórios. `src/app/admin/auditoria/page.js` é NOVO.
3. Commit e aguarde deploy na Vercel.
4. Verifique `/api/health` retorna `NEXT-0.7A`.
5. Faça login Workspace. Verifique visão geral e navegue em Obras e medições. Abra uma obra. Confira painel de medições; na ausência de importação, vazio é esperado.
6. Como ADMIN, use o link Auditoria técnica; repita Patos I M13 => 237 e Village MOD III M18 => 83, importação desabilitada.
7. Confira o link externo para Apps Script antigo. Não altere o ambiente antigo.

## Segurança
Não habilitar endpoints de escrita por engano. Manter `/upload` bloqueado. Nenhum SQL novo. Não executar `004_domain_schema_v2_DEFERRED.sql`.
