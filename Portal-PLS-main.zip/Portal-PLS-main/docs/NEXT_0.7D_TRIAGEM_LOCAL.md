# Portal PLS LCM | NEXT-0.7D — Pré-conferência de arquivos no navegador

## Objetivo
Continuar o módulo operacional sem habilitar gravações reais. A nova pré-checagem abre os bytes do Excel/PDF **apenas no navegador do usuário**, verifica assinatura do arquivo, lê nomes das abas, procura uma aba principal por perfil de PLS, calcula SHA-256 e envia à API **somente os metadados e as assinaturas**. No Neon é feita uma consulta SELECT para identificar se a mesma assinatura já consta entre as versões da obra. A assinatura enviada pelo usuário NÃO é evidência oficial: será necessário recalculá-la no servidor quando o upload real for desenvolvido.

## Segurança
- O browser não transmite o conteúdo do Excel ou PDF no formulário 0.7D.
- Nada é escrito no Drive, Neon ou Blob. Nenhum e-mail é enviado.
- Endpoints existentes POST /api/blob/presign, /api/uploads/finalize e /api/uploads/[id]/aprovar seguem retornando HTTP 423.
- Aprovados no Neon permanecem imutáveis. Todos os usuários devem ter acesso à obra para checar metadados.
- Resultado é triagem local, NÃO homologação e NÃO liberação para importar/assinar.
- Duplicidade considerada nesta tela é apenas com o que já existe no Neon, não com todo o acervo do Drive.
- É possível que alguns formatos de XLS/XLSB precisem de tratamento adicional; não concluir que são inválidos sem revisão.

## Instalação
O ZIP é um PATCH sobre NEXT-0.7C. Extrair e copiar o conteúdo **dentro** da pasta do ZIP para a raiz do repositório GitHub, preservando os caminhos. Substituir somente os caminhos presentes neste pacote; criar os novos caminhos. Commit e aguardar a Vercel.
**NÃO** executar SQL, não criar variáveis Vercel, não executar `004_domain_schema_v2_DEFERRED.sql`.

## Teste único de implantação
1. Abrir https://portal-pls.vercel.app/api/health e confirmar `NEXT-0.7D` com `operationalWritesEnabled:false`.
2. Fazer login, abrir Obras e medições > 328 - VILLAGE MOD III > Envios, versões e aprovações.
3. Escolher M18, selecionar localmente a planilha real `PLS_18 VILLAGE LAGOAS_MOD-03 -.xlsm` e, opcionalmente, o PDF.
4. Clicar `Conferir arquivo sem enviar`. Esperado: aba `PLS HAB`, duas abas, SHA-256 da planilha começando `162f00742bd2...`, aviso de triagem e SEM registro criado no Neon.
5. Se a Vercel der erro de compilação, enviar o log exato. Se o navegador mostrar erro, enviar a mensagem exibida.

## Testes técnicos locais
- `node scripts/static-check.mjs`
- `node tests/test_local_preflight_07d.mjs`
- `node tests/test_operational_07c.mjs`
- `node tests/test_preflight_endpoint_07c.cjs`
- `node tests/test_payload_06c.mjs` etc.

O ambiente de preparação não concluiu `npm install`, então **a compilação Next.js completa não foi validada**; a Vercel precisa confirmar o build. O teste local da leitura foi feito com workbook simulado, não com o pacote XLSX instalado no navegador.
