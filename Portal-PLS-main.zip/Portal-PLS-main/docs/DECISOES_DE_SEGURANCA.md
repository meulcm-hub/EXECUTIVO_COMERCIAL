# Decisões deliberadas de segurança

1. **Não confiar no navegador para números da PLS.** O novo parser será server-side.
2. **Não permitir aprovação nesta V0.1.** O endpoint existe, porém exige `processing_state=PROCESSADO`, estado que só será produzido depois da equivalência do parser.
3. **Não sobrescrever Excel anterior.** Nova versão -> anterior `SUBSTITUIDA`.
4. **Não inferir medição por `PLS17` quando a pasta é `12ª Medição`.** Pasta numerada é autoridade física.
5. **Não expor segredo OAuth/Drive/Gmail no cliente.**
6. **Não enviar Excel de 15 MB pelo corpo da Function Vercel.** Upload direto a Blob privado.
7. **Não usar Google Sheets como banco operacional do novo portal.**
