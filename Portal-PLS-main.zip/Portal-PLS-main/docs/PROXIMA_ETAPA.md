# Próxima etapa técnica

A V0.2 deve focar exclusivamente no parser e na equivalência numérica.

1. Extrair do `Index.html` da V3.44.2 as funções puras usadas por `interpretarWorkbookPls`.
2. Remover dependências de DOM/navegador.
3. Executar o parser no Node sobre os mesmos arquivos PLS usados na produção.
4. Criar testes de regressão com:
   - obra 238 - IPÊ MOD II;
   - uma obra Faixa 1;
   - PLS com HAB + INFRA;
   - arquivo XLSM com macros;
   - arquivo histórico antigo.
5. Comparar: número da medição, período, acumulado, quantidade de eventos, incidências e matriz.
6. Somente quando os resultados forem idênticos alterar `processing_state` para `PROCESSADO`.
