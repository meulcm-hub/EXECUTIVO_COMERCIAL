# NEXT-0.6C — Payload de eventos e fingerprint estrutural (sem gravação)

## Estado do projeto
- Derivada de NEXT-0.6B. O schema histórico já foi aplicado e conferido como `ready`.
- O sistema antigo Apps Script V3.44.2 continua sendo a produção/contingência.
- Nenhum SQL novo é exigido ou autorizado nesta etapa. `004_domain_schema_v2_DEFERRED.sql` continua **NÃO EXECUTAR**.
- `importEnabled:false`. Não há endpoint de importação nem qualquer gravação em `measurements`, `measurement_versions`, `measurement_events`, `measurement_source_files`, tabelas de migração, Drive ou Gmail.

## Comportamento
1. Na tela da obra, `Auditar PLS`; escolha uma medição e clique `Conferir payload 0.6C`.
2. O endpoint autenticado `POST /api/admin/migration/payload-preview`, apenas para ADMIN, faz leitura única do workbook e reaplica a validação de número, datas, resumo e candidatos.
3. O servidor mapeia todas as linhas de eventos da aba principal (Faixa 2) ou das três áreas principais (Faixa 1), confere a quantidade com a leitura oficial e prepara as colunas previstas em `measurement_events`.
4. Calcula fingerprint SHA-256 da estrutura: abas, linha/área, identificadores de eventos, quantidades planejadas, incidências, valores estruturais, fórmulas estáveis de planejamento e rótulos de posições da Faixa 1. Não é o SHA do Excel bruto.
5. Esboça registros para `measurement_source_files`, `measurements` e `measurement_versions`, incluindo ID do Drive, mas deixa UUIDs, versão vigente e identidade do importador para resolução transacional futura.
6. A tela exibe quantidade total, cobertura por área, assinatura estrutural, status, pontos para revisão e uma amostra de 12 eventos; a lista completa é produzida **somente em memória**. A API não envia todas as matrizes ao navegador por padrão.

## LIMITAÇÕES INTENCIONAIS — não liberar gravação
- A Faixa 2 pode possuir `PLS INFRA`/`PLS INFRA NI` além de `PLS HAB`: a 0.6C ainda só mapeia os eventos da **aba principal**, tal como o contador da 0.6A. Quando existem abas complementares, retorna `PAYLOAD_REVISAR_MAPEAMENTO`; não se declara payload integral da obra.
- A Faixa 2 ainda não reconcilia matrizes/locais e glosas de todas as famílias de layout. Campos desconhecidos permanecem `null`; não inventar execução ou valor.
- Na Faixa 1, matrizes das áreas principais vêm das colunas de posições. Indiretos têm percentual calculado de forma proporcional, mas não têm execução física discreta. Precisam de conferência contra a versão aprovada da planilha antes do primeiro INSERT.
- O hash de estrutura V1 é **informativo**. Não comparar com uma linha-base aprovada para bloquear uploads até homologar sua estabilidade entre medições da mesma obra.
- A 0.6C não compara ainda o snapshot completo com o modelo padrão aprovado; não tem detecção definitiva de fraude estrutural.
- Status `PAYLOAD_PRONTO_PARA_CONFERENCIA` **não autoriza importação**. Só sinaliza que quantidade de linhas e identidade mínima conferiram. `importEnabled` continua `false`.
- O preview não escolhe automaticamente um arquivo divergente, não marca medições antigas como aprovadas, não altera versões existentes.

## Testes de homologação recomendados
1. Deploy GitHub → Vercel e GET `/api/health`: `NEXT-0.6C`.
2. GET `/api/admin/migration/schema-health`: `historicalMigrationSchema=ready`, listas `missing...=[]`, `importEnabled=false`.
3. Obra **607 PATOS I**, M13, botão `Conferir payload 0.6C`: 237 eventos lidos x 237 mapeados; revisar incidências/quantidades e matriz dos primeiros eventos, `OK_INTERNO`, `APTO` no arquivo. Ainda não importar.
4. Obra **328 VILLAGE MOD III**, M18: 83 x 83; confirmar se há abas complementares e se retorna revisão apropriada. Conferir valores da Faixa 2.
5. Caso negativo: **218 SANTA CATARINA M24** deve continuar `BLOQUEADO_DATA`; **238 IPÊ MOD I M25** continua `BLOQUEADO_DIVERGENCIA` — mesmo que o payload consiga contar os eventos.
6. Testar caso de duplicado Itaituba II M17; candidato com mesmo SHA não pode virar versão adicional.

## Decisões futuras antes da 0.6D
- Definir campo oficial de unidade/identidade da Faixa 1 e harmonização numérica das incidências entre famílias.
- Reconciliar abas secundárias e matriz da Faixa 2.
- Validar fórmulas e resultados do motor em comparação com as PLS reais e o Apps Script aprovado.
- Planejar transaction/locks/idempotência de versões/validação de permissões sem reabrir aprovações existentes.
- Implementar executor transacional em etapa independente, desligado por padrão e testado em homologação.
