# NEXT-0.8B — Laboratório de envio isolado

Esta atualização **não autoriza uploads oficiais**. Testa, como ADMIN, a transferência de um Excel de teste e PDF opcional até uma **Vercel Blob Private Store separada**, calcula SHA-256 no servidor, confere a integridade lendo o mesmo Blob e elimina os arquivos ao final. **Não cria nem altera registros no Neon**, nem acessa o Drive/Gmail.

## Ativação explícita

As duas variáveis devem ser configuradas **pela equipe técnica na Vercel**:

- `PLS_LAB_UPLOAD_ENABLED=true` (valor exato)
- `PLS_LAB_BLOB_TOKEN` com o token de uma **Private Blob Store criada exclusivamente para testes**. Não pode ser o mesmo `BLOB_READ_WRITE_TOKEN` usado em operações existentes.

O padrão é **DESATIVADO**. Não compartilhe os valores das variáveis no chat, prints ou GitHub.

**Use apenas um Excel sintético de testes**, nunca medições oficiais reais. O limite por solicitação é 3 MiB, devido ao limite de tamanho de Functions. Excel e PDF opcionais são verificados por assinatura mágica e extensão. O PDF não tem seu conteúdo semântico validado. A função também verifica se já existe uma medição aprovada naquele número; caso exista, impede o teste.

Se a operação falhar ou a função terminar abruptamente, um Blob de teste pode permanecer; a equipe deve verificar a Private Store e limpar o prefixo `lcm-pls-lab-08b/`. Na execução normal, ela confirma leitura e apaga o objeto.

Caminho: `/laboratorio` (visível no menu apenas para ADMIN). A rota `POST /api/laboratorio/envio` exige sessão de administrador e confere o ID da obra.

Os endpoints operacionais `/api/blob/presign`, `/api/uploads/finalize` e `/api/uploads/[id]/aprovar` permanecem bloqueados. Nenhum SQL e nenhuma pasta oficial devem ser alterados para instalar a 0.8B.

Para evitar transferências acidentais, **não configure as variáveis até estar pronto para o primeiro teste sintético autorizado.**

## Arquivo fictício pronto para o primeiro teste

Utilize `exemplos/PLS_TESTE_FICTICIA_08B.xlsx` do pacote. Contém somente nomes e valores inventados e uma aba `PLS HAB`. Esse arquivo verifica o transporte e o descarte, não reproduz os cálculos reais de PLS. Não use número de medição já aprovado.
