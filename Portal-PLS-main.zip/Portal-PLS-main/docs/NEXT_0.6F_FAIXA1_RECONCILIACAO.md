# NEXT-0.6F — Faixa 1: comparação oficial × matriz

Somente leitura. Atualização incremental para a NEXT-0.6E.

- O leitor preserva indicadores K/L/M da planilha da Faixa 1, sem substituí-los por contagem reconstruída.
- Compara as posições T... com K/L/M (Anterior, Período, Acumulado), por serviço e aba.
- Exibe a contagem de células preenchidas em Faixa 1 (elimina `? preenchidas`), glosas, totais derivados e células zeradas nas divergências.
- Sinaliza células de matriz inválidas e números de medição maiores que o número atual.
- Mantém status `PAYLOAD_REVISAR_MAPEAMENTO` quando houver diferenças; nunca grava no Neon/Drive e não importa dados.
- Mantém hash estrutural V3 para estabilidade entre 0.6E e 0.6F, pois o formato do modelo não mudou.

## Expectativa Patos I — M13

O arquivo verificado apresentou 237 eventos, sendo 91 Habitação, 101 Infraestrutura e 45 Equipamentos. Confronto independente em XML revelou 1 divergência em `PLS-INFRA!31`, serviço 2.1.1: K=1, L=0, M=1, T31=0. Não corrigir Excel automaticamente; engenharia deve esclarecer.

## Testes

`node tests/test_payload_06f.mjs` mais testes 06c/06d/06e. São testes sintéticos; a homologação no Portal ainda é obrigatória.
