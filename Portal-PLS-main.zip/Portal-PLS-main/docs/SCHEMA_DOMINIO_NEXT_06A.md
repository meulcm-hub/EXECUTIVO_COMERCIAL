# Portal PLS LCM — proposta de domínio após a auditoria NEXT-0.5C

> **NÃO EXECUTAR SQL AINDA.** Este documento é somente a proposta de desenho para a próxima fase.
> O arquivo `sql/004_domain_schema_v2_DEFERRED.sql` continua adiado e não deve ser executado nesta versão.

## Princípios confirmados nos arquivos reais

1. `works` continua sendo a identidade da obra; o `drive_folder_id` é a identidade externa mais confiável.
2. `measurements` representa uma medição lógica única por obra + número.
3. `measurement_versions` representa versões oficiais/candidatas do Excel, preservando Drive ID e SHA-256.
4. Arquivos encontrados no Drive não devem virar automaticamente versões oficiais. OBS, modelo, teste, obsoleto, arquivo conflitante e duplicado físico precisam continuar auditáveis.
5. Aprovação torna a versão imutável; substituição cria nova versão.
6. Divergência de número, data, resumo ou candidatos diferentes bloqueia importação automática.
7. Duplicados byte a byte (mesmo SHA-256) não constituem versões de conteúdo diferentes.

## Campos que a versão de medição precisa congelar

Além dos campos já existentes em `measurement_versions`, a versão final deverá guardar:

- `parser_profile`
- `source_filename`
- `source_path`
- `source_parent_folder_id`
- `source_measurement_folder_name`
- `internal_measurement_number`
- `period_reference_raw`
- `validation_status`
- `validation_reasons` (JSON)
- `temporal_validation_status`
- `candidate_resolution` (único, duplicados idênticos, revisão manual)
- `sha256_arquivo`
- futuramente: `structure_sha256` e `structure_snapshot_json` para proteção estrutural.

## Nova entidade recomendada: measurement_source_files

Nem todo Excel existente no Drive deve ser uma `measurement_version`. Recomenda-se uma tabela de inventário/rastreabilidade dos arquivos encontrados, com:

- obra e número detectado;
- `drive_file_id` único;
- nome e caminho;
- tamanho e datas do Drive;
- número pela pasta, pelo nome e interno;
- papel (`PLS_CANDIDATA`, `MODELO`, `TESTE`);
- classificação do caminho (`PRINCIPAL`, `OBSERVACAO`, `OBSOLETO`, `PENDENCIA`);
- SHA-256 quando calculado;
- status da validação;
- indicação de fonte selecionada;
- metadados adicionais em JSON.

Isso permite preservar a bagunça histórica do Drive como evidência sem transformar todos os arquivos em versões oficiais.

## Próximo passo antes do SQL definitivo

A NEXT-0.6A gera uma prévia histórica por obra e medição, ainda sem gravar nada. Depois de revisar essa prévia, será preparado um novo SQL aditivo e idempotente já compatível com os casos reais encontrados. Até lá, não executar o `004_domain_schema_v2_DEFERRED.sql`.
