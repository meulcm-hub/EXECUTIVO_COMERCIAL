# NEXT-0.6D — Conferência das matrizes de localização em modo somente leitura

Base: NEXT-0.6C, com Neon historicalMigrationSchema `ready`. Sem nova migração SQL.

## O que foi corrigido
- Na Faixa 2, para serviços com execução por local, a leitura busca o início da matriz usando a seção `LOCAL E ÉPOCA DE EXECUÇÃO DO EVENTO` e identifica a linha de rótulos de locais. O perfil especial Jatobá mantém início na coluna Q para PLS HAB.
- Preserva `null` (vazio), valores numéricos e glosas `G` separadamente; não substitui uma execução oficial por cálculo derivado.
- Conserva na matriz JSON os pares coluna/rótulo/grupo (como BLOCO 19 + APTO 101), valores reais da célula e o diagnóstico de conciliação por número de medição.
- A estrutura V2 inclui grupos e rótulos da matriz; não inclui o preenchimento da medição, pois execução não é alteração do modelo. SHA estrutural V2 não deve ser comparado diretamente ao V1 da versão anterior.
- `MESES` e unidade percentual com 100 repetições são eventos temporais: não se inventa matriz física.
- Mantém toda validação da 0.6C: número dentro do XLSM, período/data, SHA do arquivo, duplicados/candidatos, quantidade de eventos e aprovação imutável.
- Se não identificar rótulos ou valores consistentes, `PAYLOAD_REVISAR_MAPEAMENTO`, sem ação de importação.
- Se houver outras abas de eventos PLS, mantém aviso e bloqueio de mapeamento por falta de reconciliação das abas complementares.

## Limitações deliberadas
O payload ainda é PREVIEW, não reconcilia todas as fórmulas nem garante cobertura integral de outras abas PLS, especialmente Infraestrutura. Não calcula glosas financeiras sem valor oficial do evento. Os campos `glosas` e `valor_glosa` continuam sem suposição de preço. A verificação compara contagens discretas somente quando a matriz usa números de medição como identificador e sinaliza eventuais discrepâncias; um status de revisão exige comparação humana da PLS.

## Segurança
- Endpoint POST /api/admin/migration/payload-preview continua protegido por requireGlobalAdmin.
- Resposta inclui `importEnabled:false`, `readOnly:true`; `canImport:false`.
- A execução é exclusivamente SELECT no Neon e leitura Drive. Sem alterações de Drive, Gmail ou dados de medições.
- `004_domain_schema_v2_DEFERRED.sql`: **NÃO EXECUTAR**.

## Plano de testes
1. GET /api/health = NEXT-0.6D.
2. GET /api/admin/migration/schema-health => ready, missingTables=[], missingMeasurementVersionColumns=[], importEnabled=false.
3. Village MOD III M18: 83 lidos/83 mapeados, grade de matriz deixa de ser `—` para serviços por local; conferir rótulos de posição e quantidade de divergências. A origem da planilha é `PLS HAB` e `RESUMO`.
4. Patos I M13: 237 lidos/237 mapeados; Faixa 1 mantém distribuição HABITACAO 91, INFRAESTRUTURA 101, EQUIPAMENTOS 45.
5. Santa Catarina M24: não importar por datas e abas complementares não reconciliadas.
6. Confirmar que NENHUMA mudança foi feita em medições Neon ou no Drive.

Não prosseguir para importação sem revisão/aceite dos resultados reais.
