# Arquitetura alvo — Portal PLS LCM

## Fluxo de leitura

Navegador -> Next.js/Vercel -> PostgreSQL

O Drive não é consultado para montar dashboard, histórico ou descobrir a última medição. Esses dados vêm do PostgreSQL por índices.

## Fluxo de upload

1. Usuário autenticado seleciona Excel, obra, competência e número da medição.
2. O servidor autoriza uma URL temporária e restrita.
3. O navegador envia o arquivo direto para Blob privado. O Excel de até 15 MB não atravessa o corpo de uma Function da Vercel.
4. A Function recebe apenas o pathname do Blob, lê o arquivo do armazenamento privado e calcula SHA-256.
5. O Excel é interpretado no servidor.
6. O Portal localiza a pasta já existente `Nª Medição` na raiz da obra; só cria quando não existir.
7. O arquivo é enviado ao Drive corporativo.
8. PostgreSQL grava medição + versão + snapshot em transação.
9. Blob temporário é apagado.
10. Após o parser completo e o commit, a notificação será colocada na outbox e enviada uma única vez.

## Regra da obra 238

A pasta da medição é autoridade física. Nome de arquivo como `PLS17` não deve ser interpretado como número da medição quando existe uma pasta numerada.

## Aprovação

- Usuário/Responsável: lançamento e correção enquanto `EM_EXECUCAO`.
- Aprovador/Admin: aprovação.
- `APROVADA`: imutável.
- Nova versão não sobrescreve a anterior; a anterior vira `SUBSTITUIDA`.
