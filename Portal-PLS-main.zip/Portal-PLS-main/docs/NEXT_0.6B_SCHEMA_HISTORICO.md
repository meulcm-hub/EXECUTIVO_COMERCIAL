# NEXT-0.6B — schema histórico e fila de exceções

A prévia da obra 607 - PATOS I confirmou que o sistema precisa distinguir:

- medições aptas para migração automática;
- divergência entre pasta e número interno;
- mais de um candidato principal com conteúdo diferente;
- revisão temporal;
- lacunas históricas que não devem ser inventadas.

A NEXT-0.6B não muda o parser e não flexibiliza as regras de novos uploads.
Ela prepara somente a estrutura de banco necessária para:

1. catalogar todo arquivo histórico encontrado sem transformá-lo automaticamente em versão oficial;
2. congelar, na versão oficial, o parser, SHA, caminho, número interno e validações;
3. registrar decisões administrativas de exceção histórica separadamente das regras normais;
4. rastrear cada execução futura de preview/importação.

## Regra importante

Uma exceção histórica aprovada no futuro deve valer somente para aquela medição/arquivo. Ela não pode ensinar ao Portal que divergências semelhantes são aceitáveis em novos uploads.

## SQL

Executar somente `sql/004_history_migration_schema_v1.sql` quando for autorizado.
O antigo `004_domain_schema_v2_DEFERRED.sql` continua adiado nesta etapa.
