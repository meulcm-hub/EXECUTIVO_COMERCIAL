# Status da migração

## Já implementado nesta V0.1

- Estrutura Next.js/Node.
- PostgreSQL e transações.
- Login Google restrito ao domínio LCM.
- Perfis por obra e aprovação separada.
- Endpoint rápido de obras e histórico.
- Upload de até 15 MB sem atravessar o limite de 4,5 MB da Function: Blob privado temporário.
- SHA-256 do arquivo e snapshot inicial.
- Google Drive API.
- Regra de pasta `Nª Medição` preservando pastas existentes.
- Versionamento: uma versão vigente por medição; antigas permanecem como `SUBSTITUIDA`.
- Aprovação bloqueada até o novo parser estar 100% portado e validado.
- Gmail API com destinatários fixos e uploader em CC.
- Texto obrigatório de assinatura de Luciano Capuzzo.
- Auditoria no PostgreSQL.

## Ainda NÃO liberado para produção

1. Portar `interpretarWorkbookPls()` e dependências do Index.html para `src/lib/pls/parser.js`.
2. Portar integralmente o motor Faixa 1 e comparar cálculo célula a célula.
3. Gerar PDF no Node usando o snapshot persistido.
4. Importar OBRAS/ACESSOS/MEDIÇÕES atuais do Google Sheets.
5. Implementar outbox/worker de e-mail após `PROCESSADO`.
6. Homologar primeiro 238 - IPÊ MOD II e depois amostra de Faixa 1.
7. Só então liberar aprovação no novo sistema.

## Por que aprovação está bloqueada

O maior risco seria colocar o novo portal no ar antes de o parser produzir os mesmos números da versão homologada do Apps Script. O endpoint de aprovação recusa qualquer versão cujo `processing_state` não seja `PROCESSADO`.
