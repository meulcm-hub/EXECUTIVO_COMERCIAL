# NEXT-0.6A — Preview da migração histórica

A NEXT-0.6A continua em homologação e **não importa medições**.

## O que foi adicionado

- Preview histórico por obra, processado em lotes pequenos para reduzir risco de timeout.
- Leitura de cada medição pelo mesmo parser/validações já homologados na NEXT-0.5C.
- Comparação com o que já existe nas tabelas `measurements` e `measurement_versions`, apenas para leitura.
- Ação proposta por medição:
  - `CRIAR_MEDICAO_E_VERSAO`
  - `NOVA_VERSAO_CANDIDATA`
  - `JA_EXISTE_MESMO_SHA`
  - `NAO_IMPORTAR`
- Exibição consolidada de perfil, arquivo, SHA-256, número interno, período, data, status temporal, eventos, resumo/orçamentos, candidatos e situação atual do banco.
- Status temporal `OK_INTERNO` quando a pasta não informa competência, mas período e data internos são coerentes.

## O que NÃO acontece

- Não cria `measurements`.
- Não cria `measurement_versions`.
- Não grava `measurement_events`.
- Não altera arquivos nem pastas do Drive.
- Não envia e-mail.
- Não executa nem depende do `004_domain_schema_v2_DEFERRED.sql`.

## Como testar

1. Confirmar `/api/health` com `NEXT-0.6A`.
2. Abrir uma obra e clicar em **Auditar PLS**.
3. Clicar em **Gerar preview histórico**.
4. Aguardar a tabela terminar. O Portal processa no máximo 2 medições por requisição.
5. Conferir se medições bloqueadas permanecem com `NAO_IMPORTAR` e se medições válidas mostram uma ação proposta de banco.

A tabela é somente uma simulação. Nesta versão não existe botão para confirmar importação.
