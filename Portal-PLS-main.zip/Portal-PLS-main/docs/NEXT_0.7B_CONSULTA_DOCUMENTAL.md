# NEXT-0.7B — Consulta documental da obra

Esta entrega adiciona ao painel 0.7A um módulo operacional de **leitura do Google Drive** por obra, sem gravar no Neon.

## Funcionalidades

- Lista de arquivos Excel candidatos reconhecidos pela auditoria já aprovada.
- Estatísticas reais por obra: pastas, arquivos, medições e conflitos de fonte.
- Seleção de uma medição com abertura do Excel no servidor e exibição de perfil, período, levantamento, validação preliminar, resumos e orçamentos existentes.
- Link direto à pasta e ao arquivo no Google Drive, sujeito às permissões do usuário no Drive.
- Mantém a tabela separada de **medições realmente registradas** no Neon.
- Mensagens claras diferenciando **arquivo candidato** de **medição oficial**.

## Controles

- `GET /api/obras/[id]/documentos` exige `requireWorkAccess` e `works.ativo=true`.
- `GET /api/obras/[id]/documentos/[numero]` exige `requireWorkAccess`, seleciona um candidato com a mesma lógica de auditoria e executa `readPlsWorkbookPreview` sem `includeEventPayload`.
- Esses endpoints nunca chamam SQL INSERT/UPDATE/DELETE ou APIs de gravação do Drive.
- São dinâmicos, de leitura, com cache `private, no-store`.
- Um `APTO` **na leitura preliminar do Excel** não significa aprovação, nem validação final das matrizes. A auditoria técnica continua sendo necessária.
- A contagem no painel não implica importação histórica; o sistema antigo segue sendo o oficial.

## Testes locais

- `node scripts/static-check.mjs` — 46 arquivos JS válidos.
- `node tests/smoke_ui_07b.cjs` — painel, login, obras, detalhe e módulo documental com estados inicial e carregado.
- `node tests/test_drive_work_view_07b.mjs` — seleção de fonte, alerta e segurança de links.
- `node tests/test_document_endpoints_07b.cjs` — acesso autorizado e negado; usuário não autorizado não aciona consulta ao Drive.
- `node tests/test_payload_06{c,d,e,f}.mjs` — sem regressão de motor Faixa 1 / Faixa 2 nos casos sintéticos já existentes.

O build completo depende do `npm run build` executado pela Vercel. O ambiente de geração não conseguiu instalar o Next.js por restrição de rede.
