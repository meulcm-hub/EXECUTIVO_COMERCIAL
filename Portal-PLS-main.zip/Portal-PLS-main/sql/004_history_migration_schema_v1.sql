-- Portal PLS LCM — NEXT-0.6B
-- Estrutura ADITIVA para migração histórica e fila de exceções.
-- NÃO importa medições, NÃO altera o Google Drive e NÃO apaga dados existentes.
-- Idempotente: usa IF NOT EXISTS sempre que possível.

create extension if not exists pgcrypto;

-- Campos mínimos para congelar a leitura/validação de cada versão oficial.
alter table measurements add column if not exists engine text;
alter table measurements add column if not exists faixa_pls_snapshot text;
alter table measurements add column if not exists status_updated_at timestamptz;
alter table measurements add column if not exists status_updated_by text;
alter table measurements add column if not exists legacy_id text;

alter table measurement_versions add column if not exists parser_profile text;
alter table measurement_versions add column if not exists source_filename text;
alter table measurement_versions add column if not exists source_path text;
alter table measurement_versions add column if not exists source_parent_folder_id text;
alter table measurement_versions add column if not exists source_measurement_folder_name text;
alter table measurement_versions add column if not exists internal_measurement_number integer;
alter table measurement_versions add column if not exists period_reference_raw text;
alter table measurement_versions add column if not exists validation_status text;
alter table measurement_versions add column if not exists validation_reasons jsonb not null default '[]'::jsonb;
alter table measurement_versions add column if not exists temporal_validation_status text;
alter table measurement_versions add column if not exists candidate_resolution text;
alter table measurement_versions add column if not exists structure_sha256 char(64);
alter table measurement_versions add column if not exists structure_snapshot_json jsonb not null default '{}'::jsonb;
alter table measurement_versions add column if not exists legacy_id text;
alter table measurement_versions add column if not exists replaced_by_version_id uuid references measurement_versions(id);

-- Campos comuns aos eventos das duas faixas.
alter table measurement_events add column if not exists area text;
alter table measurement_events add column if not exists item text;
alter table measurement_events add column if not exists tipo_evento text;
alter table measurement_events add column if not exists quantidade numeric(18,6);
alter table measurement_events add column if not exists valor_servico numeric(18,2);
alter table measurement_events add column if not exists valor_evento numeric(18,2);
alter table measurement_events add column if not exists perc_anterior numeric(18,10);
alter table measurement_events add column if not exists glosas numeric(18,6);
alter table measurement_events add column if not exists valor_glosa numeric(18,2);
alter table measurement_events add column if not exists matriz_json jsonb;

-- Inventário histórico: todo arquivo encontrado pode ser auditado sem virar versão oficial.
create table if not exists measurement_source_files (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references works(id) on delete restrict,
  detected_measurement integer,
  folder_measurement integer,
  filename_measurement integer,
  internal_measurement integer,
  drive_file_id text not null unique,
  drive_parent_id text,
  measurement_folder_name text,
  arquivo_nome text not null,
  source_path text,
  mime_type text,
  tamanho_bytes bigint,
  drive_modified_at timestamptz,
  source_role text,
  path_classification text,
  audit_status text,
  parser_profile text,
  sha256_arquivo char(64),
  period_reference_raw text,
  survey_date date,
  validation_status text,
  validation_reasons jsonb not null default '[]'::jsonb,
  temporal_validation_status text,
  is_selected_source boolean not null default false,
  selected_for_measurement integer,
  metadata_json jsonb not null default '{}'::jsonb,
  first_seen_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now()
);
create index if not exists ix_measurement_source_files_work_measurement
  on measurement_source_files(work_id, detected_measurement);
create index if not exists ix_measurement_source_files_sha
  on measurement_source_files(sha256_arquivo) where sha256_arquivo is not null;

alter table measurement_versions add column if not exists source_file_id uuid references measurement_source_files(id);
create index if not exists ix_measurement_versions_source_file on measurement_versions(source_file_id);

-- Decisão explícita para exceções legadas. Nunca altera a regra normal de novos uploads.
create table if not exists migration_review_decisions (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references works(id) on delete restrict,
  measurement_number integer not null check (measurement_number > 0),
  source_file_id uuid references measurement_source_files(id) on delete restrict,
  issue_type text not null,
  issue_status text not null default 'PENDENTE',
  resolution_code text,
  selected_source_file_id uuid references measurement_source_files(id) on delete restrict,
  reason text,
  evidence_json jsonb not null default '{}'::jsonb,
  created_by text not null,
  decided_by text,
  decided_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists ix_migration_review_work_measurement
  on migration_review_decisions(work_id, measurement_number, issue_status);

-- Rastreabilidade de cada execução de preview/importação histórica.
create table if not exists migration_runs (
  id uuid primary key default gen_random_uuid(),
  mode text not null,
  status text not null default 'INICIADO',
  work_id uuid references works(id) on delete restrict,
  started_by text not null,
  summary_json jsonb not null default '{}'::jsonb,
  started_at timestamptz not null default now(),
  finished_at timestamptz
);

create table if not exists migration_run_items (
  id bigserial primary key,
  run_id uuid not null references migration_runs(id) on delete cascade,
  work_id uuid not null references works(id) on delete restrict,
  measurement_number integer not null check (measurement_number > 0),
  source_file_id uuid references measurement_source_files(id) on delete restrict,
  measurement_id uuid references measurements(id) on delete restrict,
  measurement_version_id uuid references measurement_versions(id) on delete restrict,
  validation_status text,
  proposed_action text,
  final_action text,
  result_status text,
  detail_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists ix_migration_run_items_run on migration_run_items(run_id, measurement_number);

-- Observação: o antigo 004_domain_schema_v2_DEFERRED.sql continua NÃO obrigatório nesta etapa.
-- Esta estrutura nova cobre somente a migração histórica e a rastreabilidade das exceções.
