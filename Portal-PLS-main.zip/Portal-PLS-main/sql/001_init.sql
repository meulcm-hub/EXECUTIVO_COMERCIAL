create extension if not exists pgcrypto;

create table if not exists app_users (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  nome text not null default '',
  perfil_global text not null default 'USUARIO' check (perfil_global in ('USUARIO','ADMIN')),
  ativo boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists works (
  id uuid primary key default gen_random_uuid(),
  codigo text not null,
  nome text not null,
  cidade text,
  uf text,
  faixa_pls text check (faixa_pls in ('FAIXA_1','FAIXA_2')),
  drive_folder_id text,
  ativo boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (codigo, nome)
);

create table if not exists work_access (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references app_users(id) on delete cascade,
  work_id uuid not null references works(id) on delete cascade,
  perfil text not null default 'USUARIO' check (perfil in ('USUARIO','RESPONSAVEL','APROVADOR','ADMIN')),
  ativo boolean not null default true,
  created_at timestamptz not null default now(),
  unique(user_id, work_id)
);

create table if not exists measurements (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references works(id) on delete restrict,
  numero integer not null check (numero > 0),
  competencia text,
  periodo_inicio date,
  periodo_fim date,
  data_levantamento date,
  status text not null default 'EM_EXECUCAO' check (status in ('EM_EXECUCAO','APROVADA','DESAPROVADA','EXCLUIR')),
  avanco_periodo numeric(12,6),
  avanco_acumulado numeric(12,6),
  valor_periodo numeric(18,2),
  valor_acumulado numeric(18,2),
  criado_por text not null,
  aprovado_por text,
  aprovado_em timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(work_id, numero)
);

create table if not exists measurement_versions (
  id uuid primary key default gen_random_uuid(),
  measurement_id uuid not null references measurements(id) on delete restrict,
  versao integer not null check (versao > 0),
  vigente boolean not null default true,
  status_versao text not null default 'EM_EXECUCAO' check (status_versao in ('EM_EXECUCAO','SUBSTITUIDA','APROVADA','DESAPROVADA','EXCLUIR')),
  processing_state text not null default 'AGUARDANDO_PARSER' check (processing_state in ('AGUARDANDO_PARSER','PROCESSANDO','PROCESSADO','ERRO')),
  arquivo_nome text not null,
  mime_type text,
  tamanho_bytes bigint,
  drive_file_id text not null,
  drive_folder_id text not null,
  drive_url text,
  sha256_arquivo char(64) not null,
  sha256_snapshot char(64),
  snapshot_json jsonb not null default '{}'::jsonb,
  enviado_por text not null,
  origem text not null default 'UPLOAD_EXCEL',
  aprovado_por text,
  aprovado_em timestamptz,
  created_at timestamptz not null default now(),
  unique(measurement_id, versao)
);

create unique index if not exists ux_measurement_one_current_version
  on measurement_versions(measurement_id) where vigente = true;

create table if not exists measurement_events (
  id bigserial primary key,
  measurement_version_id uuid not null references measurement_versions(id) on delete cascade,
  linha_pls integer,
  macro_codigo text,
  macro text,
  evento text,
  descricao text,
  unidade text,
  repeticoes_previstas numeric(18,6),
  incidencia_servico numeric(18,10),
  incidencia_obra numeric(18,10),
  exec_anterior numeric(18,6),
  exec_periodo numeric(18,6),
  exec_acumulado numeric(18,6),
  perc_periodo numeric(18,10),
  perc_acumulado numeric(18,10),
  incidencia_periodo numeric(18,10),
  incidencia_acumulada numeric(18,10),
  local_referencia text
);

create index if not exists ix_measurement_events_version on measurement_events(measurement_version_id);
create index if not exists ix_measurements_work_num on measurements(work_id, numero desc);

create table if not exists audit_events (
  id bigserial primary key,
  work_id uuid references works(id),
  measurement_id uuid references measurements(id),
  upload_id uuid references measurement_versions(id),
  actor_email text not null,
  action text not null,
  detail jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists notification_outbox (
  id bigserial primary key,
  upload_id uuid not null references measurement_versions(id) on delete cascade,
  type text not null,
  status text not null default 'PENDENTE' check (status in ('PENDENTE','ENVIANDO','ENVIADO','ERRO')),
  tentativas integer not null default 0,
  ultimo_erro text,
  enviado_em timestamptz,
  created_at timestamptz not null default now(),
  unique(upload_id, type)
);
