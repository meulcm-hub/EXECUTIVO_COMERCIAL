import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const root = path.resolve(process.cwd());
const files = [];
function walk(dir) {
  for (const name of fs.readdirSync(dir)) {
    const full = path.join(dir, name);
    const st = fs.statSync(full);
    if (st.isDirectory()) walk(full);
    else if (/\.(js|mjs)$/.test(name)) files.push(full);
  }
}
walk(path.join(root, 'src'));
files.push(path.join(root, 'next.config.mjs'));
for (const file of files) execFileSync(process.execPath, ['--experimental-default-type=module', '--check', file], { stdio: 'pipe' });
console.log(`OK: ${files.length} arquivos JavaScript passaram no parser do Node.`);
